// Servicos simulados: Mercado Pago, envio de e-mail e servico do organizador.
// Respondem com atraso fixo, para representar o tempo de rede de um servico externo.
// Mercado Pago:
//   - POST /v1/payments: cartao e criado ja aprovado (e pago); PIX e criado pendente, com QR code e ticket_url.
//   - POST /__pagar/{id}: o cliente pagou o PIX (chamado pelo gerador de carga antes da notificacao de aprovacao).
//   - GET /v1/payments/{id}: "approved" se o pagamento foi pago, "pending" se ainda nao.
//   - GET /__pagos: lista de pagamentos pagos, usada na conferencia de pagamentos x ingressos.
// Organizador (so e chamado com CHAMA_ORGANIZADOR=1):
//   - GET /configuracoes-evento: limite por tipo de ingresso. Com LIMITE_CAMAROTE definido, conta os ingressos
//     de Camarote ja emitidos no banco e informa se o tipo esta esgotado, como o servico do organizador.
const http = require('http');
const MP = Number(process.env.MP_ATRASO_MS || 300);
const MP_CRIAR = Number(process.env.MP_CRIAR_ATRASO_MS || 800);
const SMTP = Number(process.env.SMTP_ATRASO_MS || 500);
const ORG = Number(process.env.ORG_ATRASO_MS || 150);
const PORTA = Number(process.env.PORTA || 4000);
const LIMITE_CAMAROTE = Number(process.env.LIMITE_CAMAROTE || 0);
const FIREBASE = (process.env.FIREBASE_URL || '').replace(/\/$/, '');
const pagos = new Map();          // id -> metodo
const tipos = new Map();          // id -> tipo de pagamento (cartao ou PIX)
let proximoId = 700000000000;

function responder(res, atraso, corpo) {
  setTimeout(() => {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(corpo));
  }, atraso);
}

async function vendidosCamarote(eventoId) {
  const r = await fetch(`${FIREBASE}/ingressos/${eventoId}/disponiveis.json`);
  const d = (await r.json()) || {};
  return Object.values(d).filter((t) => t && t.tipo === 'Camarote').length;
}

http.createServer((req, res) => {
  const url = req.url || '/';
  let corpo = '';
  req.on('data', (c) => { corpo += c; });
  req.on('end', async () => {
    let m;
    if (req.method === 'POST' && url.startsWith('/v1/payments')) {
      let pedido = {};
      try { pedido = JSON.parse(corpo) || {}; } catch (e) { /* ignora */ }
      const valor = pedido.transaction_amount || 0;
      const id = String(++proximoId);
      if (pedido.payment_method_id === 'pix') {  // PIX: gerado pendente; aprovado depois que o cliente paga
        tipos.set(id, 'bank_transfer');
        return responder(res, MP_CRIAR, { id: Number(id), status: 'pending', status_detail: 'pending_waiting_transfer',
          payment_type_id: 'bank_transfer', transaction_amount: valor,
          point_of_interaction: { transaction_data: { qr_code: '00020126-pix-de-teste-' + id,
            ticket_url: `https://www.mercadopago.com.br/payments/${id}/ticket?caller_id=0` } } });
      }
      pagos.set(id, 'cartao'); tipos.set(id, 'credit_card');   // cartao: aprovado desde a criacao
      return responder(res, MP_CRIAR, { id: Number(id), status: 'approved', status_detail: 'accredited',
        payment_type_id: 'credit_card', transaction_amount: valor });
    }
    if (req.method === 'POST' && (m = url.match(/^\/__pagar\/(\d+)/))) {
      pagos.set(m[1], 'pix');
      return responder(res, 0, { ok: true });
    }
    if (url.startsWith('/__pagos')) {
      return responder(res, 0, [...pagos.entries()].map(([id, metodo]) => ({ id, metodo })));
    }
    if ((m = url.match(/^\/v1\/payments\/(\d+)/))) {
      const id = m[1];
      const status = pagos.has(id) ? 'approved' : 'pending';
      return responder(res, MP, { id: Number(id), status,
        status_detail: status === 'approved' ? 'accredited' : 'pending_waiting_transfer',
        payment_type_id: tipos.get(id) || 'bank_transfer', transaction_amount: 55 });
    }
    if (url.startsWith('/smtp')) return responder(res, SMTP, { ok: true });
    if (url.startsWith('/verificar-lote')) return responder(res, ORG, { trocado: false });
    if (url.startsWith('/configuracoes-evento')) {
      if (!LIMITE_CAMAROTE || !FIREBASE) return responder(res, ORG, { success: true, limitePorTipo: [] });
      const ev = (url.match(/eventoId=(\w+)/) || [])[1] || '1001';
      let vendido = 0;
      try { vendido = await vendidosCamarote(ev); } catch (e) { /* sem leitura, sem limite */ }
      const disponivel = Math.max(0, LIMITE_CAMAROTE - vendido);
      return responder(res, ORG, { success: true, limitePorTipo: [{ tipo: 'Camarote', ativo: true,
        limite: LIMITE_CAMAROTE, vendido, disponivel, esgotado: disponivel === 0 }] });
    }
    responder(res, 0, { status: 'mock online' });
  });
}).listen(PORTA, () => console.log('mocks na porta ' + PORTA));
