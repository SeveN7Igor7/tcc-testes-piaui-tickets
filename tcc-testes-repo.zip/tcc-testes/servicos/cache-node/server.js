// Servidor 3 (versao de teste, semelhante a de producao): cache dos dados da pagina do evento no Redis.
// GET  /evento/:id     -> devolve os dados do evento do Redis; se nao houver (ou expirou), le do banco e guarda.
// POST /invalidar/:id  -> apaga o cache do evento (chamado quando o organizador altera valores ou dados).
// GET  /estatisticas   -> acertos e faltas do cache, para a analise do teste.
const http = require('http');
const { createClient } = require('redis');
const { initializeApp } = require('firebase/app');
const { getDatabase, ref, get } = require('firebase/database');

const PORTA = Number(process.env.PORT || 3020);
const TTL = Number(process.env.CACHE_TTL || 180);           // 3 minutos, como em producao
const databaseURL = process.env.FIREBASE_DATABASE_URL;
if (!databaseURL || /piauidbtickets|piauiticketsdb/.test(databaseURL)) { console.error('Banco invalido'); process.exit(1); }
const db = getDatabase(initializeApp({ databaseURL }));
const redis = createClient({ url: process.env.REDIS_URL || 'redis://localhost:6379' });
redis.on('error', (e) => console.error('Redis:', e.message));

const stats = { acertos: 0, faltas: 0, leiturasBanco: 0, invalidacoes: 0 };
const emAndamento = new Map();   // evita varias leituras do banco ao mesmo tempo para o mesmo evento

async function lerDoBanco(id) {
  stats.leiturasBanco++;
  const s = await get(ref(db, `eventos/${id}`));
  return s.exists() ? s.val() : null;
}

async function evento(id) {
  const chave = `evento:${id}`;
  const guardado = await redis.get(chave);
  if (guardado) { stats.acertos++; return { dados: guardado, origem: 'HIT' }; }
  stats.faltas++;
  if (!emAndamento.has(id)) {
    emAndamento.set(id, (async () => {
      const dados = await lerDoBanco(id);
      const json = JSON.stringify(dados);
      if (dados) await redis.set(chave, json, { EX: TTL });
      return json;
    })().finally(() => emAndamento.delete(id)));
  }
  return { dados: await emAndamento.get(id), origem: 'MISS' };
}

function responder(res, status, corpo, extra = {}) {
  res.writeHead(status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*', ...extra });
  res.end(typeof corpo === 'string' ? corpo : JSON.stringify(corpo));
}

const servidor = http.createServer(async (req, res) => {
  try {
    const url = (req.url || '/').split('?')[0];
    let m;
    if (req.method === 'GET' && (m = url.match(/^\/evento\/([\w-]+)\/?$/))) {
      const r = await evento(m[1]);
      return responder(res, 200, r.dados || 'null', { 'X-Cache': r.origem });
    }
    if (req.method === 'POST' && (m = url.match(/^\/invalidar\/([\w-]+)\/?$/))) {
      await redis.del(`evento:${m[1]}`); stats.invalidacoes++;
      return responder(res, 200, { ok: true });
    }
    if (url === '/estatisticas') return responder(res, 200, stats);
    if (url === '/' || url === '/health') return responder(res, 200, { status: 'online' });
    responder(res, 404, { error: 'Rota nao encontrada' });
  } catch (e) {
    console.error('Erro:', e.message);
    responder(res, 500, { error: 'Erro ao obter dados' });
  }
});

(async () => {
  await redis.connect();
  servidor.listen(PORTA, () => console.log(`Cache da pagina do evento na porta ${PORTA} (expira em ${TTL} s)`));
})();
