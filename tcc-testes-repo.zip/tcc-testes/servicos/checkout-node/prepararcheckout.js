import { database } from './firebaseConfig.js';
import { ref, get, set } from 'firebase/database';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Função auxiliar para buscar dados do Firebase
 */
async function getFirebase(path) {
  try {
    const dbRef = ref(database, path);
    const snapshot = await get(dbRef);
    return snapshot.exists() ? snapshot.val() : null;
  } catch (error) {
    console.error(`Erro ao buscar dados do Firebase (${path}):`, error);
    return null;
  }
}

/**
 * Função auxiliar para salvar dados no Firebase
 */
async function putFirebase(path, data) {
  try {
    const dbRef = ref(database, path);
    await set(dbRef, data);
    return true;
  } catch (error) {
    console.error(`Erro ao salvar dados no Firebase (${path}):`, error);
    return false;
  }
}

/**
 * Gera um cookie aleatório
 */
function generateCookie() {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let cookie = '';
  for (let i = 0; i < 12; i++) {
    cookie += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return cookie;
}

/**
 * Normaliza o nome de uma mesa para comparação, ignorando maiúsculas/minúsculas,
 * espaços extras e zeros à esquerda no número final (ex: "Mesa 15" == "Mesa 015").
 */
function normalizarNomeMesa(nome) {
  if (!nome) return '';
  const limpo = nome.trim().replace(/\s+/g, ' ');
  const match = limpo.match(/^(.*?)(\d+)$/);
  if (match) {
    const prefixo = match[1].trim();
    const numero = match[2].padStart(3, '0');
    return `${prefixo} ${numero}`.trim().toLowerCase();
  }
  return limpo.toLowerCase();
}

/**
 * Verifica se uma mesa já foi efetivamente vendida (ingresso emitido) para o evento,
 * consultando ingressos/{eventid}/disponiveis e comparando o campo "tipo" com o nometipo da mesa.
 */
async function verificarMesaJaVendida(eventid, nometipo) {
  const ingressos = await getFirebase(`ingressos/${eventid}/disponiveis`);
  if (!ingressos || typeof ingressos !== 'object') {
    return false;
  }

  const nometipoNormalizado = normalizarNomeMesa(nometipo);

  for (const ingresso of Object.values(ingressos)) {
    if (ingresso && normalizarNomeMesa(ingresso.tipo) === nometipoNormalizado) {
      return true;
    }
  }

  return false;
}

/**
 * Verifica se uma mesa está travada (em finalização de compra por outro cliente).
 * Considera travada quando existe um registro em audit/mesastemp/{codigoMesa}
 * cujo horário de expiração (horário de Brasília) ainda não passou.
 */
async function verificarTravaMesa(codigoMesa) {
  const auditData = await getFirebase(`audit/mesastemp/${codigoMesa}`);
  if (!auditData || !auditData.expiracaoISO) {
    return null;
  }

  const agora = new Date();
  const horarioBrasilAgora = new Date(agora.getTime() - (3 * 60 * 60 * 1000));
  const expiracao = new Date(auditData.expiracaoISO);

  if (horarioBrasilAgora < expiracao) {
    return auditData;
  }

  return null;
}

/**
 * Registra tentativa de fraude em arquivo JSON
 */
function logFraudAttempt(data) {
  const logDir = path.join(__dirname, 'logs');
  
  // Criar diretório de logs se não existir
  if (!fs.existsSync(logDir)) {
    fs.mkdirSync(logDir, { recursive: true });
  }
  
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const logFileName = `fraud_attempt_${timestamp}_${data.cpf}.json`;
  const logFilePath = path.join(logDir, logFileName);
  
  fs.writeFileSync(logFilePath, JSON.stringify(data, null, 2), 'utf8');
}

/**
 * Handler principal da API de preparar checkout
 */
/**
 * Processar reserva de mesa com validação no Firebase
 */
async function processarReservaMesa(req, res, evento, cpf, eventid, total, unt, tiposArray, taxaadicional, taxaadicionalvalor) {
  try {
    const errosValidacao = [];

    // Validar se o evento tem configuração de mesas
    if (!evento.mesas) {
      return res.json({
        success: false,
        message: 'Este evento não possui configuração de mesas disponível'
      });
    }

    // Para mesas, cada evento tem um único nó configurado em evento.mesas
    // (o nome do nó varia por evento, ex: "Estranha Loucura", "Zezo In The Hall")
    let mesaValidaEncontrada = false;

    const mesaConfigurada = Object.values(evento.mesas)[0];
    if (mesaConfigurada) {
      const valorMesa = parseFloat(mesaConfigurada.valor || mesaConfigurada.valorbruto || mesaConfigurada.valortotal || 0);

      if (Math.abs(valorMesa - total) <= 0.01) {
        mesaValidaEncontrada = true;
      }
    }

    if (!mesaValidaEncontrada) {
      errosValidacao.push(`Valor total R$ ${total.toFixed(2).replace('.', ',')} não corresponde ao valor da mesa configurada para este evento`);
    }

    // Se houver erros de validação, bloquear
    if (errosValidacao.length > 0) {
      // Registrar tentativa de fraude para mesas
      const logContent = {
        '🚨 TipoAlerta': 'TENTATIVA_MANIPULACAO_VALORES_MESA',
        '🕒 DataHora': new Date().toISOString(),
        '👤 CPF': cpf,
        '🎫 EventoID': eventid,
        '🪑 TipoReserva': 'Mesa',
        '💰 ValorRecebido': total,
        '� MesasRecebidas': tiposArray,
        '⚠️ Erros': errosValidacao,
        '🌐 IP': req.ip || req.connection.remoteAddress || 'unknown',
        '📱 UserAgent': req.get('user-agent') || 'unknown'
      };

      logFraudAttempt(logContent);

      return res.json({
        success: false,
        message: 'Configuração incorreta, link encerrado ou evento com dados fornecidos inválidos para venda, contate o suporte'
      });
    }

    // Validação passou - processar a reserva
    // Reservas de mesa não têm limite de compra por CPF

    // Verificar se alguma das mesas do carrinho já foi vendida (ingresso já emitido)
    for (const tipoData of tiposArray) {
      const nometipoMesa = tipoData.nometipo || '';
      if (nometipoMesa && await verificarMesaJaVendida(eventid, nometipoMesa)) {
        return res.json({
          success: false,
          message: `A mesa '${nometipoMesa}' já foi adquirida por outro cliente.`
        });
      }
    }

    // Verificar se a mesa já está travada (outro cliente finalizando a compra)
    const primeiraMesaCheck = tiposArray[0];
    const codigoMesa = primeiraMesaCheck && primeiraMesaCheck.nometipo
      ? normalizarNomeMesa(primeiraMesaCheck.nometipo).replace(/\s+/g, '_')
      : null;

    if (codigoMesa) {
      const trava = await verificarTravaMesa(codigoMesa);
      if (trava) {
        return res.json({
          success: false,
          message: 'A mesa selecionada está em finalização de compra por outro cliente. Aguarde alguns minutos e tente novamente.'
        });
      }
    }

    // Gerar cookie e salvar dados validados - USAR MESMA LÓGICA DOS INGRESSOS
    const cookie = generateCookie();
    const timestamp = new Date().toISOString();

    // Para mesas, manter estrutura igual aos ingressos normais
    const tiposValidados = {};
    for (const tipoData of tiposArray) {
      const nometipo = tipoData.nometipo || '';
      const untTipo = parseInt(tipoData.unt || 0);
      const valorbruto = parseFloat(tipoData.valorbruto || 0);

      tiposValidados[nometipo] = {
        nometipo: nometipo,
        unt: untTipo,
        type: 1, // Mesas sempre têm multiplicity 1
        valorbruto: valorbruto
      };
    }

    const payload = {
      eventid: eventid,
      timeout: 300,
      unt: unt,
      user: cpf,
      valortotal: total, // Usar valor total informado
      paymentcompleted: false,
      generatedtoken: false,
      generatedtoken2: false,
      generatedtoken3: false,
      generatedtoken4: false,
      generatedtoken5: false,
      tipos: tiposValidados,
      timestamp: timestamp,
      mesa: true, // Marcar que é uma reserva de mesa
      comprasegura: false,
      valorcompraseguro: Math.round(total * 1.1 * 100) / 100 // valortotal + 10%
    };

    // Adicionar taxa adicional se presente
    if (taxaadicional === true) {
      payload.taxaadicional = 'true';
      const valorAdicionalFloat = parseFloat(taxaadicionalvalor) || 0;
      payload.taxaadicionalvalor = valorAdicionalFloat;
      payload.valortotaladicional = total + valorAdicionalFloat;
    }

    // Salvar no Firebase - IGUAL AOS INGRESSOS
    await putFirebase(`cookies/${cookie}`, payload);
    await putFirebase(`cookiesfixo/${cookie}`, payload);
    await putFirebase(`users/cpf/${cpf}/carrinhos/abertos/${eventid}`, {
      quantidade: unt,
      valortotal: total,
      tipos: tiposValidados,
      mesa: true,
      last_update: timestamp
    });

    // PARA MESAS: Salvar também em /audit/mesastemp com código da mesa (trava contra concorrência)
    if (codigoMesa) {
      // Ajustar para fuso horário brasileiro (UTC-3)
      const agora = new Date();
      const horarioBrasil = new Date(agora.getTime() - (3 * 60 * 60 * 1000)); // Subtrair 3 horas
      const horarioExpiracao = new Date(horarioBrasil.getTime() + (30 * 60 * 1000)); // Adicionar 30 minutos
      const dataFormatada = horarioBrasil.toISOString().split('T')[0]; // YYYY-MM-DD
      const horarioFormatado = horarioBrasil.toISOString().split('T')[1].split('.')[0]; // HH:MM:SS
      const horarioExpiracaoFormatado = horarioExpiracao.toISOString().split('T')[1].split('.')[0]; // HH:MM:SS

      await putFirebase(`audit/mesastemp/${codigoMesa}`, {
        cod_mesa: codigoMesa,
        codcarrinho: cookie,
        data: dataFormatada,
        horario: horarioFormatado,
        horarioexpiracao: horarioExpiracaoFormatado,
        expiracaoISO: horarioExpiracao.toISOString() // usado por verificarTravaMesa para checar a trava
      });
    }

    // Retornar sucesso
    return res.json({
      success: true,
      cookie: cookie
    });

  } catch (error) {
    console.error('Erro no processamento de reserva de mesa:', error);
    return res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
}

export async function prepararCheckoutHandler(req, res) {
  try {
    // Extrair dados do body
    const {
      cpf: cpfRaw,
      eventid,
      total,
      unt,
      tipos,
      codaffiliate = null,
      affiliate = null,
      semtaxa = false,
      oferta = null,
      mesa = false,
      taxaadicional = false,
      taxaadicionalvalor = 0
    } = req.body;

    // Limpar CPF (remover caracteres não numéricos)
    const cpf = cpfRaw ? cpfRaw.replace(/\D/g, '') : '';

    // Normalizar tipos: converter para array se for objeto
    let tiposArray = tipos;
    if (tipos && !Array.isArray(tipos)) {
      tiposArray = Object.values(tipos);
    }

    // Validação básica
    if (!cpf || !eventid || !unt || unt <= 0 || !tiposArray || tiposArray.length === 0) {
      return res.json({
        success: false,
        message: 'Dados incompletos'
      });
    }

    // 1. Buscar dados do evento no Firebase
    const evento = await getFirebase(`eventos/${eventid}`);

    if (!evento) {
      return res.json({
        success: false,
        message: 'Configuração incorreta, link encerrado ou evento com dados fornecidos inválidos para venda, contate o suporte'
      });
    }

    // SE FOR RESERVA DE MESA, USAR VALIDAÇÃO ESPECÍFICA
    if (mesa === true) {
      return await processarReservaMesa(req, res, evento, cpf, eventid, total, unt, tiposArray, taxaadicional, taxaadicionalvalor);
    }

    // 1.1. Determinar se é compra de OFERTA, AFILIADO ou NORMAL
    let tiposParaValidar = [];
    let isOferta = false;
    let isAffiliate = false;

    // Verificar se é compra de AFILIADO
    if (affiliate === "true" && codaffiliate) {
      if (evento.afiliados && evento.afiliados[codaffiliate]) {
        const afiliadoData = evento.afiliados[codaffiliate];

        // Verificar se o afiliado está disponível
        if (!afiliadoData.disponivel || afiliadoData.disponivel !== true) {
          return res.json({
            success: false,
            message: 'Este link de afiliado não está mais disponível.'
          });
        }

        // Usar tipos do afiliado
        if (afiliadoData.tipos && Array.isArray(Object.values(afiliadoData.tipos))) {
          tiposParaValidar = Object.values(afiliadoData.tipos);
          isAffiliate = true;
        } else {
          return res.json({
            success: false,
            message: 'Afiliado sem tipos de ingressos configurados.'
          });
        }
      } else {
        return res.json({
          success: false,
          message: 'Afiliado não encontrado.'
        });
      }
    }
    // Se não for afiliado, verificar se é OFERTA
    else if (oferta) {
      if (evento.ofertas && evento.ofertas[oferta]) {
        const ofertaData = evento.ofertas[oferta];

        // Verificar se a oferta está disponível
        if (!ofertaData.disponivel || ofertaData.disponivel !== true) {
          return res.json({
            success: false,
            message: 'Esta oferta não está mais disponível.'
          });
        }

        // Usar tipos da oferta
        if (ofertaData.tipos && Array.isArray(Object.values(ofertaData.tipos))) {
          tiposParaValidar = Object.values(ofertaData.tipos);
          isOferta = true;
        } else {
          return res.json({
            success: false,
            message: 'Oferta sem tipos de ingressos configurados.'
          });
        }
      } else {
        return res.json({
          success: false,
          message: 'Oferta não encontrada.'
        });
      }
    } else {
      // Compra normal - usar tipos do evento
      if (!evento.tipos) {
        return res.json({
          success: false,
          message: 'Configuração incorreta, link encerrado ou evento com dados fornecidos inválidos para venda, contate o suporte'
        });
      }
      tiposParaValidar = Object.values(evento.tipos);
    }

    // 2. VALIDAÇÃO DE SEGURANÇA: Verificar se os valores enviados correspondem aos do Firebase
    let valorTotalCalculado = 0;
    let valorBaseTotal = 0; // Total sem nenhuma taxa
    const errosValidacao = [];

    // Taxa personalizada: os valores no Firebase já incluem a taxa padrão de 10%,
    // então o valor com taxa personalizada é (valor / 1.10) * (1 + taxa/100)
    const taxaPersonalizada = parseFloat(evento.taxapersonalizada);
    const temTaxaPersonalizada = !isNaN(taxaPersonalizada) && taxaPersonalizada >= 0;

    for (const tipoData of tiposArray) {
      const nometipo = tipoData.nometipo || '';
      const untTipo = parseInt(tipoData.unt || 0);
      const valorbrutoRecebido = parseFloat(tipoData.valorbruto || 0);
      const multiplicity = parseInt(tipoData.type || 1);

      // Buscar tipo nos tipos para validar
      let tipoNoEvento = null;
      for (const tipo of tiposParaValidar) {
        if (tipo.nometipo === nometipo) {
          tipoNoEvento = tipo;
          break;
        }
      }

      if (!tipoNoEvento) {
        const origem = isAffiliate ? " no afiliado" : (isOferta ? " na oferta" : " no evento");
        errosValidacao.push(`Tipo de ingresso '${nometipo}' não encontrado${origem}`);
        continue;
      }

      // Validar multiplicidade
      if (multiplicity > 1 && untTipo % multiplicity !== 0) {
        errosValidacao.push(`Quantidade para '${nometipo}' inválida: este tipo exige múltiplos de ${multiplicity}.`);
        continue;
      }

      const grupos = multiplicity > 1 ? Math.floor(untTipo / multiplicity) : untTipo;

      // Extrair todos os valores válidos deste tipo
      const valoresValidos = [];
      // Valores sem taxa ficam separados para não receberem a taxa personalizada
      const valoresSemTaxa = [];

      // Para OFERTAS e AFILIADOS: apenas o valorbruto é válido
      if (isOferta || isAffiliate) {
        const valorbrutoReal = parseFloat(tipoNoEvento.valorbruto || 0);
        valoresValidos.push(valorbrutoReal);
      } else {
        // Para EVENTO NORMAL: valorbruto + valores promocionais ativos
        const valorbrutoReal = parseFloat(tipoNoEvento.valorbruto || 0);
        valoresValidos.push(valorbrutoReal);

        // Percorrer todas as chaves do tipo para encontrar valores promocionais
        for (const [chave, valor] of Object.entries(tipoNoEvento)) {
          const match = chave.match(/^valorpromocionallink(\d*)$/);
          if (match) {
            const sufixo = match[1];
            const chaveAtivo = `promocionallinkativo${sufixo}`;

            // Verificar se está ativo
            if (tipoNoEvento[chaveAtivo] === true) {
              const valorPromocional = parseFloat(valor);
              if (valorPromocional > 0) {
                valoresValidos.push(valorPromocional);
              }
            }
          }
        }

        // Verificar se aceita valor sem taxa
        if (semtaxa === true || evento.semtaxa === true || evento.semtaxapromocional === true) {
          const valorSemTaxa = Math.round((valorbrutoReal / 1.10) * 100) / 100;
          if (valorSemTaxa > 0) {
            valoresSemTaxa.push(valorSemTaxa);
          }
        }

        // Verificar casadinhas (desconto por quantidade)
        if (evento.casadinhastemp && typeof evento.casadinhastemp === 'object') {
          const casadinha = evento.casadinhastemp;

          if (casadinha.status === 'ativo') {
            for (const [threshold, valorCasadinha] of Object.entries(casadinha)) {
              if (threshold !== 'status' && !isNaN(threshold)) {
                if (grupos >= parseInt(threshold)) {
                  const valorCasadinhaFloat = parseFloat(valorCasadinha);
                  if (valorCasadinhaFloat > 0) {
                    // valorCasadinhaFloat é o TOTAL do combo (ex.: 2 ingressos por R$55);
                    // como valorUtilizado é multiplicado por `grupos` mais abaixo, guardamos
                    // o valor equivalente "por grupo" para o total final fechar certo
                    const valorCasadinhaPorGrupo = valorCasadinhaFloat / grupos;
                    valoresValidos.push(valorCasadinhaPorGrupo);

                    // Valor casadinha sem taxa
                    if (semtaxa === true || evento.semtaxa === true || evento.semtaxapromocional === true) {
                      const valorCasadinhaSemTaxaTotal = Math.round((valorCasadinhaFloat / 1.10) * 100) / 100;
                      const valorCasadinhaSemTaxaPorGrupo = valorCasadinhaSemTaxaTotal / grupos;
                      if (valorCasadinhaSemTaxaPorGrupo > 0) {
                        valoresSemTaxa.push(valorCasadinhaSemTaxaPorGrupo);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }

      // Cada candidato guarda o valor aceito e o valor base (sem taxa), usado no cálculo do PIX
      const candidatos = valoresValidos.map(v => ({ valor: v, base: v / 1.10 }));

      // Aceitar também os valores convertidos para a taxa personalizada do evento
      if (temTaxaPersonalizada) {
        for (const v of valoresValidos) {
          candidatos.push({
            valor: Math.round((v / 1.10) * (1 + taxaPersonalizada / 100) * 100) / 100,
            base: v / 1.10
          });
        }
      }
      for (const v of valoresSemTaxa) {
        candidatos.push({ valor: v, base: v });
      }

      // Verificar se o valor recebido corresponde a algum valor válido
      let valorValido = false;
      let valorUtilizado = 0;
      let valorBaseUtilizado = 0;

      for (const candidato of candidatos) {
        if (Math.abs(valorbrutoRecebido - candidato.valor) <= 0.01) {
          valorValido = true;
          valorUtilizado = candidato.valor;
          valorBaseUtilizado = candidato.base;
          break;
        }
      }

      // Se nenhum valor foi validado, registrar erro
      if (!valorValido) {
        const valoresFormatados = candidatos.map(c =>
          `R$ ${c.valor.toFixed(2).replace('.', ',')}`
        );

        errosValidacao.push(
          `Valor incorreto para '${nometipo}': valores aceitos: ${valoresFormatados.join(', ')} | recebido: R$ ${valorbrutoRecebido.toFixed(2).replace('.', ',')}`
        );
        valorUtilizado = parseFloat(tipoNoEvento.valorbruto);
        valorBaseUtilizado = valorUtilizado / 1.10;
      }

      // Calcular valor total baseado no valor validado
      valorTotalCalculado += (valorUtilizado * grupos);
      valorBaseTotal += (valorBaseUtilizado * grupos);
    }

    // Verificar se o valor total enviado corresponde ao calculado
    if (Math.abs(valorTotalCalculado - total) > 0.01) {
      errosValidacao.push(
        `Valor total incorreto: esperado R$ ${valorTotalCalculado.toFixed(2).replace('.', ',')}, recebido R$ ${total.toFixed(2).replace('.', ',')}`
      );
    }

    // Se houver erros de validação, bloquear
    if (errosValidacao.length > 0) {
      // Registrar tentativa de fraude
      const logContent = {
        '🚨 TipoAlerta': 'TENTATIVA_MANIPULACAO_VALORES',
        '🕒 DataHora': new Date().toISOString(),
        '👤 CPF': cpf,
        '🎫 EventoID': eventid,
        '🏷️ Oferta': oferta || 'Nenhuma (compra normal)',
        '💰 ValorRecebido': total,
        '💰 ValorCalculado': valorTotalCalculado,
        '📊 TiposRecebidos': tiposArray,
        '📋 TiposValidados': tiposParaValidar,
        '⚠️ Erros': errosValidacao,
        '🌐 IP': req.ip || req.connection.remoteAddress || 'unknown',
        '📱 UserAgent': req.get('user-agent') || 'unknown'
      };

      logFraudAttempt(logContent);

      return res.json({
        success: false,
        message: 'Configuração incorreta, link encerrado ou evento com dados fornecidos inválidos para venda, contate o suporte'
      });
    }

    // 3. Verificar limite de compra por CPF
    if (evento.limitar && evento.limitar.limitarcompra === true) {
      const limite = parseInt(evento.limitar.limitedecompracpf || 0);
      if (limite > 0) {
        const comprados = await getFirebase(`users/cpf/${cpf}/ingressoscomprados`);
        let quantidadeComprada = 0;

        if (comprados && typeof comprados === 'object') {
          for (const item of Object.values(comprados)) {
            if (item.eventid === eventid) {
              quantidadeComprada += 1;
            }
          }
        }

        if ((quantidadeComprada + unt) > limite) {
          return res.json({
            success: false,
            message: `Limite de compra atingido: você já comprou ${quantidadeComprada} ingresso(s). Limite permitido: ${limite}.`
          });
        }
      }
    }

    // 4. Gerar cookie e salvar dados VALIDADOS no Firebase
    const cookie = generateCookie();
    const timestamp = new Date().toISOString();

    // Recriar tipos com valores validados do Firebase
    const tiposValidados = {};
    for (const tipoData of tiposArray) {
      const nometipo = tipoData.nometipo || '';
      const untTipo = parseInt(tipoData.unt || 0);
      const multiplicity = parseInt(tipoData.type || 1);

      // Buscar valor real nos tipos validados
      for (const tipo of tiposParaValidar) {
        if (tipo.nometipo === nometipo) {
          tiposValidados[nometipo] = {
            nometipo: nometipo,
            unt: untTipo,
            type: multiplicity,
            valorbruto: parseFloat(tipo.valorbruto)
          };
          break;
        }
      }
    }

    const payload = {
      eventid: eventid,
      timeout: 300,
      unt: unt,
      user: cpf,
      valortotal: valorTotalCalculado,
      paymentcompleted: false,
      generatedtoken: false,
      generatedtoken2: false,
      generatedtoken3: false,
      generatedtoken4: false,
      generatedtoken5: false,
      tipos: tiposValidados,
      timestamp: timestamp,
      comprasegura: false,
      valorcompraseguro: Math.round(valorTotalCalculado * 1.1 * 100) / 100 // valortotal + 10%
    };

    // Adicionar campos opcionais
    if ((evento.semtaxa === true) || (semtaxa === true)) {
      payload.semtaxa = true;
    }

    if (evento.semtaxapix === true) {
      payload.semtaxapix = true;
    }

    if (temTaxaPersonalizada) {
      payload.taxapersonalizada = taxaPersonalizada;
    }

    // Taxa personalizada do PIX: recalcula o total a partir do valor base (sem taxa)
    const taxaPersonalizadaPix = parseFloat(evento.taxapersonalizadapix);
    const temTaxaPersonalizadaPix = !isNaN(taxaPersonalizadaPix) && taxaPersonalizadaPix >= 0;
    if (temTaxaPersonalizadaPix) {
      payload.taxapersonalizadapix = taxaPersonalizadaPix;
      const valorTaxaPersonalizadaPix = Math.round(valorBaseTotal * (1 + taxaPersonalizadaPix / 100) * 100) / 100;
      payload.valortaxapersonalizadapix = valorTaxaPersonalizadaPix;
      payload.valorcompraseguropix = Math.round(valorTaxaPersonalizadaPix * 1.1 * 100) / 100; // valor PIX + 10%
    }

    if (oferta) {
      payload.oferta = oferta;
    }

    if (codaffiliate) {
      payload.codaffiliate = codaffiliate;
    }

    if (affiliate) {
      payload.affiliate = affiliate;
    }

    // Adicionar taxa adicional se presente
    if (taxaadicional === true) {
      payload.taxaadicional = 'true';
      const valorAdicionalFloat = parseFloat(taxaadicionalvalor) || 0;
      payload.taxaadicionalvalor = valorAdicionalFloat;
      payload.valortotaladicional = valorTotalCalculado + valorAdicionalFloat;
    }

    // Salvar no Firebase
    await putFirebase(`cookies/${cookie}`, payload);
    await putFirebase(`cookiesfixo/${cookie}`, payload);
    await putFirebase(`users/cpf/${cpf}/carrinhos/abertos/${eventid}`, {
      quantidade: unt,
      valortotal: valorTotalCalculado,
      tipos: tiposValidados,
      oferta: oferta || null,
      codaffiliate: codaffiliate || null,
      affiliate: affiliate || null,
      taxapersonalizada: payload.taxapersonalizada ?? null,
      taxapersonalizadapix: payload.taxapersonalizadapix ?? null,
      last_update: timestamp
    });

    // Retornar sucesso com o cookie
    return res.json({
      success: true,
      cookie: cookie
    });

  } catch (error) {
    console.error('Erro no prepararcheckout:', error);
    return res.status(500).json({
      success: false,
      message: 'Erro interno do servidor'
    });
  }
}
