import express from 'express';
import cors from 'cors';
import { prepararCheckoutHandler } from './prepararcheckout.js';

const app = express();
const PORT = process.env.PORT || 3005;

// Middlewares
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'OPTIONS'],
  allowedHeaders: ['Content-Type']
}));
app.use(express.json());

// Rotas
app.post('/prepararcheckout', prepararCheckoutHandler);

// Rota de teste
app.get('/', (req, res) => {
  res.json({status: 'online' });
});

app.listen(PORT, () => {
  console.log(`🚀 Servidor rodando na porta ${PORT}`);
  console.log(`📡 Endpoint: http://localhost:${PORT}/prepararcheckout`);
});
