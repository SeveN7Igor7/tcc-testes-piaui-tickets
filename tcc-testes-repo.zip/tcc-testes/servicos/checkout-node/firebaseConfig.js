// TESTE: em producao este arquivo escolhe entre os projetos Firebase "principal" e "reserva".
// No teste, usa apenas o banco de teste indicado em FIREBASE_DATABASE_URL (mesmo SDK cliente da producao).
import dns from "node:dns";
import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";

dns.setDefaultResultOrder("ipv4first");

const databaseURL = process.env.FIREBASE_DATABASE_URL;
if (!databaseURL) throw new Error("Defina FIREBASE_DATABASE_URL");
if (/piauidbtickets|piauiticketsdb/.test(databaseURL)) throw new Error("Banco de PRODUCAO. Abortado.");

const app = initializeApp({ databaseURL });
const database = getDatabase(app);
const bancoAtivo = "teste";
console.log(`🔥 Firebase ativo: ${bancoAtivo} (${databaseURL})`);

export { database, bancoAtivo };
