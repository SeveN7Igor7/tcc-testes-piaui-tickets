const firebaseService = require('../services/FirebaseService');

/**
 * Classe para validações centralizadas
 */
class ValidationService {
  /**
   * Valida dados do pagamento
   * @param {Object} paymentData - Dados do pagamento
   * @throws {Error} - Se dados inválidos
   */
  static validatePaymentData(paymentData) {
    if (!paymentData) {
      throw new Error('Dados do pagamento não encontrados');
    }

    const requiredFields = ['usercpf', 'codcarrinho', 'eventId'];
    const missingFields = requiredFields.filter(field => !paymentData[field]);

    if (missingFields.length > 0) {
      throw new Error(`Campos obrigatórios ausentes: ${missingFields.join(', ')}`);
    }

    return true;
  }

  /**
   * Valida quantidade de ingressos
   * @param {number} quantity - Quantidade
   * @throws {Error} - Se quantidade inválida
   */
  static validateTicketQuantity(quantity) {
    const qty = parseInt(quantity);

    if (isNaN(qty) || qty < 1) {
      throw new Error('Quantidade de ingressos deve ser maior que zero');
    }

    if (qty > 5) {
      throw new Error('Quantidade máxima de ingressos excedida (máximo: 5)');
    }

    return qty;
  }

  /**
   * Valida CPF (formato básico)
   * @param {string} cpf - CPF a validar
   * @returns {boolean}
   */
  static validateCPF(cpf) {
    if (!cpf || typeof cpf !== 'string') {
      return false;
    }

    // Remove caracteres não numéricos
    const cleanCPF = cpf.replace(/\D/g, '');

    // Verifica se tem 11 dígitos
    return cleanCPF.length === 11;
  }

  /**
   * Valida email (formato básico)
   * @param {string} email - Email a validar
   * @returns {boolean}
   */
  static validateEmail(email) {
    if (!email || typeof email !== 'string') {
      return false;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  /**
   * Valida se um token tem formato válido
   * @param {string} token - Token a validar
   * @returns {boolean}
   */
  static validateTokenFormat(token) {
    if (!token || typeof token !== 'string') {
      return false;
    }

    // Token deve ter ao menos 8 caracteres
    return token.length >= 8;
  }

  /**
   * Valida dados do evento
   * @param {Object} eventData - Dados do evento
   * @throws {Error} - Se evento inválido
   */
  static validateEventData(eventData) {
    if (!eventData) {
      throw new Error('Evento não encontrado');
    }

    if (!eventData.nomeevento) {
      throw new Error('Nome do evento não encontrado');
    }

    return true;
  }

  /**
   * Valida dados do usuário
   * @param {Object} userData - Dados do usuário
   * @throws {Error} - Se usuário inválido
   */
  static validateUserData(userData) {
    if (!userData) {
      throw new Error('Usuário não encontrado');
    }

    if (!userData.email || !this.validateEmail(userData.email)) {
      throw new Error('Email do usuário inválido ou ausente');
    }

    return true;
  }

  /**
   * Sanitiza string para prevenir injeções
   * @param {string} str - String a sanitizar
   * @returns {string}
   */
  static sanitizeString(str) {
    if (!str || typeof str !== 'string') {
      return '';
    }

    return str
      .replace(/[<>]/g, '') // Remove tags HTML
      .trim();
  }

  /**
   * Valida valor monetário
   * @param {number} value - Valor a validar
   * @returns {boolean}
   */
  static validateMonetaryValue(value) {
    const numValue = parseFloat(value);
    return !isNaN(numValue) && numValue >= 0;
  }
}

module.exports = ValidationService;
