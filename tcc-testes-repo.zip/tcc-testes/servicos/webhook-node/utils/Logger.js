const fs = require('fs');
const path = require('path');

class Logger {
  constructor() {
    this.logFile = path.join(__dirname, '../logs/webhook.log');
    this.ensureLogDirectory();
  }

  /**
   * Garante que o diretório de logs existe
   */
  ensureLogDirectory() {
    const logDir = path.dirname(this.logFile);
    if (!fs.existsSync(logDir)) {
      fs.mkdirSync(logDir, { recursive: true });
    }
  }

  /**
   * Formata a mensagem de log
   */
  formatMessage(level, message, data = null) {
    const timestamp = new Date().toISOString();
    let logMessage = `[${timestamp}] [${level}] ${message}`;
    
    if (data) {
      logMessage += ` | ${JSON.stringify(data)}`;
    }
    
    return logMessage;
  }

  /**
   * Escreve no arquivo de log
   */
  writeToFile(message) {
    try {
      fs.appendFileSync(this.logFile, message + '\n', 'utf8');
    } catch (error) {
      console.error('Erro ao escrever no arquivo de log:', error);
    }
  }

  /**
   * Log de informação
   */
  info(message, data = null) {
    const formattedMessage = this.formatMessage('INFO', message, data);
    console.log(formattedMessage);
    this.writeToFile(formattedMessage);
  }

  /**
   * Log de sucesso
   */
  success(message, data = null) {
    const formattedMessage = this.formatMessage('SUCESSO', message, data);
    console.log('\x1b[32m%s\x1b[0m', formattedMessage); // Verde
    this.writeToFile(formattedMessage);
  }

  /**
   * Log de erro
   */
  error(message, data = null) {
    const formattedMessage = this.formatMessage('ERRO', message, data);
    console.error('\x1b[31m%s\x1b[0m', formattedMessage); // Vermelho
    this.writeToFile(formattedMessage);
  }

  /**
   * Log de aviso
   */
  warning(message, data = null) {
    const formattedMessage = this.formatMessage('AVISO', message, data);
    console.warn('\x1b[33m%s\x1b[0m', formattedMessage); // Amarelo
    this.writeToFile(formattedMessage);
  }

  /**
   * Log de debug
   */
  debug(message, data = null) {
    if (process.env.NODE_ENV === 'development') {
      const formattedMessage = this.formatMessage('DEBUG', message, data);
      console.log('\x1b[36m%s\x1b[0m', formattedMessage); // Ciano
      this.writeToFile(formattedMessage);
    }
  }
}

module.exports = new Logger();
