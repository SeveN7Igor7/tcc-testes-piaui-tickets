const { Queue, Worker } = require('bullmq');
const { createBullBoard } = require('@bull-board/api');
const { BullMQAdapter } = require('@bull-board/api/bullMQAdapter');
const { ExpressAdapter } = require('@bull-board/express');
const logger = require('./utils/Logger');

// Configuração Redis
const redisConfig = {
  host: process.env.REDIS_HOST || 'localhost',
  port: process.env.REDIS_PORT || 6379,
  password: process.env.REDIS_PASSWORD || 'redis-teste'
};

// Função auxiliar para adicionar delay
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Função para realizar retry com tentativas e delay
async function retryWithDelay(fn, maxRetries = 5, delayMs = 3000, context = '') {
  let lastError;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      logger.info(`🔄 Tentativa ${attempt}/${maxRetries}${context ? ` - ${context}` : ''}`);
      const result = await fn();

      if (attempt > 1) {
        logger.success(`✅ Sucesso na tentativa ${attempt}/${maxRetries}${context ? ` - ${context}` : ''}`);
      }

      return result;
    } catch (error) {
      lastError = error;
      logger.warning(`⚠️ Tentativa ${attempt}/${maxRetries} falhou${context ? ` - ${context}` : ''}`, {
        error: error.message
      });

      if (attempt < maxRetries) {
        logger.info(`⏳ Aguardando ${delayMs/1000} segundos antes da próxima tentativa...`);
        await sleep(delayMs);
      }
    }
  }

  logger.error(`❌ Todas as ${maxRetries} tentativas falharam${context ? ` - ${context}` : ''}`, {
    error: lastError.message,
    stack: lastError.stack
  });

  throw lastError;
}

// TESTE: USAR_FILA=1 reproduz o estagio E4 (fila BullMQ no Redis, 1 por vez).
// USAR_FILA=0 reproduz o estagio E3: o webhook e processado logo apos a resposta, sem fila.
const USAR_FILA = process.env.USAR_FILA !== '0';
const fs = require('fs');
const ARQ_TEMPOS = process.env.ARQ_TEMPOS || '/registros/tempos_webhook.jsonl';
function registrarTempo(job, inicio, status) {
  const fim = Date.now();
  const chegada = job.data.recebidoEm || inicio;
  const linha = { hora: new Date(fim).toISOString(), paymentId: String(job.data.paymentId), metodo: job.data.paymentMethod,
    action: job.data.webhookData && job.data.webhookData.action, status, fila: USAR_FILA,
    espera_ms: inicio - chegada, processamento_ms: fim - inicio, total_ms: fim - chegada };
  try { fs.appendFileSync(ARQ_TEMPOS, JSON.stringify(linha) + '\n'); } catch (e) { /* ignora */ }
}

// Fila para processamento de webhooks
const webhookQueue = !USAR_FILA ? null : new Queue('webhook-processing', {
  connection: redisConfig,
  defaultJobOptions: {
    removeOnComplete: 50,
    removeOnFail: 100,
    attempts: 5, // Aumentado para 5 tentativas
    backoff: {
      type: 'exponential',
      delay: 5000, // Delay inicial de 5 segundos
    },
  },
});

// Worker para processar webhooks
const processarWebhook = async (job) => {
  const { paymentId, paymentMethod, webhookData } = job.data;
  const { action, type, data } = webhookData;

  logger.info(`🔄 Processando webhook na fila: ${paymentId} (${paymentMethod}) - Action: ${action}`);

  try {
    // Importar serviços necessários
    const firebaseService = require('./services/FirebaseService');
    const mercadopagoService = require('./services/MercadoPagoService');
    const ticketService = require('./services/TicketService');
    const emailService = require('./services/EmailService');
    const facebookConversionService = require('./services/FacebookConversionService');

    // Verificar se já foi processado
    const isProcessed = await checkIfProcessed(paymentId, firebaseService);
    if (isProcessed) {
      logger.warning(`⏭️ Pagamento ${paymentId} já processado anteriormente - Ignorando`);
      return { status: 'already_processed', paymentId };
    }

    // Buscar detalhes do pagamento no Mercado Pago
    logger.info(`🔍 Buscando detalhes do pagamento: ${paymentId} (${paymentMethod})`);
    const paymentDetails = await mercadopagoService.getPaymentDetails(paymentId, paymentMethod);
    const paymentInfo = mercadopagoService.extractPaymentInfo(paymentDetails);

    logger.info(`✅ Pagamento recuperado: ${paymentId} - Status: ${paymentInfo.status}`);
    logger.info('💳 Detalhes do pagamento', paymentInfo);

    // Processar baseado no action
    if (action === 'payment.created') {
      await handlePaymentCreated(paymentId, paymentInfo, firebaseService, emailService, ticketService, facebookConversionService, logger);
    } else if (action === 'payment.updated') {
      await handlePaymentUpdated(paymentId, paymentInfo, firebaseService, emailService, ticketService, facebookConversionService, logger);
    }

    logger.success(`✅ Webhook processado com sucesso: ${paymentId}`);
    return { status: 'processed', paymentId, action, paymentMethod };

  } catch (error) {
    logger.error(`❌ Erro ao processar webhook na fila: ${paymentId}`, {
      error: error.message,
      stack: error.stack
    });

    // Se for erro de dados não encontrados, pode ser retry útil
    if (error.message.includes('não encontrados') || error.message.includes('PAYMENT_NOT_FOUND')) {
      logger.warning(`⚠️ Dados do pagamento ${paymentId} ainda não disponíveis - será feito retry automático`);
    }

    throw error;
  }
};

// TESTE: mede espera na fila e tempo de processamento de cada webhook
async function processarMedido(job) {
  const inicio = Date.now();
  try { const r = await processarWebhook(job); registrarTempo(job, inicio, (r && r.status) || 'ok'); return r; }
  catch (e) { registrarTempo(job, inicio, 'erro'); throw e; }
}

const webhookWorker = !USAR_FILA ? null : new Worker('webhook-processing', processarMedido, {
  connection: redisConfig,
  concurrency: 1, // Processar 1 por vez
});

// TESTE (E3, sem fila): processa direto, sem esperar a vez, como antes da fila existir
const filaOuDireto = USAR_FILA ? webhookQueue : {
  add: async (nome, data) => { setImmediate(() => processarMedido({ id: 'direto', data }).catch(() => {})); return { id: 'direto' }; }
};

// Eventos do worker
if (webhookWorker) webhookWorker.on('completed', (job) => {
  logger.success(`✅ Job ${job.id} concluído: ${job.data.paymentId}`);
});

if (webhookWorker) webhookWorker.on('failed', (job, err) => {
  logger.error(`❌ Job ${job.id} falhou: ${job.data.paymentId}`, {
    error: err.message
  });
});

if (webhookWorker) webhookWorker.on('active', (job) => {
  logger.info(`🔄 Job ${job.id} iniciado: ${job.data.paymentId}`);
});

// Funções auxiliares para processamento de webhooks
async function checkIfProcessed(paymentId, firebaseService) {
  try {
    const pontesmpData = await firebaseService.get(`pontesmp/${paymentId}`);

    if (pontesmpData && pontesmpData.statuspayment === 'aprovada') {
      return true;
    }

    return false;
  } catch (error) {
    logger.error('❌ Erro ao verificar status do pagamento', { paymentId, error: error.message });
    return false;
  }
}

async function handlePaymentCreated(paymentId, paymentInfo, firebaseService, emailService, ticketService, facebookConversionService, logger) {
  try {
    logger.info('🆕 Pagamento criado', { paymentId, status: paymentInfo.status });

    // Verificar se existe no pontesmp
    let pontesmpData = await firebaseService.get(`pontesmp/${paymentId}`);

    if (pontesmpData) {
      // Se não estiver aprovado, marca como pendente
      if (paymentInfo.status !== 'approved') {
        // Buscar dados atuais ANTES de atualizar para não perder nada
        const currentData = await firebaseService.get(`pontesmp/${paymentId}`);
        const updatedData = {
          ...currentData,
          statuspayment: mapStatus(paymentInfo.status),
          updatedAt: new Date().toISOString()
        };
        await firebaseService.update(`pontesmp/${paymentId}`, updatedData);
        logger.info('⏳ Status do pagamento atualizado para pending', { paymentId, previousData: currentData });
      }

      // Enviar email informando status atual (evitar duplicar approved aqui)
      if (paymentInfo.status !== 'approved') {
        await emailService.sendPaymentStatusEmail({
          usercpf: pontesmpData.usercpf,
          eventid: pontesmpData.eventId,
          paymentId,
          status: paymentInfo.status,
          status_detail: paymentInfo.status_detail
        });
      }
    }

    // Se já estiver aprovado no momento da criação, processa
    if (paymentInfo.status === 'approved') {
      await processApprovedPayment(paymentId, paymentInfo, firebaseService, emailService, ticketService, facebookConversionService, logger);
    }

  } catch (error) {
    logger.error('❌ Erro ao processar pagamento criado', { paymentId, error: error.message });
    throw error;
  }
}

async function handlePaymentUpdated(paymentId, paymentInfo, firebaseService, emailService, ticketService, facebookConversionService, logger) {
  try {
    logger.info('🔄 Pagamento atualizado', { paymentId, status: paymentInfo.status });

    // Buscar dados básicos do pagamento para envio de email
    let pontesmpData = await firebaseService.get(`pontesmp/${paymentId}`);
    if (pontesmpData) {
      // Atualizar status refletindo status do MP
      if (paymentInfo.status !== 'approved') {
        // Buscar dados atuais ANTES de atualizar para não perder nada
        const currentData = await firebaseService.get(`pontesmp/${paymentId}`);
        const updatedData = {
          ...currentData,
          statuspayment: mapStatus(paymentInfo.status),
          updatedAt: new Date().toISOString()
        };
        await firebaseService.update(`pontesmp/${paymentId}`, updatedData);
        logger.info('⏳ Status do pagamento atualizado', { paymentId, fromStatus: currentData.statuspayment, toStatus: mapStatus(paymentInfo.status) });
      }

      // Evitar duplicar email de approved aqui; será enviado em processApprovedPayment
      if (paymentInfo.status !== 'approved') {
        await emailService.sendPaymentStatusEmail({
          usercpf: pontesmpData.usercpf,
          eventid: pontesmpData.eventId,
          paymentId,
          status: paymentInfo.status,
          status_detail: paymentInfo.status_detail
        });
      }
    }

    // Se foi aprovado, processa
    if (paymentInfo.status === 'approved') {
      await processApprovedPayment(paymentId, paymentInfo, firebaseService, emailService, ticketService, facebookConversionService, logger);
    } else {
      logger.info('⏳ Pagamento ainda não aprovado', {
        paymentId,
        status: paymentInfo.status,
        status_detail: paymentInfo.status_detail
      });
    }

  } catch (error) {
    logger.error('❌ Erro ao processar pagamento atualizado', { paymentId, error: error.message });
    throw error;
  }
}

async function processApprovedPayment(paymentId, paymentInfo, firebaseService, emailService, ticketService, facebookConversionService, logger) {
  try {
    logger.success('✅ Pagamento aprovado - Iniciando processamento', {
      paymentId,
      payment_method: paymentInfo.payment_method
    });

    // Buscar dados atuais ANTES de atualizar para não perder nada
    const currentData = await firebaseService.get(`pontesmp/${paymentId}`);
    
    if (!currentData) {
      throw new Error(`Dados do pagamento não encontrados para atualizar status: ${paymentId}`);
    }

    // Atualizar status no Firebase preservando todos os dados existentes
    const updatedData = {
      ...currentData,
      statuspayment: 'aprovada',
      approvedAt: new Date().toISOString(),
      approvedPaymentMethod: paymentInfo.payment_method
    };
    
    await firebaseService.update(`pontesmp/${paymentId}`, updatedData);

    logger.success('✅ Status atualizado para aprovada no Firebase', { 
      paymentId, 
      previousData: currentData,
      updatedData 
    });

    // Enviar conversão para Facebook Pixel (se configurado)
    try {
      const eventId = updatedData.eventId || currentData.eventId;
      if (eventId) {
        logger.info('🔍 Verificando configuração de Facebook Pixel para o evento', { eventId });
        
        // Buscar configurações do evento
        const eventData = await firebaseService.get(`eventos/${eventId}`);
        
        if (!eventData) {
          logger.warning('⚠️ Dados do evento não encontrados no Firebase', { eventId });
        } else {
          logger.info('🔍 DEBUG - Configurações do evento encontradas', {
            eventId,
            hasPixelFacebook: !!eventData.pixelfacebook,
            hasConversaoTokenApi: !!eventData.conversaotokenapi,
            pixelFacebookValue: eventData.pixelfacebook || 'null/undefined',
            conversaoTokenApiPreview: eventData.conversaotokenapi ? `${String(eventData.conversaotokenapi).substring(0, 20)}...` : 'null/undefined',
            allEventKeys: Object.keys(eventData)
          });
        }
        
        if (eventData && eventData.pixelfacebook && eventData.conversaotokenapi) {
          logger.info('📊 Evento configurado com Facebook Pixel - enviando conversão', {
            eventId,
            pixelId: eventData.pixelfacebook
          });

          // Preparar dados do pagamento para conversão
          const paymentDataForFb = {
            paymentId,
            amount: paymentInfo.transaction_amount || 0,
            quantity: currentData.qtdIngresso || 1,
            eventUrl: eventData.url || null
          };

          // Buscar dados completos do usuário no Firebase
          let userDataForFb = {
            email: currentData.useremail || null,
            cpf: currentData.usercpf || null,
            firstName: currentData.usernome ? currentData.usernome.split(' ')[0] : null,
            lastName: currentData.usernome ? currentData.usernome.split(' ').slice(1).join(' ') : null,
            phone: currentData.usertelefone || null,
            city: null,
            state: null,
            userAgent: null,
            clientIpAddress: null,
            fbp: currentData.fbp || null,
            fbc: currentData.fbc || null
          };

          // Buscar dados adicionais do usuário no nó /users/cpf/
          if (currentData.usercpf) {
            try {
              const cpfClean = currentData.usercpf.replace(/\D/g, '');
              const userFullData = await firebaseService.get(`users/cpf/${cpfClean}`);
              
              if (userFullData) {
                logger.info('🔍 Dados completos do usuário encontrados no Firebase', {
                  cpf: cpfClean,
                  hasEmail: !!userFullData.email,
                  hasTelefone: !!userFullData.telefone,
                  hasFullname: !!userFullData.fullname
                });

                // Atualizar com dados completos
                userDataForFb.email = userFullData.email || userDataForFb.email;
                userDataForFb.phone = userFullData.telefone || userDataForFb.phone;
                
                if (userFullData.fullname) {
                  const nameParts = userFullData.fullname.split(' ');
                  userDataForFb.firstName = nameParts[0] || userDataForFb.firstName;
                  userDataForFb.lastName = nameParts.slice(1).join(' ') || userDataForFb.lastName;
                }

                // Cookies Facebook (fbp e fbc) se disponíveis
                userDataForFb.fbp = userFullData.fbp || userDataForFb.fbp;
                userDataForFb.fbc = userFullData.fbc || userDataForFb.fbc;
              } else {
                logger.warning('⚠️ Dados do usuário não encontrados em /users/cpf/', { cpf: cpfClean });
              }
            } catch (userError) {
              logger.warning('⚠️ Erro ao buscar dados do usuário (continuando com dados disponíveis)', {
                error: userError.message
              });
            }
          }

          logger.info('🔍 DEBUG - Dados preparados para envio ao Facebook', {
            paymentDataForFb,
            userDataForFb
          });

          // Enviar conversão
          const fbResult = await facebookConversionService.sendConversion(
            { 
              pixelfacebook: eventData.pixelfacebook, 
              conversaotokenapi: eventData.conversaotokenapi 
            },
            paymentDataForFb,
            userDataForFb
          );

          logger.info('🔍 DEBUG - Resultado do envio Facebook', {
            fbResult
          });

          if (fbResult.success) {
            logger.success('✅ Conversão Facebook enviada com sucesso', {
              paymentId,
              eventId,
              fbtrace_id: fbResult.fbtrace_id
            });
          } else {
            logger.warning('⚠️ Conversão Facebook não enviada', {
              paymentId,
              eventId,
              reason: fbResult.reason || fbResult.error,
              fullResult: fbResult
            });
          }
        } else {
          logger.info('⏭️ Evento não configurado com Facebook Pixel - ignorando conversão', { 
            eventId,
            hasPixelId: !!(eventData && eventData.pixelfacebook),
            hasToken: !!(eventData && eventData.conversaotokenapi)
          });
        }
      }
    } catch (fbError) {
      // Erro no Facebook não deve interromper o processamento
      logger.error('❌ Erro ao enviar conversão Facebook (ignorando e continuando)', {
        paymentId,
        error: fbError.message
      });
    }

    // Processar ingressos com retry (caso dados ainda não estejam no Firebase)
    const ticketResult = await retryWithDelay(
      async () => {
        // Buscar dados do pontesmp com validação
        const pontesmpData = await firebaseService.get(`pontesmp/${paymentId}`);

        if (!pontesmpData) {
          throw new Error(`Dados do pagamento não encontrados no Firebase: ${paymentId}`);
        }

        const { usercpf, codcarrinho, eventId } = pontesmpData;

        // Validar campos obrigatórios
        if (!usercpf || !codcarrinho || !eventId) {
          throw new Error(`Campos obrigatórios ausentes (usercpf, codcarrinho ou eventId) para pagamento ${paymentId}`);
        }

        // Se chegou aqui, os dados estão completos, processar tickets
        const result = await ticketService.processTickets(paymentId, paymentInfo.payment_method);

        return { pontesmpData, result };
      },
      10, // 10 tentativas
      4000, // 4 segundos de delay
      `Processamento de tickets para pagamento ${paymentId}`
    );

    // Enviar email com os ingressos (QR code + token) já que foram salvos e processados
    const pontesmpData = await firebaseService.get(`pontesmp/${paymentId}`);
    const ticketsForEmail = ticketResult?.result?.tickets || [];

    if (pontesmpData && pontesmpData.usercpf && pontesmpData.eventId) {
      if (ticketsForEmail.length > 0) {
        const emailEnviado = await emailService.sendTicketsEmail({
          usercpf: pontesmpData.usercpf,
          eventid: pontesmpData.eventId,
          paymentId,
          tickets: ticketsForEmail
        });

        if (emailEnviado) {
          logger.success('📧 Email com ingressos (QR code + token) enviado ao usuário', {
            paymentId,
            quantidade: ticketsForEmail.length
          });
        } else {
          logger.warning('⚠️ Falha ao enviar email com ingressos - enviando email de status como fallback', { paymentId });
          // Fallback: ao menos notificar a aprovação
          await emailService.sendPaymentStatusEmail({
            usercpf: pontesmpData.usercpf,
            eventid: pontesmpData.eventId,
            paymentId,
            status: 'approved',
            status_detail: paymentInfo.status_detail
          });
        }
      } else {
        // Sem tickets retornados (ex.: já processado em execução anterior) - envia email de status
        logger.warning('⚠️ Nenhum ingresso retornado para email - enviando email de status de aprovação', { paymentId });
        await emailService.sendPaymentStatusEmail({
          usercpf: pontesmpData.usercpf,
          eventid: pontesmpData.eventId,
          paymentId,
          status: 'approved',
          status_detail: paymentInfo.status_detail
        });
      }
    } else {
      logger.warning('⚠️ Não foi possível enviar email - dados incompletos no Firebase', { paymentId });
    }

    logger.success('🎉 Processamento completo do pagamento concluído', { paymentId });

  } catch (error) {
    logger.error('❌ Erro ao processar pagamento aprovado', {
      paymentId,
      error: error.message,
      stack: error.stack
    });
    throw error;
  }
}

function mapStatus(status) {
  switch (status) {
    case 'approved':
      return 'aprovada';
    case 'pending':
    case 'in_process':
    case 'in_mediation':
    case 'authorized':
      return 'pending';
    case 'rejected':
    case 'cancelled':
    case 'refunded':
    case 'charged_back':
      return 'rejeitada';
    default:
      return String(status || 'pending');
  }
}

// Bull Board para monitoramento
const serverAdapter = new ExpressAdapter();
serverAdapter.setBasePath('/admin/queues');

const { add, remove, setQueues, replaceQueues } = createBullBoard({
  queues: USAR_FILA ? [new BullMQAdapter(webhookQueue)] : [],
  serverAdapter: serverAdapter,
});

module.exports = {
  webhookQueue: filaOuDireto,
  webhookWorker,
  serverAdapter,
  addQueueToBullBoard: (queue) => add(new BullMQAdapter(queue)),
  removeQueueFromBullBoard: (queue) => remove(new BullMQAdapter(queue))
};