/**
 * Constantes do sistema
 */

// Limites de quantidade
const TICKET_LIMITS = {
  MIN: 1,
  MAX: 5
};

// Métodos de pagamento
const PAYMENT_METHODS = {
  CREDIT_CARD: 'CARTÃO',
  PIX: 'PIX',
  DEBIT_CARD: 'CARTÃO',
  UNKNOWN: 'DESCONHECIDO'
};

// Status de pagamento
const PAYMENT_STATUS = {
  PENDING: 'pending',
  APPROVED: 'approved',
  REJECTED: 'rejected',
  CANCELLED: 'cancelled',
  REFUNDED: 'refunded',
  IN_PROCESS: 'in_process'
};

// Status interno do sistema
const INTERNAL_PAYMENT_STATUS = {
  PENDING: 'pending',
  APPROVED: 'aprovada',
  REJECTED: 'rejeitada'
};

// Caminhos do Firebase
const FIREBASE_PATHS = {
  PONTESMP: 'pontesmp',
  COOKIES: 'cookies',
  COOKIES_FIXO: 'cookiesfixo',
  INGRESSOS: 'ingressos',
  DISPONIVEIS: 'disponiveis',
  USERS: 'users',
  CPF: 'cpf',
  INGRESSOS_COMPRADOS: 'ingressoscomprados',
  EVENTOS: 'eventos',
  EMPRESAS: 'empresas',
  VENDAS: 'vendas',
  VENDAS_REALIZADAS: 'vendasrealizadas',
  SALDO_DISPONIVEL: 'saldo_disponivel'
};

// Configurações de retry
const RETRY_CONFIG = {
  MAX_TOKEN_GENERATION_ATTEMPTS: 5,
  RETRY_DELAY_MS: 1000
};

// Taxas e descontos
const FEES = {
  COMPANY_DISCOUNT: 0.10 // 10% de desconto
};

// Mensagens de erro
const ERROR_MESSAGES = {
  PAYMENT_NOT_FOUND: 'Dados do pagamento não encontrados',
  INVALID_QUANTITY: 'Quantidade de ingressos inválida',
  TOKEN_EXISTS: 'Token já existe no banco de dados',
  TOKEN_GENERATION_FAILED: 'Falha ao gerar token único',
  MISSING_REQUIRED_FIELDS: 'Campos obrigatórios ausentes',
  EVENT_NOT_FOUND: 'Evento não encontrado',
  USER_NOT_FOUND: 'Usuário não encontrado',
  COMPANY_NOT_FOUND: 'Empresa não encontrada',
  EMAIL_SEND_FAILED: 'Falha ao enviar email',
  FIREBASE_ERROR: 'Erro ao acessar Firebase',
  MERCADOPAGO_ERROR: 'Erro ao acessar API do Mercado Pago'
};

// Mensagens de sucesso
const SUCCESS_MESSAGES = {
  PAYMENT_PROCESSED: 'Pagamento processado com sucesso',
  TICKETS_CREATED: 'Ingressos criados com sucesso',
  EMAIL_SENT: 'Email enviado com sucesso',
  TOKENS_VERIFIED: 'Tokens verificados com sucesso'
};

// Timeouts (em milissegundos)
const TIMEOUTS = {
  HTTP_REQUEST: 30000, // 30 segundos
  TOKEN_GENERATION: 10000, // 10 segundos
  FIREBASE_OPERATION: 15000 // 15 segundos
};

// Tipos de log
const LOG_LEVELS = {
  INFO: 'INFO',
  SUCCESS: 'SUCESSO',
  ERROR: 'ERRO',
  WARNING: 'AVISO',
  DEBUG: 'DEBUG'
};

module.exports = {
  TICKET_LIMITS,
  PAYMENT_METHODS,
  PAYMENT_STATUS,
  INTERNAL_PAYMENT_STATUS,
  FIREBASE_PATHS,
  RETRY_CONFIG,
  FEES,
  ERROR_MESSAGES,
  SUCCESS_MESSAGES,
  TIMEOUTS,
  LOG_LEVELS
};
