const express = require('express');
const router = express.Router();
const firebaseService = require('../services/FirebaseService');
const mercadopagoService = require('../services/MercadoPagoService');
const logger = require('../utils/Logger');
const emailService = require('../services/EmailService');
const { webhookQueue } = require('../queue');

/**
 * Função auxiliar para adicionar delay
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Função para realizar retry com tentativas e delay
 * @param {Function} fn - Função async a ser executada
 * @param {number} maxRetries - Número máximo de tentativas (padrão: 5)
 * @param {number} delayMs - Delay entre tentativas em ms (padrão: 3000)
 * @param {string} context - Contexto para logging
 */
async function retryWithDelay(fn, maxRetries = 5, delayMs = 3000, context = '') {
  let lastError;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      logger.info(`🔄 Tentativa ${attempt}/${maxRetries}${context ? ` - ${context}` : ''}`);
      const result = await fn();
      
      if (attempt > 1) {
        logger.success(`✅ Sucesso na tentativa ${attempt}/${maxRetries}${context ? ` - ${context}` : ''}`);
      }
      
      return result;
    } catch (error) {
      lastError = error;
      logger.warning(`⚠️ Tentativa ${attempt}/${maxRetries} falhou${context ? ` - ${context}` : ''}`, {
        error: error.message
      });
      
      if (attempt < maxRetries) {
        logger.info(`⏳ Aguardando ${delayMs/1000} segundos antes da próxima tentativa...`);
        await sleep(delayMs);
      }
    }
  }
  
  logger.error(`❌ Todas as ${maxRetries} tentativas falharam${context ? ` - ${context}` : ''}`, {
    error: lastError.message,
    stack: lastError.stack
  });
  
  throw lastError;
}

/**
 * Webhook para pagamentos via PIX
 * Endpoint: POST /webhook/pix
 */
router.post('/pix', async (req, res) => {
  try {
    logger.info('🚀 Webhook PIX recebido');
    
    // Validar dados recebidos
    const { action, type, data } = req.body;
    
    if (!action || !type || !data || !data.id) {
      logger.warning('⚠️ Dados incompletos no webhook PIX', req.body);
      return res.status(400).json({ error: 'Dados incompletos' });
    }
    
    // Responder imediatamente ao Mercado Pago
    res.status(200).json({ status: 'received' });
    
    // Processar apenas eventos de pagamento
    if (type !== 'payment') {
      logger.info('ℹ️ Tipo de evento ignorado (não é pagamento)', { type });
      return;
    }
    
    const paymentId = data.id;
    
    logger.info('📋 Adicionando pagamento PIX à fila', { 
      paymentId, 
      action, 
      type 
    });
    
    // Adicionar à fila para processamento (todas as verificações ficam no worker)
    await webhookQueue.add('process-payment', {
      paymentId,
      paymentMethod: 'pix',
      webhookData: req.body,
      recebidoEm: Date.now() // TESTE: medir espera e tempo total
    });
    
    logger.info('✅ Pagamento PIX adicionado à fila', { paymentId });
    
  } catch (error) {
    logger.error('❌ Erro ao adicionar webhook PIX à fila', {
      error: error.message,
      stack: error.stack
    });
  }
});

/**
 * Webhook para pagamentos via Cartão
 * Endpoint: POST /webhook/cartao
 */
router.post('/cartao', async (req, res) => {
  try {
    logger.info('🚀 Webhook CARTÃO recebido');
    
    // Validar dados recebidos
    const { action, type, data } = req.body;
    
    if (!action || !type || !data || !data.id) {
      logger.warning('⚠️ Dados incompletos no webhook CARTÃO', req.body);
      return res.status(400).json({ error: 'Dados incompletos' });
    }
    
    // Responder imediatamente ao Mercado Pago
    res.status(200).json({ status: 'received' });
    
    // Processar apenas eventos de pagamento
    if (type !== 'payment') {
      logger.info('ℹ️ Tipo de evento ignorado (não é pagamento)', { type });
      return;
    }
    
    const paymentId = data.id;
    
    logger.info('📋 Adicionando pagamento CARTÃO à fila', { 
      paymentId, 
      action, 
      type 
    });
    
    // Adicionar à fila para processamento (todas as verificações ficam no worker)
    await webhookQueue.add('process-payment', {
      paymentId,
      paymentMethod: 'cartao',
      webhookData: req.body,
      recebidoEm: Date.now() // TESTE: medir espera e tempo total
    });
    
    logger.info('✅ Pagamento CARTÃO adicionado à fila', { paymentId });
    
  } catch (error) {
    logger.error('❌ Erro ao adicionar webhook CARTÃO à fila', {
      error: error.message,
      stack: error.stack
    });
  }
});

module.exports = router;
