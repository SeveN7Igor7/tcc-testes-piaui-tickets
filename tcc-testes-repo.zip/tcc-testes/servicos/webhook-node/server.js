require('dotenv').config();
const crypto = require('crypto');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const webhookRoutes = require('./routes/webhook');
const logger = require('./utils/Logger');
const { serverAdapter } = require('./queue');

const app = express();
const PORT = process.env.PORT || 3000;

// Middlewares de segurança
app.use(helmet());

// CORS - permitir requisições de qualquer origem
app.use(cors());

// Body parser - aumentar limite para receber webhooks grandes
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Middleware de logging de requisições
app.use((req, res, next) => {
  logger.info(`📨 ${req.method} ${req.path}`, {
    ip: req.ip,
    userAgent: req.get('user-agent')
  });
  next();
});

// Rota de health check
app.get('/', (req, res) => {
  res.json({
    status: 'online',
    message: 'Nem invente amigo :) Coletado',
    version: '1.0.2',
    timestamp: new Date().toISOString()
  });
});

// Rota de health check específica
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    timestamp: new Date().toISOString()
  });
});

// Rotas de webhook
app.use('/webhook', webhookRoutes);

// Autenticação básica para o painel de monitoramento de filas
function queueBasicAuth(req, res, next) {
  const expectedUser = process.env.QUEUE_ADMIN_USER;
  const expectedPass = process.env.QUEUE_ADMIN_PASSWORD;

  if (!expectedUser || !expectedPass) {
    logger.error('❌ QUEUE_ADMIN_USER/QUEUE_ADMIN_PASSWORD não configurados - bloqueando acesso ao painel de filas');
    return res.status(503).send('Painel de filas indisponível: credenciais de acesso não configuradas.');
  }

  const header = req.headers.authorization || '';
  const [scheme, encoded] = header.split(' ');

  if (scheme === 'Basic' && encoded) {
    const decoded = Buffer.from(encoded, 'base64').toString('utf8');
    const separatorIndex = decoded.indexOf(':');
    const user = decoded.slice(0, separatorIndex);
    const pass = decoded.slice(separatorIndex + 1);

    const userBuf = Buffer.from(user);
    const expectedUserBuf = Buffer.from(expectedUser);
    const passBuf = Buffer.from(pass);
    const expectedPassBuf = Buffer.from(expectedPass);

    const userMatches = userBuf.length === expectedUserBuf.length &&
      crypto.timingSafeEqual(userBuf, expectedUserBuf);
    const passMatches = passBuf.length === expectedPassBuf.length &&
      crypto.timingSafeEqual(passBuf, expectedPassBuf);

    if (userMatches && passMatches) {
      return next();
    }
  }

  logger.warning('⚠️ Tentativa de acesso não autorizado ao painel de filas', { ip: req.ip });
  res.set('WWW-Authenticate', 'Basic realm="Filas"');
  return res.status(401).send('Autenticação necessária.');
}

// Rotas do Bull Board (monitoramento de filas)
app.use('/admin/queues', queueBasicAuth, serverAdapter.getRouter());

// Middleware de tratamento de erros 404
app.use((req, res) => {
  logger.warning('⚠️ Rota não encontrada', { path: req.path, method: req.method });
  res.status(404).json({
    error: 'Rota não encontrada',
    path: req.path
  });
});

// Middleware de tratamento de erros global
app.use((err, req, res, next) => {
  logger.error('❌ Erro no servidor', {
    error: err.message,
    stack: err.stack,
    path: req.path
  });
  
  res.status(500).json({
    error: 'Erro interno do servidor',
    message: process.env.NODE_ENV === 'development' ? err.message : 'Erro ao processar requisição'
  });
});

// Iniciar servidor
app.listen(PORT, () => {
  logger.success(`🚀 Servidor rodando na porta ${PORT}`);
  logger.info(`📍 Ambiente: ${process.env.NODE_ENV || 'production'}`);
  logger.info(`🌐 Endpoints disponíveis:`);
  logger.info(`   GET  /              - Status do servidor`);
  logger.info(`   GET  /health        - Health check`);
  logger.info(`   POST /webhook/pix   - Webhook para pagamentos PIX`);
  logger.info(`   POST /webhook/cartao - Webhook para pagamentos com Cartão`);
});

// Tratamento de erros não capturados
process.on('uncaughtException', (error) => {
  logger.error('❌ Exceção não capturada', {
    error: error.message,
    stack: error.stack
  });
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('❌ Promise rejection não tratada', {
    reason: reason,
    promise: promise
  });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  logger.info('🛑 SIGTERM recebido, encerrando servidor...');
  process.exit(0);
});

process.on('SIGINT', () => {
  logger.info('🛑 SIGINT recebido, encerrando servidor...');
  process.exit(0);
});

module.exports = app;
