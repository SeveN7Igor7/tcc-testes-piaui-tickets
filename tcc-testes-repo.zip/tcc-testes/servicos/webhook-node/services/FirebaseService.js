// TESTE: em producao este servico usa o firebase-admin com a chave de conta de servico do projeto.
// No teste, o banco de teste tem regras abertas e nao ha chave de servico, entao usamos o SDK cliente
// do Firebase, que tambem mantem uma conexao persistente (WebSocket) com o Realtime Database.
// A interface (get, set, update, remove, push) e a mesma do servico original.
const { initializeApp } = require('firebase/app');
const { getDatabase, ref, get, set, update, remove, push } = require('firebase/database');

class FirebaseService {
  constructor() {
    const databaseURL = process.env.FIREBASE_DATABASE_URL;
    if (!databaseURL) throw new Error('Defina FIREBASE_DATABASE_URL');
    if (/piauidbtickets|piauiticketsdb/.test(databaseURL)) throw new Error('Banco de PRODUCAO. Abortado.');
    this.db = getDatabase(initializeApp({ databaseURL }));
    console.log('✅ Firebase (banco de teste) inicializado');
  }

  async get(path) { const s = await get(ref(this.db, path)); return s.exists() ? s.val() : null; }
  async set(path, data) { await set(ref(this.db, path), data); return true; }
  async update(path, data) { await update(ref(this.db, path), data); return true; }
  async remove(path) { await remove(ref(this.db, path)); return true; }
  async push(path, data) { const r = await push(ref(this.db, path), data); return r.key; }
}

module.exports = new FirebaseService();
