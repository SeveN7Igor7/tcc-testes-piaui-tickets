const firebaseService = require('./FirebaseService');

class TokenService {
  constructor() {
    this.maxRetries = 5; // Máximo de tentativas para gerar token único
  }

  /**
   * Gera um único token localmente
   * Formato: 7 letras + 3 números embaralhados (total: 10 caracteres)
   */
  generateToken() {
    try {
      const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      const numbers = '0123456789';
      
      // Gerar 7 letras aleatórias
      let randomLetters = '';
      for (let i = 0; i < 7; i++) {
        randomLetters += letters.charAt(Math.floor(Math.random() * letters.length));
      }
      
      // Gerar 3 números aleatórios
      let randomNumbers = '';
      for (let i = 0; i < 3; i++) {
        randomNumbers += numbers.charAt(Math.floor(Math.random() * numbers.length));
      }
      
      // Combinar e embaralhar
      const combined = randomLetters + randomNumbers;
      const codeArray = combined.split('');
      
      // Embaralhar usando Fisher-Yates shuffle
      for (let i = codeArray.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [codeArray[i], codeArray[j]] = [codeArray[j], codeArray[i]];
      }
      
      const token = codeArray.join('');
      console.log(`🎟️ Token gerado: ${token.substring(0, 8)}...`);
      return token;
    } catch (error) {
      console.error('❌ Erro ao gerar token:', error.message);
      throw error;
    }
  }

  /**
   * Verifica se um token já existe no banco de dados
   * @param {string} token - Token a ser verificado
   * @param {string} eventid - ID do evento
   * @returns {boolean} - True se o token já existe
   */
  async tokenExists(token, eventid) {
    try {
      // Verificar em ingressos disponíveis
      const ingressosData = await firebaseService.get(`ingressos/${eventid}/disponiveis/${token}`);
      if (ingressosData) {
        console.log(`⚠️ Token ${token.substring(0, 8)}... já existe em ingressos/disponiveis`);
        return true;
      }

      // Verificar em todos os usuários (busca geral)
      const usersData = await firebaseService.get(`users`);
      if (usersData) {
        for (const cpf in usersData) {
          const ingressosComprados = usersData[cpf]?.ingressoscomprados;
          if (ingressosComprados && ingressosComprados[token]) {
            console.log(`⚠️ Token ${token.substring(0, 8)}... já existe em users/cpf/${cpf}/ingressoscomprados`);
            return true;
          }
        }
      }

      // Verificar em vendas de empresas
      const empresasData = await firebaseService.get(`empresas`);
      if (empresasData) {
        for (const empresaId in empresasData) {
          const vendas = empresasData[empresaId]?.vendas?.vendasrealizadas;
          if (vendas && vendas[eventid] && vendas[eventid][token]) {
            console.log(`⚠️ Token ${token.substring(0, 8)}... já existe em empresas/${empresaId}/vendas`);
            return true;
          }
        }
      }

      return false;
    } catch (error) {
      console.error('❌ Erro ao verificar existência do token:', error.message);
      // Em caso de erro, retorna false para não bloquear o processo
      return false;
    }
  }

  /**
   * Gera um token único (que não existe no banco)
   * @param {string} eventid - ID do evento
   * @returns {string} - Token único gerado
   */
  async generateUniqueToken(eventid) {
    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      const token = this.generateToken();
      
      const exists = await this.tokenExists(token, eventid);
      
      if (!exists) {
        console.log(`✅ Token único gerado na tentativa ${attempt}: ${token.substring(0, 8)}...`);
        return token;
      }
      
      console.log(`🔄 Token duplicado encontrado, tentativa ${attempt}/${this.maxRetries}`);
    }
    
    throw new Error(`Não foi possível gerar token único após ${this.maxRetries} tentativas`);
  }

  /**
   * Gera múltiplos tokens únicos
   * @param {number} quantity - Quantidade de tokens
   * @param {string} eventid - ID do evento
   * @returns {Array<string>} - Array de tokens únicos
   */
  async generateUniqueTokens(quantity, eventid) {
    try {
      console.log(`🎫 Gerando ${quantity} tokens únicos para evento ${eventid}...`);
      
      const tokens = [];
      const generatedTokensSet = new Set(); // Para evitar duplicatas no mesmo lote
      
      for (let i = 0; i < quantity; i++) {
        let token;
        let isUnique = false;
        
        while (!isUnique) {
          token = await this.generateUniqueToken(eventid);
          
          // Verificar se não foi gerado no mesmo lote
          if (!generatedTokensSet.has(token)) {
            generatedTokensSet.add(token);
            isUnique = true;
          } else {
            console.log(`🔄 Token duplicado no mesmo lote, gerando novo...`);
          }
        }
        
        tokens.push(token);
        console.log(`📍 Token ${i + 1}/${quantity} gerado: ${token.substring(0, 8)}...`);
      }
      
      console.log(`✅ ${tokens.length} tokens únicos gerados com sucesso`);
      return tokens;
    } catch (error) {
      console.error('❌ Erro ao gerar múltiplos tokens únicos:', error.message);
      throw error;
    }
  }

  /**
   * Cria uma lista plana de tipos de tokens baseada nas quantidades especificadas
   * 
   * @param {Object} tiposData - Dados dos tipos no formato: {"Feminino": {"nometipo": "Feminino", "unt": 2}, "Masculino": {"nometipo": "Masculino", "unt": 3}}
   * @returns {Array} Lista plana de tipos: ["Feminino", "Feminino", "Masculino", "Masculino", "Masculino"]
   */
  createTokenTypesList(tiposData) {
    const tokenTypesList = [];
    
    if (!tiposData || typeof tiposData !== 'object') {
      console.warn('⚠️ Dados de tipos não encontrados ou inválidos, usando tipo padrão');
      return ['Padrão'];
    }
    
    console.log('📋 Processando tipos de tokens:', tiposData);
    
    // Iterar sobre cada tipo e adicionar à lista baseado na quantidade
    for (const [tipoKey, tipoInfo] of Object.entries(tiposData)) {
      if (!tipoInfo || !tipoInfo.nometipo || typeof tipoInfo.unt !== 'number') {
        console.warn(`⚠️ Dados de tipo inválidos para ${tipoKey}:`, tipoInfo);
        continue;
      }
      
      const nometipo = tipoInfo.nometipo;
      const quantidade = tipoInfo.unt;
      
      console.log(`📌 Tipo: ${nometipo} - Quantidade: ${quantidade}`);
      
      // Adicionar o tipo à lista o número de vezes especificado pela quantidade
      for (let i = 0; i < quantidade; i++) {
        tokenTypesList.push(nometipo);
      }
    }
    
    if (tokenTypesList.length === 0) {
      console.warn('⚠️ Nenhum tipo válido encontrado, usando tipo padrão');
      return ['Padrão'];
    }
    
    console.log(`✅ Lista de tipos criada: ${tokenTypesList.length} itens`, tokenTypesList);
    return tokenTypesList;
  }
}

module.exports = new TokenService();
