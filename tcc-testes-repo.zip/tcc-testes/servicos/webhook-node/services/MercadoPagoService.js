const axios = require('axios');

class MercadoPagoService {
  constructor() {
    this.accessTokenPix = process.env.MERCADOPAGO_ACCESS_TOKEN_PIX;
    this.accessTokenCartao = process.env.MERCADOPAGO_ACCESS_TOKEN_CARTAO;
    this.apiUrl = (process.env.MP_API_URL || 'https://api.mercadopago.com') + '/v1/payments'; // TESTE: Mercado Pago simulado
  }

  /**
   * Busca detalhes de um pagamento pelo ID
   * @param {string} paymentId - ID do pagamento
   * @param {string} paymentType - Tipo de pagamento ('pix' ou 'cartao')
   */
  async getPaymentDetails(paymentId, paymentType = 'cartao') {
    try {
      console.log(`🔍 Buscando detalhes do pagamento: ${paymentId} (${paymentType.toUpperCase()})`);
      
      // Selecionar token baseado no tipo
      const accessToken = paymentType === 'pix' ? this.accessTokenPix : this.accessTokenCartao;
      
      const response = await axios.get(`${this.apiUrl}/${paymentId}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        timeout: 30000
      });

      console.log(`✅ Pagamento recuperado: ${paymentId} - Status: ${response.data.status}`);
      return response.data;
    } catch (error) {
      console.error(`❌ Erro ao buscar pagamento ${paymentId}:`, error.message);
      throw error;
    }
  }

  /**
   * Verifica se um pagamento foi aprovado
   */
  isPaymentApproved(paymentData) {
    return paymentData.status === 'approved';
  }

  /**
   * Obtém o método de pagamento
   */
  getPaymentMethod(paymentData) {
    const paymentType = paymentData.payment_type_id;
    
    if (paymentType === 'credit_card' || paymentType === 'debit_card') {
      return 'CARTÃO';
    } else if (paymentType === 'bank_transfer') {
      return 'PIX';
    }
    
    return paymentType ? paymentType.toUpperCase() : 'DESCONHECIDO';
  }

  /**
   * Extrai informações relevantes do pagamento
   */
  extractPaymentInfo(paymentData) {
    return {
      id: paymentData.id,
      status: paymentData.status,
      status_detail: paymentData.status_detail,
      payment_method: this.getPaymentMethod(paymentData),
      payment_type_id: paymentData.payment_type_id,
      transaction_amount: paymentData.transaction_amount,
      date_created: paymentData.date_created,
      date_approved: paymentData.date_approved,
      payer_email: paymentData.payer?.email,
      payer_identification: paymentData.payer?.identification,
      external_reference: paymentData.external_reference,
      description: paymentData.description
    };
  }
}

module.exports = new MercadoPagoService();
