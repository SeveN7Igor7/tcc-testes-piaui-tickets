const firebaseService = require('./FirebaseService');
const tokenService = require('./TokenService');
const emailService = require('./EmailService');
const ValidationService = require('../utils/ValidationService');
const { 
  TICKET_LIMITS, 
  FIREBASE_PATHS,
  ERROR_MESSAGES,
  SUCCESS_MESSAGES 
} = require('../config/constants');

class TicketService {
  /**
   * Processa ingressos para um pagamento aprovado
   */
  async processTickets(paymentId, paymentMethod) {
    try {
      console.log(`🎫 Processando ingressos para pagamento: ${paymentId}`);
      
      // 1. Validar e buscar dados do pagamento
      const paymentData = await this.getPaymentData(paymentId);
      const { usercpf, codcarrinho, eventid } = paymentData;
      
      console.log(`📊 Dados: CPF=${usercpf}, Carrinho=${codcarrinho}, Evento=${eventid}`);
      
      // 2. Buscar e validar quantidade de ingressos
      const untValue = await this.getTicketQuantity(codcarrinho);
      console.log(`📈 Quantidade de ingressos: ${untValue}`);
      
      // 3. Gerar tokens únicos (sem duplicatas)
      const tokens = await tokenService.generateUniqueTokens(untValue, eventid);
      
      // 4. Buscar tipos de tokens e criar lista plana
      const tiposData = await firebaseService.get(`cookiesfixo/${codcarrinho}/tipos`);
      const tokenTypesList = tokenService.createTokenTypesList(tiposData);
      
      // 5. Atualizar tokens no Firebase (cookiesfixo)
      await this.updateTokensInFirebase(codcarrinho, tokens, tokenTypesList);
      
      // 6. Processar cada token nos 3 caminhos
      await this.saveAllTickets(eventid, usercpf, codcarrinho, tokens, tokenTypesList, paymentMethod, paymentId);
      
      console.log(`✅ ${tokens.length} ingressos processados com sucesso`);
      
      // 7. Verificar integridade dos tokens
      await this.verifyTokensInPaths(eventid, usercpf, tokens);

      // Montar lista de ingressos (token + tipo) para envio de email
      const tickets = tokens.map((token, index) => ({
        token,
        tipo: tokenTypesList[index] || tokenTypesList[0] || 'Padrão'
      }));

      return { usercpf, eventid, codcarrinho, tokens, tokenTypesList, tickets };
    } catch (error) {
      console.error('❌ Erro ao processar ingressos:', error);
      throw error;
    }
  }

  /**
   * Busca e valida dados do pagamento
   * @param {string} paymentId - ID do pagamento
   * @returns {Object} - Dados validados do pagamento
   */
  async getPaymentData(paymentId) {
    const pontesmpData = await firebaseService.get(`${FIREBASE_PATHS.PONTESMP}/${paymentId}`);
    
    if (!pontesmpData) {
      throw new Error(`${ERROR_MESSAGES.PAYMENT_NOT_FOUND}: ${paymentId}`);
    }
    
    const usercpf = pontesmpData.usercpf;
    const codcarrinho = pontesmpData.codcarrinho;
    const eventid = pontesmpData.eventId;
    
    if (!usercpf || !codcarrinho || !eventid) {
      throw new Error(ERROR_MESSAGES.MISSING_REQUIRED_FIELDS + ' (usercpf, codcarrinho ou eventId)');
    }
    
    // Validar CPF
    if (!ValidationService.validateCPF(usercpf)) {
      throw new Error('CPF inválido');
    }
    
    return { usercpf, codcarrinho, eventid };
  }

  /**
   * Busca e valida quantidade de ingressos
   * @param {string} codcarrinho - Código do carrinho
   * @returns {number} - Quantidade validada
   */
  async getTicketQuantity(codcarrinho) {
    const untData = await firebaseService.get(`${FIREBASE_PATHS.COOKIES_FIXO}/${codcarrinho}/unt`);
    const untValue = ValidationService.validateTicketQuantity(untData);
    
    return untValue;
  }

  /**
   * Retorna data e hora no fuso de São Paulo (America/Sao_Paulo) no formato desejado
   * @returns {{datebuy: string, horariocompra: string}} - datebuy: YYYY-MM-DD, horariocompra: HH:MM:SS
   */
  getDateTimeInSaoPaulo() {
    try {
      const timeZone = 'America/Sao_Paulo';
      // YYYY-MM-DD
      const datebuy = new Date().toLocaleDateString('en-CA', { timeZone });
      // HH:MM:SS (24h)
      const horariocompra = new Date().toLocaleTimeString('en-GB', { hour12: false, timeZone });
      return { datebuy, horariocompra };
    } catch (err) {
      // Fallback para caso Intl/timeZone não esteja disponível
      const now = new Date();
      const datebuy = now.toISOString().split('T')[0];
      const horariocompra = now.toTimeString().split(' ')[0];
      return { datebuy, horariocompra };
    }
  }

  /**
   * Salva todos os tokens nos 3 caminhos do Firebase
   * @param {string} eventid - ID do evento
   * @param {string} usercpf - CPF do usuário
   * @param {string} codcarrinho - Código do carrinho
   * @param {Array<string>} tokens - Array de tokens
   * @param {Array<string>} tokenTypesList - Lista de tipos
   * @param {string} paymentMethod - Método de pagamento
   * @param {string} paymentId - ID do pagamento
   */
  async saveAllTickets(eventid, usercpf, codcarrinho, tokens, tokenTypesList, paymentMethod, paymentId) {
    const errors = [];
    
    for (let index = 0; index < tokens.length; index++) {
      const token = tokens[index];
      const tokentype = tokenTypesList[index] || tokenTypesList[0];
      
      try {
        await this.processToken(eventid, usercpf, codcarrinho, token, tokentype, paymentMethod, paymentId);
      } catch (error) {
        console.error(`❌ Erro ao processar token ${token}:`, error);
        errors.push({ token, error: error.message });
      }
    }
    
    if (errors.length > 0) {
      console.error(`⚠️ ${errors.length} token(s) falharam ao salvar:`, errors);
      throw new Error(`Falha ao salvar ${errors.length} token(s)`);
    }
  }

  /**
   * Atualiza tokens e tipos no Firebase (cookiesfixo)
   */
  async updateTokensInFirebase(codcarrinho, tokens, tokenTypesList) {
    try {
      // Criar estrutura de tokens
      const tokensData = {};
      tokens.forEach((token, index) => {
        tokensData[`token${index + 1}`] = token;
      });
      
      // Criar estrutura de tipos
      const typesData = {};
      tokenTypesList.forEach((type, index) => {
        typesData[`tokentype${index + 1}`] = type;
      });
      
      // Atualizar no Firebase
      await firebaseService.set(`cookiesfixo/${codcarrinho}/tokens`, tokensData);
      await firebaseService.set(`cookiesfixo/${codcarrinho}/tokentypes`, typesData);
      
      console.log(`✅ Tokens e tipos salvos no carrinho ${codcarrinho}`);
    } catch (error) {
      console.error('❌ Erro ao atualizar tokens no Firebase:', error);
      throw error;
    }
  }

  /**
   * Processa um único token (salva nos 3 caminhos)
   */
  async processToken(eventid, usercpf, codcarrinho, token, tokentype, paymentMethod, paymentId) {
    try {
      // Verificar se o token já existe antes de salvar
      await this.checkTokenConflict(token, eventid, usercpf);
      
  const { datebuy, horariocompra } = this.getDateTimeInSaoPaulo();
      
      // Buscar dados do carrinho
      const cookieData = await firebaseService.get(`cookies/${codcarrinho}`);
      const unt = cookieData?.unt || 1;
      const valortotal = cookieData?.valortotal || 0;
      
      // Preparar dados do ticket
      const ticketBaseData = {
        token,
        compradorcpf: usercpf,
        methodpayment: paymentMethod,
        tipo: tokentype,
        datebuy,
        horariocompra,
        eventid
      };
      
      // 1. Salvar em ingressos disponíveis
      await this.saveTicketToAvailable(eventid, token, ticketBaseData);
      
      // 2. Salvar em ingressoscomprados do usuário
      await this.saveTicketToUser(usercpf, token, { ...ticketBaseData, unt, valortotal });
      
      // 3. Processar vendas da empresa
      await this.processCompanySales(eventid, usercpf, codcarrinho, token, unt, valortotal, paymentMethod, tokentype, datebuy, horariocompra);
      
    } catch (error) {
      console.error(`❌ Erro ao processar token ${token}:`, error);
      throw error;
    }
  }

  /**
   * Verifica se há conflito de token antes de salvar
   * @param {string} token - Token a verificar
   * @param {string} eventid - ID do evento
   * @param {string} usercpf - CPF do usuário
   */
  async checkTokenConflict(token, eventid, usercpf) {
    // Validar formato do token
    if (!ValidationService.validateTokenFormat(token)) {
      throw new Error(`Formato de token inválido: ${token}`);
    }

    const paths = [
      { 
        path: `${FIREBASE_PATHS.INGRESSOS}/${eventid}/${FIREBASE_PATHS.DISPONIVEIS}/${token}`, 
        name: 'ingressos/disponiveis' 
      },
      { 
        path: `${FIREBASE_PATHS.USERS}/${FIREBASE_PATHS.CPF}/${usercpf}/${FIREBASE_PATHS.INGRESSOS_COMPRADOS}/${token}`, 
        name: 'users/ingressoscomprados' 
      }
    ];

    for (const { path, name } of paths) {
      const existingData = await firebaseService.get(path);
      if (existingData) {
        throw new Error(`${ERROR_MESSAGES.TOKEN_EXISTS} em ${name}: ${token.substring(0, 8)}...`);
      }
    }
  }

  /**
   * Salva ticket em ingressos/disponiveis
   */
  async saveTicketToAvailable(eventid, token, ticketBaseData) {
    const ticketData = {
      compradorcpf: ticketBaseData.compradorcpf,
      horariovalidado: null,
      validado: false,
      token: ticketBaseData.token,
      methodpayment: ticketBaseData.methodpayment,
      isvalidaded: false,
      datebuy: ticketBaseData.datebuy,
      horariocompra: ticketBaseData.horariocompra,
      tipo: ticketBaseData.tipo
    };
    
    await firebaseService.set(`ingressos/${eventid}/disponiveis/${token}`, ticketData);
    console.log(`✅ Token ${token.substring(0, 8)}... salvo em ingressos/disponiveis`);
  }

  /**
   * Salva ticket no perfil do usuário
   */
  async saveTicketToUser(usercpf, token, ticketData) {
    const userTicketData = {
      eventid: ticketData.eventid,
      compradorcpf: ticketData.compradorcpf,
      unt: ticketData.unt,
      valortotal: ticketData.valortotal,
      methodpayment: ticketData.methodpayment,
      tipo: ticketData.tipo,
      token: ticketData.token
    };
    
    await firebaseService.set(`users/cpf/${usercpf}/ingressoscomprados/${token}`, userTicketData);
    console.log(`✅ Token ${token.substring(0, 8)}... salvo no perfil do usuário`);
  }

  /**
   * Processa vendas da empresa
   */
  async processCompanySales(eventid, usercpf, codcarrinho, token, unt, valortotal, paymentMethod, tokentype, datebuy, horariocompra) {
    try {
      // Buscar empresa vinculada ao evento
      const linkedCompanyId = await this.getLinkedCompany(eventid);
      
      if (!linkedCompanyId) {
        console.warn(`⚠️ Nenhuma empresa vinculada ao evento ${eventid}`);
        return;
      }
      
      // Verificar conflito antes de salvar
      const salesPath = `empresas/${linkedCompanyId}/vendas/vendasrealizadas/${eventid}/${token}`;
      const existingSale = await firebaseService.get(salesPath);
      
      if (existingSale) {
        throw new Error(`Token ${token.substring(0, 8)}... já existe nas vendas da empresa ${linkedCompanyId}`);
      }
      
      // Garantir estrutura de vendas
      await this.ensureCompanySalesStructure(linkedCompanyId);
      
      // Salvar venda
      const salesData = {
        compradorcpf: usercpf,
        datebuy: datebuy,
        horariocompra: horariocompra,
        codcarrinho: codcarrinho,
        unt: unt,
        valortotal: valortotal,
        methodpayment: paymentMethod,
        tipo: tokentype,
        token: token
      };
      
      await firebaseService.set(salesPath, salesData);
      console.log(`✅ Token ${token.substring(0, 8)}... salvo nas vendas da empresa`);
      
      // Atualizar saldo da empresa (apenas uma vez por pagamento)
      await this.updateCompanyBalance(linkedCompanyId, valortotal);
      
    } catch (error) {
      console.error('❌ Erro ao processar vendas da empresa:', error);
      throw error;
    }
  }

  /**
   * Busca empresa vinculada ao evento
   * @param {string} eventid - ID do evento
   * @returns {string|null} - ID da empresa ou null
   */
  async getLinkedCompany(eventid) {
    const eventData = await firebaseService.get(`eventos/${eventid}`);
    return eventData?.empresavinculada || null;
  }

  /**
   * Garante que a estrutura de vendas existe
   */
  async ensureCompanySalesStructure(linkedCompanyId) {
    try {
      const vendasNode = await firebaseService.get(`empresas/${linkedCompanyId}/vendas`);
      
      if (vendasNode === null) {
        await firebaseService.set(`empresas/${linkedCompanyId}/vendas`, {});
        console.log(`📁 Nó de vendas criado para empresa ${linkedCompanyId}`);
      }
      
      const vendasRealizadasNode = await firebaseService.get(`empresas/${linkedCompanyId}/vendas/vendasrealizadas`);
      
      if (vendasRealizadasNode === null) {
        await firebaseService.set(`empresas/${linkedCompanyId}/vendas/vendasrealizadas`, {});
        console.log(`📁 Nó de vendas realizadas criado para empresa ${linkedCompanyId}`);
      }
    } catch (error) {
      console.error('❌ Erro ao garantir estrutura de vendas:', error);
    }
  }

  /**
   * Atualiza o saldo disponível da empresa (desconto de 10%)
   */
  async updateCompanyBalance(linkedCompanyId, valortotal) {
    try {
      const companyData = await firebaseService.get(`empresas/${linkedCompanyId}`);
      
      if (!companyData) {
        console.warn(`⚠️ Dados da empresa ${linkedCompanyId} não encontrados`);
        return;
      }
      
      const saldoDisponivel = parseFloat(companyData.saldo_disponivel || 0);
      const valorComDesconto = valortotal - (valortotal * 0.10); // 10% de desconto
      const novoSaldo = saldoDisponivel + valorComDesconto;
      
      await firebaseService.set(`empresas/${linkedCompanyId}/saldo_disponivel`, novoSaldo);
      
      console.log(`💰 Saldo atualizado: Empresa=${linkedCompanyId}, Anterior=${saldoDisponivel.toFixed(2)}, Novo=${novoSaldo.toFixed(2)}, Adicionado=${valorComDesconto.toFixed(2)}`);
      
    } catch (error) {
      console.error('❌ Erro ao atualizar saldo da empresa:', error);
    }
  }

  /**
   * Verifica se os tokens foram salvos corretamente nos 3 caminhos
   */
  async verifyTokensInPaths(eventid, usercpf, tokens) {
    try {
      console.log('🔍 Verificando tokens nos caminhos...');
      
      const missingTokens = [];
      
      for (const token of tokens) {
        // Caminho 1: ingressos/disponiveis
        const path1Data = await firebaseService.get(`ingressos/${eventid}/disponiveis/${token}`);
        if (!path1Data) {
          missingTokens.push({ token: token.substring(0, 8) + '...', caminho: 'disponiveis' });
          await this.recreateTokenInPath1(eventid, token, usercpf);
        }
        
        // Caminho 2: users/ingressoscomprados
        const path2Data = await firebaseService.get(`users/cpf/${usercpf}/ingressoscomprados/${token}`);
        if (!path2Data) {
          missingTokens.push({ token: token.substring(0, 8) + '...', caminho: 'usuario' });
          await this.recreateTokenInPath2(eventid, token, usercpf);
        }
        
        // Caminho 3: empresas/vendas
        const eventData = await firebaseService.get(`eventos/${eventid}`);
        const linkedCompanyId = eventData?.empresavinculada;
        if (linkedCompanyId) {
          const path3Data = await firebaseService.get(`empresas/${linkedCompanyId}/vendas/vendasrealizadas/${eventid}/${token}`);
          if (!path3Data) {
            missingTokens.push({ token: token.substring(0, 8) + '...', caminho: 'empresa' });
            await this.recreateTokenInPath3(linkedCompanyId, eventid, token, usercpf);
          }
        }
      }
      
      if (missingTokens.length === 0) {
        console.log('✅ Todos os tokens verificados e existentes nos 3 caminhos');
      } else {
        console.log('⚠️ Tokens ausentes encontrados e recriados:', missingTokens);
      }
      
    } catch (error) {
      console.error('❌ Erro ao verificar tokens:', error);
    }
  }

  async recreateTokenInPath1(eventid, token, usercpf) {
    const { datebuy, horariocompra } = this.getDateTimeInSaoPaulo();
    const ticketData = {
      compradorcpf: usercpf,
      horariovalidado: null,
      validado: false,
      token: token,
      methodpayment: 'CARTÃO',
      isvalidaded: false,
      datebuy,
      horariocompra
    };
    
    await firebaseService.set(`ingressos/${eventid}/disponiveis/${token}`, ticketData);
    console.log(`🔧 Token ${token.substring(0, 8)}... recriado em disponíveis`);
  }

  async recreateTokenInPath2(eventid, token, usercpf) {
    const userTicketData = {
      eventid: eventid,
      compradorcpf: usercpf,
      methodpayment: 'CARTÃO',
      token: token,
      tipo: 'Padrão'
    };
    
    await firebaseService.set(`users/cpf/${usercpf}/ingressoscomprados/${token}`, userTicketData);
    console.log(`🔧 Token ${token.substring(0, 8)}... recriado no perfil do usuário`);
  }

  async recreateTokenInPath3(linkedCompanyId, eventid, token, usercpf) {
    const { datebuy, horariocompra } = this.getDateTimeInSaoPaulo();
    const salesData = {
      compradorcpf: usercpf,
      datebuy,
      horariacompra,
      methodpayment: 'CARTÃO',
      token: token
    };
    
    await firebaseService.set(`empresas/${linkedCompanyId}/vendas/vendasrealizadas/${eventid}/${token}`, salesData);
    console.log(`🔧 Token ${token.substring(0, 8)}... recriado nas vendas da empresa`);
  }
}

module.exports = new TicketService();
