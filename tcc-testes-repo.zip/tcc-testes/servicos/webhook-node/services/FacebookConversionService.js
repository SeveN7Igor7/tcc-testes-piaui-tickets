const axios = require('axios');
const crypto = require('crypto');
const logger = require('../utils/Logger');

class FacebookConversionService {
  constructor() {
    this.apiVersion = 'v21.0'; // Versão da API Meta
    this.baseUrl = 'https://graph.facebook.com';
  }

  /**
   * Envia evento de conversão para o Facebook Pixel
   * @param {Object} eventConfig - Configuração do evento (pixelfacebook, conversaotokenapi)
   * @param {Object} paymentData - Dados do pagamento
   * @param {Object} userData - Dados do usuário
   */
  async sendConversion(eventConfig, paymentData, userData) {
    try {
      const { pixelfacebook, conversaotokenapi } = eventConfig;

      // Validar configurações
      if (!pixelfacebook || !conversaotokenapi) {
        logger.info('⏭️ Conversão Facebook não configurada - pixelfacebook ou conversaotokenapi ausente', {
          hasPixelId: !!pixelfacebook,
          hasToken: !!conversaotokenapi
        });
        return { success: false, reason: 'not_configured' };
      }

      logger.info('📊 Iniciando envio de conversão para Facebook Pixel', {
        pixelId: pixelfacebook,
        paymentId: paymentData.paymentId,
        tokenMasked: conversaotokenapi ? `${conversaotokenapi.substring(0, 20)}...` : null
      });

      logger.info('⚠️ IMPORTANTE: Enviando evento do tipo PURCHASE (Compra) - não Lead/Inscrição', {
        eventType: 'Purchase',
        orderId: paymentData.paymentId,
        paymentValue: paymentData.amount,
        currency: 'BRL',
        formatoSimplificado: 'Usando formato testado no Graph API Explorer'
      });

      // Preparar dados do evento
      const eventData = this.buildEventData(paymentData, userData);

      // URL da API de Conversões
      const url = `${this.baseUrl}/${this.apiVersion}/${pixelfacebook}/events`;

      // Payload do evento
      const payload = {
        data: [eventData],
        access_token: conversaotokenapi
      };

      // Log do payload completo (sem o token)
      const payloadForLog = {
        data: payload.data
      };
      logger.info('🔍 DEBUG Facebook API - Payload Completo', {
        payload: JSON.stringify(payloadForLog, null, 2)
      });

      // Log detalhado da requisição
      logger.info('🔍 DEBUG Facebook API - Requisição', {
        url: url,
        method: 'POST',
        pixelId: pixelfacebook,
        eventName: eventData.event_name,
        orderId: eventData.order_id,
        eventId: eventData.event_id,
        eventTime: eventData.event_time,
        actionSource: eventData.action_source,
        customData: eventData.custom_data,
        userData: {
          hasEmail: !!eventData.user_data.em,
          hasExternalId: !!eventData.user_data.external_id,
          hasFirstName: !!eventData.user_data.fn,
          hasLastName: !!eventData.user_data.ln,
          hasPhone: !!eventData.user_data.ph,
          hasCity: !!eventData.user_data.ct,
          hasState: !!eventData.user_data.st,
          country: eventData.user_data.country,
          hasFbp: !!eventData.user_data.fbp,
          hasFbc: !!eventData.user_data.fbc,
          hasUserAgent: !!eventData.user_data.client_user_agent,
          hasIp: !!eventData.user_data.client_ip_address
        },
        userDataMatchParameters: this.countUserDataParameters(eventData.user_data),
        payloadSize: JSON.stringify(payload).length
      });

      // Verificar qualidade dos dados para match
      const filledParams = this.countFilledParameters(eventData.user_data);
      if (filledParams < 3) {
        logger.warning('⚠️ ATENÇÃO: Poucos dados de usuário preenchidos - pode afetar o match do Facebook', {
          filledParams,
          recommendation: 'Adicione email, telefone e nome completo para melhor match'
        });
      } else {
        logger.info('✅ Dados de usuário adequados para match do Facebook', { filledParams });
      }

      // Enviar para Facebook
      const response = await axios.post(url, payload, {
        headers: {
          'Content-Type': 'application/json'
        },
        timeout: 10000 // 10 segundos timeout
      });

      // Log detalhado da resposta
      logger.info('🔍 DEBUG Facebook API - Resposta', {
        status: response.status,
        statusText: response.statusText,
        headers: response.headers,
        data: response.data
      });

      if (response.data && response.data.events_received > 0) {
        logger.success('✅ Conversão enviada com sucesso para Facebook Pixel', {
          pixelId: pixelfacebook,
          paymentId: paymentData.paymentId,
          eventsReceived: response.data.events_received,
          fbtrace_id: response.data.fbtrace_id,
          fullResponse: response.data
        });

        logger.success('✅ CONFIRMAÇÃO: Evento PURCHASE enviado ao Facebook', {
          eventName: 'Purchase',
          value: paymentData.amount,
          currency: 'BRL',
          fbtrace_id: response.data.fbtrace_id,
          message: 'Se aparecer como Inscrição no Meta, verifique se há outro Pixel no frontend'
        });

        // Informações de troubleshooting
        logger.info('🔍 TROUBLESHOOTING: Como verificar no Event Manager do Facebook', {
          step1: `Abra: https://business.facebook.com/events_manager2/list/pixel/${pixelfacebook}/test_events`,
          step2: 'Use o FB Trace ID para localizar este evento específico',
          step3: 'Verifique se o Event Name é "Purchase" (não Lead, CompleteRegistration, etc)',
          step4: 'Se aparecer outro tipo: pode haver Pixel duplicado no frontend',
          step5: 'Verifique também a qualidade do match (Event Match Quality Score)',
          fbTraceId: response.data.fbtrace_id
        });

        return {
          success: true,
          eventsReceived: response.data.events_received,
          fbtrace_id: response.data.fbtrace_id
        };
      } else {
        logger.warning('⚠️ Facebook retornou resposta sem eventos recebidos', {
          fullResponse: response.data,
          status: response.status
        });
        return { success: false, reason: 'no_events_received', data: response.data };
      }

    } catch (error) {
      logger.error('❌ Erro ao enviar conversão para Facebook Pixel', {
        error: error.message,
        errorCode: error.code,
        response: error.response?.data,
        status: error.response?.status,
        statusText: error.response?.statusText,
        headers: error.response?.headers,
        requestUrl: error.config?.url,
        requestMethod: error.config?.method,
        stack: error.stack
      });

      // Retornar erro mas não lançar exception
      return {
        success: false,
        error: error.message,
        errorCode: error.code,
        response: error.response?.data,
        status: error.response?.status
      };
    }
  }

  /**
   * Constrói os dados do evento para enviar ao Facebook
   */
  buildEventData(paymentData, userData) {
    const timestamp = Math.floor(Date.now() / 1000);
    const eventId = `${paymentData.paymentId}_${timestamp}`;

    // Validar valor da compra
    const purchaseValue = parseFloat(paymentData.amount || 0);
    
    if (purchaseValue <= 0) {
      logger.warning('⚠️ ATENÇÃO: Valor da compra é R$ 0 ou inválido', {
        amount: paymentData.amount,
        parsed: purchaseValue
      });
    }

    if (purchaseValue < 1) {
      logger.warning('⚠️ ATENÇÃO: Valor muito baixo (< R$ 1,00) - Facebook pode não processar corretamente', {
        value: purchaseValue
      });
    }

    const eventData = {
      event_name: 'Purchase', // Evento de compra - DEVE ser exatamente 'Purchase' para conversão
      event_time: timestamp,
      event_id: eventId,
      order_id: paymentData.paymentId, // ID do pedido/pagamento
      action_source: 'website',
      user_data: this.buildUserData(userData),
      custom_data: {
        currency: 'BRL',
        value: purchaseValue, // Valor da compra
        contents: [
          {
            id: paymentData.paymentId,
            quantity: paymentData.quantity || 1
          }
        ]
      }
    };

    // Adicionar event_source_url se disponível
    if (paymentData.eventUrl) {
      eventData.event_source_url = paymentData.eventUrl;
    }

    logger.info('🔍 Evento construído como PURCHASE (Compra)', {
      eventName: eventData.event_name,
      orderId: eventData.order_id,
      value: eventData.custom_data.value,
      currency: eventData.custom_data.currency,
      contents: eventData.custom_data.contents
    });

    return eventData;
  }

  /**
   * Constrói os dados do usuário com hash
   */
  buildUserData(userData) {
    const userDataHashed = {};

    // Email (hashed)
    if (userData.email) {
      userDataHashed.em = this.hashData(userData.email.toLowerCase().trim());
    }

    // CPF como external_id (hashed)
    if (userData.cpf) {
      userDataHashed.external_id = this.hashData(userData.cpf.replace(/\D/g, ''));
    }

    // Nome (hashed)
    if (userData.firstName) {
      userDataHashed.fn = this.hashData(userData.firstName.toLowerCase().trim());
    }

    // Sobrenome (hashed)
    if (userData.lastName) {
      userDataHashed.ln = this.hashData(userData.lastName.toLowerCase().trim());
    }

    // Telefone (hashed)
    if (userData.phone) {
      const phoneClean = userData.phone.replace(/\D/g, '');
      userDataHashed.ph = this.hashData(phoneClean);
    }

    // Cidade (hashed)
    if (userData.city) {
      userDataHashed.ct = this.hashData(userData.city.toLowerCase().trim());
    }

    // Estado (hashed)
    if (userData.state) {
      userDataHashed.st = this.hashData(userData.state.toLowerCase().trim());
    }

    // País (sempre BR)
    userDataHashed.country = this.hashData('br');

    // User Agent e IP (não hasheados)
    if (userData.userAgent) {
      userDataHashed.client_user_agent = userData.userAgent;
    }

    if (userData.clientIpAddress) {
      userDataHashed.client_ip_address = userData.clientIpAddress;
    }

    // FBP (Facebook Browser Pixel) - cookie _fbp
    if (userData.fbp) {
      userDataHashed.fbp = userData.fbp;
    }

    // FBC (Facebook Click ID) - cookie _fbc
    if (userData.fbc) {
      userDataHashed.fbc = userData.fbc;
    }

    return userDataHashed;
  }

  /**
   * Faz hash SHA256 de um dado
   */
  hashData(data) {
    if (!data) return null;
    return crypto.createHash('sha256').update(String(data)).digest('hex');
  }

  /**
   * Conta quantos parâmetros de user_data estão preenchidos
   */
  countUserDataParameters(userData) {
    const params = ['em', 'external_id', 'fn', 'ln', 'ph', 'ct', 'st', 'country', 'fbp', 'fbc', 'client_user_agent', 'client_ip_address'];
    const filled = params.filter(param => userData[param] && userData[param] !== null).length;
    return `${filled}/${params.length} parâmetros preenchidos`;
  }

  /**
   * Conta quantos parâmetros críticos estão preenchidos (retorna número)
   */
  countFilledParameters(userData) {
    const criticalParams = ['em', 'external_id', 'fn', 'ln', 'ph', 'fbp', 'fbc'];
    return criticalParams.filter(param => userData[param] && userData[param] !== null).length;
  }

  /**
   * Testa a configuração do pixel
   */
  async testPixelConfiguration(pixelId, accessToken) {
    try {
      const url = `${this.baseUrl}/${this.apiVersion}/${pixelId}`;
      const response = await axios.get(url, {
        params: { access_token: accessToken },
        timeout: 5000
      });

      return {
        success: true,
        pixelData: response.data
      };
    } catch (error) {
      return {
        success: false,
        error: error.message,
        response: error.response?.data
      };
    }
  }
}

module.exports = new FacebookConversionService();
