const nodemailer = require('nodemailer');
const QRCode = require('qrcode');
const firebaseService = require('./FirebaseService');

class EmailService {
  constructor() {
    // TESTE: com EMAIL_MOCK_URL definido, o envio vai para o servico simulado (mesmo atraso do teste do PHP).
    // O e-mail e o QR code continuam sendo montados normalmente.
    if (process.env.EMAIL_MOCK_URL) {
      const axios = require('axios');
      this.transporter = { sendMail: async () => { await axios.get(process.env.EMAIL_MOCK_URL, { timeout: 30000 }); return { messageId: 'teste' }; } };
      console.log('📧 Serviço de email simulado (teste)');
      return;
    }
    this.transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT),
      secure: process.env.SMTP_SECURE === 'true', // true para 465, false para outras portas
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      }
    });
    
    console.log('📧 Serviço de email configurado');
  }

  /**
   * Envia email com base no status do pagamento do Mercado Pago
   */
  async sendPaymentStatusEmail({ usercpf, eventid, paymentId, status, status_detail }) {
    try {
      // Buscar dados do usuário e evento
      const userData = await firebaseService.get(`users/cpf/${usercpf}`);
      const eventData = await firebaseService.get(`eventos/${eventid}`);
      const email = userData?.email || 'nao-responda@piauitickets.com';
      const fullName = userData?.fullname || 'Usuário';
      const eventName = eventData?.nomeevento || 'Evento';

      const { subject, html } = this.buildStatusEmailTemplate({
        fullName,
        eventName,
        status,
        status_detail,
        paymentId
      });

      const mailOptions = {
        from: `"${process.env.SMTP_FROM_NAME}" <${process.env.SMTP_USER}>`,
        to: email,
        subject,
        html
      };

      await this.transporter.sendMail(mailOptions);
      console.log(`✅ Email de status (${status}) enviado para ${email}`);
      return true;
    } catch (error) {
      console.error('❌ Erro ao enviar email de status:', error);
      return false;
    }
  }

  /**
   * Constrói template de email com base no status do pagamento
   */
  buildStatusEmailTemplate({ fullName, eventName, status, status_detail, paymentId }) {
    const titleMap = {
      approved: 'Pagamento Aprovado ✅',
      pending: 'Pagamento Pendente ⏳',
      in_process: 'Pagamento em Análise 🔎',
      authorized: 'Pagamento Autorizado 🟦',
      in_mediation: 'Pagamento em Mediação 🟨',
      rejected: 'Pagamento Rejeitado ❌',
      cancelled: 'Pagamento Cancelado 🟥',
      refunded: 'Pagamento Estornado 💸',
      charged_back: 'Pagamento Contestato ⚠️'
    };

    const adviceMap = {
      approved: 'Seus ingressos já estão disponíveis na sua área do usuário.',
      pending: 'Estamos aguardando a confirmação do pagamento. Você será notificado assim que houver atualização.',
      in_process: 'Seu pagamento está em análise. Assim que for concluído, você receberá uma notificação.',
      authorized: 'Pagamento autorizado pelo emissor. Em breve será processado.',
      in_mediation: 'A transação está em mediação. Nossa equipe está acompanhando.',
      rejected: 'Seu pagamento não foi aprovado. Verifique seus dados e tente novamente.',
      cancelled: 'Esta transação consta como expirada ou cancelada; caso você tenha realizado o pagamento em outra tentativa, fique tranquilo, pois pagamentos concluídos com sucesso não são cancelados.',
      refunded: 'O valor foi estornado. Caso tenha dúvidas, contate o suporte.',
      charged_back: 'O pagamento foi contestado. Nossa equipe analisará o caso.'
    };

    const subject = `[PI TICKETS] ${titleMap[status] || 'Atualização de Pagamento'}`;
    const detail = status_detail ? `<p style="color:#bbb; font-size:13px">Detalhe: ${this.escapeHtml(status_detail)}</p>` : '';

    const html = `
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    body { font-family: Arial, sans-serif; background: #0b0b0b; color:#fff; margin:0; padding:0; }
    .container { max-width: 640px; margin: 0 auto; padding: 24px; background: #1a1a1a; border-radius: 12px; }
    .badge { display:inline-block; padding:6px 10px; border-radius:12px; font-size: 12px; margin-bottom: 8px; background:#333; color:#ddd }
    .approved { background:#1e8e3e; }
    .pending { background:#f9a825; }
    .in_process { background:#0288d1; }
    .rejected { background:#d32f2f; }
    .cancelled { background:#9e9e9e; }
    .refunded { background:#6a1b9a; }
    .charged_back { background:#ef6c00; }
    h1 { font-size:22px; margin: 0 0 8px; }
    p { color:#ddd; line-height:1.6; }
    .footer { color:#aaa; font-size:12px; margin-top: 24px; border-top:1px solid #333; padding-top: 12px; text-align:center; }
  </style>
  <title>${subject}</title>
  </head>
  <body>
    <div class="container">
      <span class="badge ${this.escapeHtml(status)}">${this.escapeHtml(titleMap[status] || status)}</span>
      <h1>Olá, ${this.escapeHtml(fullName)}!</h1>
      <p>Sobre sua compra para o evento <strong>${this.escapeHtml(eventName)}</strong>:</p>
      <p>${this.escapeHtml(adviceMap[status] || 'Status atualizado do seu pagamento.')}</p>
      ${detail}
      <p style="color:#bbb; font-size:13px">ID do pagamento: ${this.escapeHtml(String(paymentId))}</p>
      <div class="footer">PI TICKETS • ${new Date().getFullYear()} • Esta é uma mensagem automática</div>
    </div>
  </body>
 </html>`;

    return { subject, html };
  }

  /**
   * Envia email de confirmação de compra
   */
  async sendConfirmationEmail(usercpf, eventid, tokens, paymentId) {
    try {
      console.log(`📨 Enviando email de confirmação para CPF: ${usercpf}`);
      
      // Buscar dados do usuário
      const userData = await firebaseService.get(`users/cpf/${usercpf}`);
      const email = userData?.email || 'nao-responda@piauitickets.com';
      const fullName = userData?.fullname || 'Usuário';
      
      // Buscar dados do evento
      const eventData = await firebaseService.get(`eventos/${eventid}`);
      const eventName = eventData?.nomeevento || 'Evento Desconhecido';
      
      const mailOptions = {
        from: `"${process.env.SMTP_FROM_NAME}" <${process.env.SMTP_USER}>`,
        to: email,
        subject: 'Obrigado pela Compra!!',
        html: this.generateEmailBody(eventName, fullName, tokens.length)
      };
      
      await this.transporter.sendMail(mailOptions);
      
      console.log(`✅ Email enviado com sucesso para ${email}`);
      return true;
      
    } catch (error) {
      console.error('❌ Erro ao enviar email:', error);
      throw error;
    }
  }

  /**
   * Gera o corpo HTML do email
   */
  generateEmailBody(eventName, fullName, ticketCount) {
    return `
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #000000;
            color: #ffffff;
        }
        .container {
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #1f1f1f;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
        }
        h1 { 
            color: #ffffff; 
            font-size: 24px;
            margin-bottom: 10px;
        }
        h2 { 
            color: #ffffff; 
            font-size: 20px;
            margin-top: 20px;
        }
        p {
            font-size: 16px;
            color: #e0e0e0;
            line-height: 1.6;
        }
        .event-info {
            margin: 20px 0;
            padding: 15px;
            background-color: #333333;
            border: 1px solid #444444;
            border-radius: 4px;
        }
        .ticket-count {
            background-color: #4CAF50;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            display: inline-block;
            margin: 10px 0;
            font-weight: bold;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #444444;
            font-size: 14px;
            color: #cccccc;
        }
        .highlight {
            color: #4CAF50;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎉 Obrigado pela Compra, ${this.escapeHtml(fullName)}!</h1>
        <p>Seus ingressos foram gerados com sucesso!</p>
        
        <div class="event-info">
            <h2>✅ Compra Processada com Sucesso</h2>
            <p><strong>Evento:</strong> <span class="highlight">${this.escapeHtml(eventName)}</span></p>
            <div class="ticket-count">🎫 ${ticketCount} ${ticketCount === 1 ? 'Ingresso' : 'Ingressos'}</div>
            <p style="margin-top: 15px;">
                <strong>Como acessar seus ingressos:</strong><br>
                1. Faça login na sua conta<br>
                2. Acesse a área do Usuário<br>
                3. Visualize e apresente seus ingressos no evento
            </p>
        </div>
        
        <div class="footer">
            <p><strong>PI TICKETS</strong></p>
            <p>Todos os direitos reservados © ${new Date().getFullYear()}</p>
            <p style="font-size: 12px; color: #999; margin-top: 10px;">
                Este é um e-mail automático. Por favor, não responda.
            </p>
        </div>
    </div>
</body>
</html>
    `;
  }

  /**
   * Envia email com os ingressos (QR code, token e tipo de cada ingresso)
   * Chamado após os ingressos serem salvos e processados com sucesso.
   *
   * @param {Object} params
   * @param {string} params.usercpf - CPF do comprador
   * @param {string} params.eventid - ID do evento
   * @param {string} params.paymentId - ID do pagamento
   * @param {Array<{token: string, tipo: string}>} params.tickets - Lista de ingressos
   */
  async sendTicketsEmail({ usercpf, eventid, paymentId, tickets }) {
    try {
      if (!Array.isArray(tickets) || tickets.length === 0) {
        console.warn('⚠️ Nenhum ingresso fornecido para envio de email de ingressos');
        return false;
      }

      console.log(`📨 Enviando email de ingressos (${tickets.length}) para CPF: ${usercpf}`);

      // Buscar dados do usuário e do evento
      const userData = await firebaseService.get(`users/cpf/${usercpf}`);
      const eventData = await firebaseService.get(`eventos/${eventid}`);

      const email = userData?.email || 'nao-responda@piauitickets.com';
      const fullName = userData?.fullname || 'Usuário';
      const eventName = eventData?.nomeevento || 'Evento';
      const eventDate = eventData?.dataevento || eventData?.data || '';
      const eventLocal = eventData?.local || eventData?.endereco || '';

      // Gerar um QR code (PNG) por ingresso e anexar como imagem inline (CID)
      const attachments = [];
      const ticketsWithCid = [];

      for (let i = 0; i < tickets.length; i++) {
        const ticket = tickets[i];
        const token = ticket.token;
        const cid = `qr-${token}-${i}`;

        const qrBuffer = await QRCode.toBuffer(token, {
          type: 'png',
          width: 260,
          margin: 1,
          errorCorrectionLevel: 'H'
        });

        attachments.push({
          filename: `ingresso-${i + 1}.png`,
          content: qrBuffer,
          cid
        });

        ticketsWithCid.push({
          token,
          tipo: ticket.tipo || 'Padrão',
          cid,
          index: i + 1
        });
      }

      const { subject, html } = this.buildTicketsEmailTemplate({
        fullName,
        eventName,
        eventDate,
        eventLocal,
        tickets: ticketsWithCid,
        paymentId
      });

      const mailOptions = {
        from: `"${process.env.SMTP_FROM_NAME}" <${process.env.SMTP_USER}>`,
        to: email,
        subject,
        html,
        attachments
      };

      await this.transporter.sendMail(mailOptions);
      console.log(`✅ Email de ingressos enviado com sucesso para ${email} (${tickets.length} ingresso(s))`);
      return true;
    } catch (error) {
      console.error('❌ Erro ao enviar email de ingressos:', error);
      return false;
    }
  }

  /**
   * Constrói o template HTML do email de ingressos com QR codes
   */
  buildTicketsEmailTemplate({ fullName, eventName, eventDate, eventLocal, tickets, paymentId }) {
    const subject = `[PI TICKETS] 🎫 Seus ingressos para ${eventName}`;

    const eventMeta = [
      eventDate ? `<p style="margin:4px 0; color:#bbb; font-size:14px"><strong>Data:</strong> ${this.escapeHtml(String(eventDate))}</p>` : '',
      eventLocal ? `<p style="margin:4px 0; color:#bbb; font-size:14px"><strong>Local:</strong> ${this.escapeHtml(String(eventLocal))}</p>` : ''
    ].join('');

    const ticketCards = tickets.map(t => `
      <div class="ticket">
        <div class="ticket-header">
          🎟️ Ingresso ${t.index} <span class="tipo">${this.escapeHtml(t.tipo)}</span>
        </div>
        <img class="qr" src="cid:${t.cid}" alt="QR Code do ingresso" width="220" height="220" />
        <p class="token-label">Token do ingresso:</p>
        <p class="token">${this.escapeHtml(t.token)}</p>
      </div>
    `).join('');

    const html = `
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    body { font-family: Arial, sans-serif; margin:0; padding:0; background-color:#000000; color:#ffffff; }
    .container { width:100%; max-width:640px; margin:0 auto; padding:24px; background-color:#1f1f1f; border-radius:8px; }
    h1 { color:#ffffff; font-size:24px; margin:0 0 8px; }
    p { font-size:16px; color:#e0e0e0; line-height:1.6; }
    .event-info { margin:20px 0; padding:15px; background-color:#333333; border:1px solid #444444; border-radius:6px; }
    .event-info h2 { margin:0 0 8px; font-size:20px; color:#fff; }
    .highlight { color:#4CAF50; font-weight:bold; }
    .ticket { margin:18px 0; padding:18px; background-color:#2a2a2a; border:1px solid #444; border-radius:8px; text-align:center; }
    .ticket-header { font-size:17px; font-weight:bold; color:#fff; margin-bottom:12px; }
    .tipo { display:inline-block; margin-left:8px; padding:3px 10px; background-color:#4CAF50; color:#fff; border-radius:12px; font-size:12px; font-weight:bold; vertical-align:middle; }
    .qr { display:block; margin:0 auto 12px; background:#fff; padding:10px; border-radius:8px; }
    .token-label { margin:6px 0 2px; font-size:13px; color:#aaa; }
    .token { margin:0; font-size:20px; font-weight:bold; letter-spacing:2px; color:#4CAF50; font-family:'Courier New', monospace; }
    .instructions { margin-top:20px; padding:15px; background-color:#333; border-radius:6px; }
    .footer { text-align:center; margin-top:30px; padding-top:20px; border-top:1px solid #444; font-size:14px; color:#cccccc; }
  </style>
  <title>${subject}</title>
</head>
<body>
  <div class="container">
    <h1>🎉 Olá, ${this.escapeHtml(fullName)}!</h1>
    <p>Seu pagamento foi aprovado e seus ingressos foram gerados com sucesso.</p>
    <p style="background-color:#1e3a1e; border-left:4px solid #4CAF50; padding:12px 14px; border-radius:4px; margin:16px 0;">
      ⭐ <strong>Recomendado:</strong> o ideal é acessar seus ingressos pela <strong>área do usuário</strong> na sua conta.
      Os ingressos abaixo neste email são apenas uma <strong>forma alternativa</strong> de acesso.
    </p>

    <div class="event-info">
      <h2>📅 <span style="color:#ffffff; font-weight:bold;">${this.escapeHtml(eventName)}</span></h2>
      ${eventMeta}
      <p style="margin:8px 0 0; color:#bbb; font-size:13px"><strong>${tickets.length}</strong> ${tickets.length === 1 ? 'ingresso' : 'ingressos'}</p>
    </div>

    ${ticketCards}

    <div class="instructions" style="color:#ffffff;">
      <strong style="color:#ffffff;">Como usar:</strong>
      <p style="margin:8px 0 0; color:#ffffff;">
        1. <strong>De preferência, acesse seus ingressos pela área do usuário</strong> na sua conta — essa é a forma recomendada.<br>
        2. Caso não consiga, use o QR code (ou o token) deste email como <strong>alternativa</strong>.<br>
        3. Apresente o QR code na entrada do evento. Cada ingresso é válido para <strong>uma única entrada</strong>.
      </p>
    </div>

    <div class="footer">
      <p><strong>PI TICKETS</strong></p>
      <p style="font-size:12px; color:#999">ID do pagamento: ${this.escapeHtml(String(paymentId))}</p>
      <p style="font-size:12px; color:#999">Todos os direitos reservados © ${new Date().getFullYear()} — Este é um e-mail automático, não responda.</p>
    </div>
  </div>
</body>
</html>`;

    return { subject, html };
  }

  /**
   * Escapa caracteres HTML para prevenir XSS
   */
  escapeHtml(text) {
    const map = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
  }

  /**
   * Testa a configuração do email
   */
  async testConnection() {
    try {
      await this.transporter.verify();
      console.log('✅ Conexão com servidor SMTP verificada');
      return true;
    } catch (error) {
      console.error('❌ Erro ao verificar conexão SMTP:', error);
      return false;
    }
  }
}

module.exports = new EmailService();
