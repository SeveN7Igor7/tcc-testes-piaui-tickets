# Kit de teste de carga: estágios E1 e E2 (PHP)

Reproduz a aplicação PHP original (página do evento, preparar checkout, webhook e gerador de
códigos) em contêineres com os limites de cada plano de hospedagem, e aplica o cenário de pico com o k6.

O Mercado Pago e o envio de e-mail são simulados por um serviço local com atraso fixo. Nenhum
segredo ou endereço de produção está neste pacote.

## Antes de começar

1. Docker Desktop aberto, com pelo menos 4 CPUs e 6 GB de memória liberados em Settings > Resources.
2. Um projeto Firebase só de teste, com Realtime Database e regras abertas para leitura e escrita.
3. Copie `.env.exemplo` para `.env` e coloque a URL do banco de teste.

## Rodar tudo de uma vez (recomendado)

```
powershell -ExecutionPolicy Bypass -File rodar_todos.ps1
```

Roda os 6 estágios **um depois do outro** (cerca de 1 hora no total) e, no fim, abre o painel de comparação.
Os estágios não rodam em paralelo de propósito: no mesmo computador, eles disputariam processador, rede e
banco de teste, e um atrapalharia o resultado do outro.

Enquanto cada estágio roda, o painel ao vivo do k6 abre sozinho em **http://localhost:5665**
(requisições por segundo, tempos de resposta e falhas em tempo real).

## Analisar os resultados

- **painel.html**: abra no navegador, clique em "Escolher a pasta resultados" e selecione a pasta `resultados`.
  Tem uma aba **Comparação** (gráficos e tabela lado a lado) e **uma aba por estágio**.
- **resultados\<estágio>.html**: relatório detalhado do k6 de cada estágio, com gráficos ao longo do tempo.
- **resultados\<estágio>_php.log**: registro do PHP; o painel conta os erros de falta de memória a partir dele.

## Plano da revisão do orientador (um comando só)

```
powershell -ExecutionPolicy Bypass -File rodar_professor.ps1
```

Roda, em sequência (4 a 5 horas):
1. a 3ª, 4ª e 5ª execuções do controle (E2-Cloud), do E1 com 32 processos, do E3 e do E4;
2. o **teste de notificação duplicada** no E1 com 32 processos e no E4: cada notificação de aprovação chega duas
   vezes ao mesmo tempo, como o Mercado Pago às vezes faz;
3. o **teste de estoque** no E1 com 32 processos e no E4: todos os compradores querem Camarote, com estoque de
   100 ingressos controlado pela página do evento (serviço do organizador), como em produção.

Ao fim de **cada** execução, o script confere no banco de teste:
- pagamentos pagos × ingressos emitidos (faltou ingresso? sobrou ingresso?);
- ingressos vendidos × estoque (vendeu Camarote acima do limite?).

O resultado fica em `resultados\<execução>_conferencia.json`. Na primeira execução, o script também salva a
descrição do computador e das versões em `resultados\ambiente.txt`.

Deixe o computador sem suspender e **sem outros programas abertos** (jogos, atualizações), porque eles
interferem nos resultados.

## Estágios E3 e E4: PHP no Cloud + servidores Node.js

```
powershell -ExecutionPolicy Bypass -File rodar_todos.ps1 -Estagios E2-Cloud,E3,E4
```

- **E2-Cloud (controle):** tudo em PHP no Cloud WEB 4/4 (32 processos de 128 MB).
- **E3:** o mesmo Cloud, mas só com as páginas em PHP (página do evento, tela de checkout, PIX, cartão, login e
  área do usuário). A preparação do checkout vai para o serviço Node do servidor 2, e os webhooks para o serviço
  Node do servidor 1, **sem fila** (cada webhook é processado assim que chega).
- **E4:** igual ao E3, com a **fila Redis/BullMQ** nos webhooks (1 por vez) e o **cache Redis da página do evento**
  (servidor 3): a página pede os dados do evento a uma API Node que guarda no Redis por 3 minutos e só vai ao banco
  quando o cache expira ou é invalidado (`POST /invalidar/<id>`). Esse serviço foi escrito para o teste, seguindo
  a mesma ideia do de produção; acertos e faltas do cache ficam em `resultados\E4_..._cache.json`.

Cada serviço Node roda com os limites de um servidor da InterServer (1 núcleo, 2 GB). O código é o de produção, com
quatro trocas para o teste: banco de teste (SDK cliente do Firebase, porque o banco de teste não tem chave de serviço),
Mercado Pago simulado, e-mail simulado (o QR code continua sendo gerado) e a fila que pode ser desligada (E3).

Na primeira vez, o Docker monta as imagens dos serviços Node (alguns minutos, precisa de internet).
Antes de começar, o script confere se os dois serviços respondem; se não, mostra o erro e para.

Arquivos a mais em `resultados`: `<estágio>_webhook.log` traz, para cada webhook, a espera na fila e o tempo até
terminar de emitir o ingresso; `<estágio>_node.log` traz o registro dos serviços Node.

**Painel da fila (só no E4):** http://localhost:3001/admin/queues (usuário `admin`, senha `teste`).

**Ao terminar cada estágio, feche a aba do painel ao vivo (localhost:5665)**, senão o k6 pode ficar parado esperando.

## O que a jornada de compra faz agora

1. Abre a página do evento; 2. prepara o checkout; 3. abre a tela de checkout;
4. paga:
   - **80% com PIX**: a página chama `api/apimercadopago.php`, que gera o PIX (pendente); o cliente paga de 10 a 40 s depois;
   - **20% com cartão**: `api/pagamentocardmp/pagamentocardmp.php`, aprovado na hora (na produção, 17% das notificações eram de cartão);
5. o Mercado Pago simulado envia os webhooks de criação e de aprovação;
6. **70% dos compradores entram na área do usuário** (`/login/`): abrem a tela, fazem login (a página chama
   `api/validacao.php` no próprio servidor, ocupando **dois** processos PHP ao mesmo tempo) e abrem a área de novo
   para ver os ingressos (1 leitura do usuário + 1 por evento + 2 por ingresso).

Todos os usuários de teste têm a senha `senha123`, criptografada com uma chave só de teste (`CHAVE_SENHA`).
Parte deles já tem ingressos antigos de outros eventos (50% nenhum, 30% 1–2, 15% 3–6, 5% 7–15).

## Primeira execução (teste rápido, para ver se tudo sobe)

Abra o PowerShell nesta pasta e rode:

    powershell -ExecutionPolicy Bypass -File rodar.ps1 -Estagio E1 -Mult 0.2 -Rep 0

Na primeira vez o Docker baixa as imagens, o que leva alguns minutos. Enquanto roda, abra
http://localhost:8080/comprar/1001/ no navegador: deve aparecer a página do "Evento de Teste".

Se der erro, copie a mensagem inteira e me envie.

## O que o teste simula

Três tipos de usuário ao mesmo tempo, como na abertura de vendas real:

- **Visitantes** que só abrem a página do evento.
- **Compradores**, com a jornada completa: abrem a página, levam de 5 a 20 s escolhendo,
  preparam o checkout, abrem a tela de checkout, levam de 5 a 15 s para escolher o PIX, geram o PIX (o Mercado Pago simulado responde "pendente") e pagam
  de 10 a 40 s depois (a segunda notificação responde "aprovado" e os ingressos são gerados).
  A quantidade de ingressos por compra segue a proporção real: 1 em 63% das compras, 2 em 25%,
  3 em 7%, 4 em 1% e 5 em 4%.
- **Rajada da abertura**: no minuto 1, um grupo de compradores entra quase junto, em 20 s,
  como quem estava esperando o link.

Como cada compra leva de 20 s a 1 min, em qualquer momento há páginas sendo abertas enquanto
outros clientes preparam o checkout e webhooks estão sendo processados.

Com `-Mult 1`: 30 compradores e 270 visitantes por minuto no pico, mais 60 compradores na rajada.

## Execuções para o artigo

Para cada estágio, 3 repetições com o mesmo multiplicador:

    powershell -ExecutionPolicy Bypass -File rodar.ps1 -Estagio E1 -Mult 1 -Rep 1
    powershell -ExecutionPolicy Bypass -File rodar.ps1 -Estagio E1 -Mult 1 -Rep 2
    powershell -ExecutionPolicy Bypass -File rodar.ps1 -Estagio E1 -Mult 1 -Rep 3

Estágios disponíveis: `E1`, `E2-II`, `E2-III`, `E2-Cloud`.

`-Mult` multiplica o pico real de produção (26 notificações de pagamento por minuto). Se um estágio não saturar, repita com 2 e 4.

Cada execução leva cerca de 10 minutos e recarrega os dados de teste antes de começar.

## O que sai em `resultados/`

- `NOME.json`: resumo do k6, com latência (mediana, p95, p99), taxa de erros, workers ocupados e fila do PHP-FPM.
- `NOME.txt`: a saída do k6 na tela.
- `NOME_recursos.csv`: CPU e memória de cada contêiner a cada 10 segundos.
- `NOME_webhook.log`: registro do webhook, com o tempo de execução de cada pagamento.

Envie a pasta `resultados` inteira para gerar as tabelas e os gráficos.

## O que conferir antes das execuções definitivas

- Em `rodar.ps1`, o número de processos PHP (`filhos`) de cada plano. Está 4, 4, 4 e 32; ajuste para o que você usava.
- Em `k6/pico.js`, `VISITAS_POR_COMPRA` está 10. É uma premissa: se você tiver o número real de visitas por compra, use-o.
- Versão do PHP: o kit usa a 8.2. Se a produção usava outra, troque a imagem em `docker-compose.yml`.

## Diferenças em relação à produção (vão para as limitações do artigo)

- O gerador de carga roda na mesma máquina que a aplicação.
- O registro do pagamento, gravado em produção pela tela de pagamento, é gravado pelo próprio gerador de carga.
- Mercado Pago e e-mail respondem com atraso fixo (300 ms e 500 ms).
- A página do evento roda sem as chamadas ao serviço do organizador, como no estágio inicial.
