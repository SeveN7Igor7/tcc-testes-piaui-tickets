# Roda varios estagios em sequencia e, no fim, abre o painel de comparacao.
# Exemplos:
#   powershell -ExecutionPolicy Bypass -File rodar_todos.ps1                          (todos)
#   powershell -ExecutionPolicy Bypass -File rodar_todos.ps1 -Estagios E2-Cloud,E3,E4 (so esses)
param(
  [string]$Estagios = 'E1,E1-16,E1-32,E2-II,E2-III,E2-Cloud,E3,E4',
  [string]$Mult = '1',
  [int]$Rep = 1,
  [ValidateSet('normal', 'duplicado', 'estoque')][string]$Teste = 'normal'
)
Set-Location $PSScriptRoot
$inicio = Get-Date
# aceita a lista separada por virgula (com -File o PowerShell entrega tudo como um texto so)
$lista = $Estagios -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ }
foreach ($e in $lista) {
  powershell -ExecutionPolicy Bypass -File rodar.ps1 -Estagio $e -Mult $Mult -Rep $Rep -Teste $Teste
}
$min = [math]::Round(((Get-Date) - $inicio).TotalMinutes)
Write-Host "Estagios terminados em $min minutos. Abrindo o painel de comparacao..."
Start-Process (Join-Path $PSScriptRoot 'painel.html')
