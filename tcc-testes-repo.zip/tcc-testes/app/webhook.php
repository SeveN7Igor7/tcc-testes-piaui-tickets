<?php


header("Content-Type: application/json");
error_reporting(E_ALL);
ini_set('display_errors', 0);

class WebhookConfig {
    const FIREBASE_URL = 'definido por variavel de ambiente';
    const ACCESS_TOKEN = 'removido';
    const MERCADOPAGO_API_URL = 'https://api.mercadopago.com/v1/payments/';
    // TESTE: URL do gerador de token vem de SITE_URL (ver abaixo)
    const LOG_FILE = __DIR__ . '/webhook_logs.log';
    
    // ConfiguraÃ§Ãµes de email
    const SMTP_HOST = 'smtpi.kinghost.net';
    const SMTP_USERNAME = 'naoresponda@piauitickets.com';
    const SMTP_PASSWORD = 'removido';
    const SMTP_PORT = 587;
}

class WebhookLogger {
    private static function writeLog($level, $message, $data = []) {
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = '[' . $timestamp . '] [' . $level . '] ' . $message;
        if (!empty($data)) {
            $logMessage .= ' | ' . json_encode($data, JSON_UNESCAPED_UNICODE);
        }
        file_put_contents(WebhookConfig::LOG_FILE, $logMessage . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
    
    public static function info($message, $data = []) {
        self::writeLog('INFO', $message, $data);
    }
    
    public static function error($message, $data = []) {
        self::writeLog('ERRO', $message, $data);
    }
    
    public static function success($message, $data = []) {
        self::writeLog('SUCESSO', $message, $data);
    }
    
    public static function debug($message, $data = []) {
        self::writeLog('DEBUG', $message, $data);
    }
    
    public static function warning($message, $data = []) {
        self::writeLog('AVISO', $message, $data);
    }
}

class FirebaseManager {
    private $baseUrl;
    
    public function __construct($baseUrl) {
        $this->baseUrl = rtrim($baseUrl, '/');
    }
    
    public function get($path) {
        $url = $this->baseUrl . '/' . ltrim($path, '/') . '.json';
        WebhookLogger::debug('RequisiÃ§Ã£o GET para Firebase', ['url' => $url, 'caminho' => $path]);
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            WebhookLogger::error('Erro curl no Firebase GET', ['erro' => $error, 'caminho' => $path]);
            return false;
        }
        
        if ($httpCode === 404) {
            WebhookLogger::debug('NÃ³ nÃ£o encontrado no Firebase GET', ['caminho' => $path]);
            return null; // NÃ³ nÃ£o existe
        }
        
        if ($httpCode !== 200) {
            WebhookLogger::error('Falha no Firebase GET', ['codigo_http' => $httpCode, 'caminho' => $path, 'resposta' => $response]);
            return false;
        }
        
        $data = json_decode($response, true);
        WebhookLogger::debug('Firebase GET bem-sucedido', ['caminho' => $path, 'tamanho_dados' => strlen($response)]);
        return $data;
    }
    
    public function put($path, $data) {
        $url = $this->baseUrl . '/' . ltrim($path, '/') . '.json';
        WebhookLogger::debug('RequisiÃ§Ã£o PUT para Firebase', ['url' => $url, 'caminho' => $path, 'dados' => $data]);
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            WebhookLogger::error('Erro curl no Firebase PUT', ['erro' => $error, 'caminho' => $path]);
            return false;
        }
        
        if ($httpCode !== 200) {
            WebhookLogger::error('Falha no Firebase PUT', ['codigo_http' => $httpCode, 'caminho' => $path, 'resposta' => $response]);
            return false;
        }
        
        WebhookLogger::success('Firebase PUT realizado com sucesso', ['caminho' => $path, 'dados' => $data]);
        return json_decode($response, true);
    }
    
    public function patch($path, $data) {
        $url = $this->baseUrl . '/' . ltrim($path, '/') . '.json';
        WebhookLogger::debug('RequisiÃ§Ã£o PATCH para Firebase', ['url' => $url, 'caminho' => $path, 'dados' => $data]);
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PATCH');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            WebhookLogger::error('Erro curl no Firebase PATCH', ['erro' => $error, 'caminho' => $path]);
            return false;
        }
        
        if ($httpCode !== 200) {
            WebhookLogger::error('Falha no Firebase PATCH', ['codigo_http' => $httpCode, 'caminho' => $path, 'resposta' => $response]);
            return false;
        }
        
        WebhookLogger::success('Firebase PATCH realizado com sucesso', ['caminho' => $path, 'dados' => $data]);
        return json_decode($response, true);
    }
}

class TokenManager {
    public static function generateToken() {
        WebhookLogger::debug('Gerando novo token');
        
        $response = file_get_contents((getenv('SITE_URL') . '/tokengenerator/'));
        if ($response === false) {
            WebhookLogger::error('Falha ao gerar token', ['url' => (getenv('SITE_URL') . '/tokengenerator/')]);
            return null;
        }
        
        $data = json_decode($response, true);
        if (!$data || !isset($data['token'])) {
            WebhookLogger::error('Resposta de token invÃ¡lida', ['resposta' => $response]);
            return null;
        }
        
        WebhookLogger::success('Token gerado com sucesso', ['token' => substr($data['token'], 0, 8) . '...']);
        return $data['token'];
    }
    
    public static function generateTokens($quantity) {
        $tokens = [];
        for ($i = 0; $i < $quantity; $i++) {
            $token = self::generateToken();
            if ($token) {
                $tokens[] = $token;
            } else {
                WebhookLogger::error('Falha ao gerar token', ['tentativa' => $i + 1, 'quantidade' => $quantity]);
                return false;
            }
        }
        
        WebhookLogger::success('MÃºltiplos tokens gerados', ['quantidade' => count($tokens)]);
        return $tokens;
    }
}

class PaymentManager {
    private $firebase;
    
    public function __construct(FirebaseManager $firebase) {
        $this->firebase = $firebase;
    }
    
    public function getPaymentDetails($paymentId) {
        $url = (getenv('MOCK_URL') . '/v1/payments/') . $paymentId . '?access_token=' . 'token-de-teste';
        WebhookLogger::debug('Buscando detalhes do pagamento', ['id_pagamento' => $paymentId, 'url' => $url]);
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            WebhookLogger::error('Erro curl na API de pagamento', ['erro' => $error, 'id_pagamento' => $paymentId]);
            return false;
        }
        
        if ($httpCode !== 200) {
            WebhookLogger::error('Falha na API de pagamento', ['codigo_http' => $httpCode, 'id_pagamento' => $paymentId, 'resposta' => $response]);
            return false;
        }
        
        $data = json_decode($response, true);
        WebhookLogger::success('Detalhes do pagamento recuperados', ['id_pagamento' => $paymentId, 'status' => $data['status'] ?? 'desconhecido']);
        return $data;
    }
    
    public function isPaymentAlreadyProcessed($paymentId) {
        $pontesmpData = $this->firebase->get("pontesmp/$paymentId");
        
        if ($pontesmpData && isset($pontesmpData['statuspayment']) && $pontesmpData['statuspayment'] === 'aprovada') {
            WebhookLogger::warning('Pagamento jÃ¡ processado', ['id_pagamento' => $paymentId]);
            return true;
        }
        
        WebhookLogger::debug('Pagamento ainda nÃ£o processado', ['id_pagamento' => $paymentId]);
        return false;
    }
    
    public function updatePaymentStatus($paymentId, $status) {
        $result = $this->firebase->patch("pontesmp/$paymentId", ['statuspayment' => $status]);
        
        if ($result !== false) {
            WebhookLogger::success('Status do pagamento atualizado', ['id_pagamento' => $paymentId, 'status' => $status]);
            return true;
        }
        
        WebhookLogger::error('Falha ao atualizar status do pagamento', ['id_pagamento' => $paymentId, 'status' => $status]);
        return false;
    }
}

class TicketProcessor {
    private $firebase;
    private $generatedTokens = [];
    private $tokenPaths = [];
    
    public function __construct(FirebaseManager $firebase) {
        $this->firebase = $firebase;
    }
    
    public function processTickets($paymentId) {
        WebhookLogger::info('ðŸŽ« Processando ingressos', ['id_pagamento' => $paymentId]);
        
        // Buscar dados do pagamento no Firebase
        $pontesmpData = $this->firebase->get("pontesmp/$paymentId");
        if (!$pontesmpData) {
            WebhookLogger::error('Dados do pagamento nÃ£o encontrados', ['id_pagamento' => $paymentId]);
            return false;
        }
        
        $usercpf = $pontesmpData['usercpf'] ?? null;
        $codcarrinho = $pontesmpData['codcarrinho'] ?? null;
        $eventid = $pontesmpData['eventId'] ?? null;
        
        if (!$usercpf || !$codcarrinho || !$eventid) {
            WebhookLogger::error('Dados obrigatÃ³rios ausentes', ['id_pagamento' => $paymentId]);
            return false;
        }
        
        // Buscar quantidade total de ingressos
        $untData = $this->firebase->get("cookiesfixo/$codcarrinho/unt");
        $untValue = (int)$untData;
        
        WebhookLogger::info('ðŸ“Š Quantidade total de ingressos', ['quantidade' => $untValue]);
        
        if ($untValue < 1 || $untValue > 5) {
            WebhookLogger::error('Quantidade invÃ¡lida', ['quantidade' => $untValue]);
            return false;
        }
        
        // Gerar tokens
        $tokens = TokenManager::generateTokens($untValue);
        if (!$tokens) {
            WebhookLogger::error('Falha ao gerar tokens', ['quantidade' => $untValue]);
            return false;
        }
        
        $this->generatedTokens = $tokens;
        
        WebhookLogger::success('ðŸŽŸï¸ Ingressos gerados', [
            'tokens' => array_map(function($token) { return substr($token, 0, 8) . '...'; }, $tokens)
        ]);
        
        // Buscar tipos de tokens e criar lista plana
        $tiposData = $this->firebase->get("cookiesfixo/$codcarrinho/tipos");
        $tokenTypesList = $this->createTokenTypesList($tiposData);
        
        WebhookLogger::debug('Lista de tipos de tokens criada', ['tipos' => $tokenTypesList]);
        
        // Atualizar tokens no Firebase
        $this->updateTokensInFirebase($codcarrinho, $tokens, $tokenTypesList);
        
        // Processar cada token
        foreach ($tokens as $index => $token) {
            $tokentype = $tokenTypesList[$index] ?? $tokenTypesList[0]; // Fallback para o primeiro tipo
            $this->processToken($eventid, $usercpf, $codcarrinho, $token, $tokentype, $paymentId);
        }
        
        WebhookLogger::success('ðŸ“ Ingressos enviados para os caminhos', [
            'caminho_1' => "ingressos/$eventid/disponiveis",
            'caminho_2' => "users/cpf/$usercpf/ingressoscomprados", 
            'caminho_3' => "empresas/[empresa]/vendas/vendasrealizadas/$eventid"
        ]);
        
        // Enviar email
        $this->sendConfirmationEmail($usercpf, $eventid, $tokens, $paymentId);
        
        $this->verifyTokensInPaths($eventid, $usercpf, $tokens);
        
        return true;
    }
    
    /**
     * Cria uma lista plana de tipos de tokens baseada nas quantidades especificadas
     * 
     * @param array $tiposData Dados dos tipos no formato: {"Feminino": {"nometipo": "Feminino", "unt": 2}, "Masculino": {"nometipo": "Masculino", "unt": 3}}
     * @return array Lista plana de tipos: ["Feminino", "Feminino", "Masculino", "Masculino", "Masculino"]
     */
    private function createTokenTypesList($tiposData) {
        $tokenTypesList = [];
        
        if (!$tiposData || !is_array($tiposData)) {
            WebhookLogger::warning('Dados de tipos nÃ£o encontrados ou invÃ¡lidos, usando tipo padrÃ£o');
            return ['PadrÃ£o']; // Fallback para tipo padrÃ£o
        }
        
        WebhookLogger::debug('Dados de tipos recebidos', ['tipos_data' => $tiposData]);
        
        // Iterar sobre cada tipo e adicionar Ã  lista baseado na quantidade
        foreach ($tiposData as $tipoKey => $tipoInfo) {
            if (!is_array($tipoInfo) || !isset($tipoInfo['nometipo']) || !isset($tipoInfo['unt'])) {
                WebhookLogger::warning('Dados de tipo invÃ¡lidos', ['tipo_key' => $tipoKey, 'tipo_info' => $tipoInfo]);
                continue;
            }
            
            $nometipo = $tipoInfo['nometipo'];
            $quantidade = (int)$tipoInfo['unt'];
            
            WebhookLogger::debug('Processando tipo', ['nome' => $nometipo, 'quantidade' => $quantidade]);
            
            // Adicionar o tipo Ã  lista o nÃºmero de vezes especificado pela quantidade
            for ($i = 0; $i < $quantidade; $i++) {
                $tokenTypesList[] = $nometipo;
            }
        }
        
        if (empty($tokenTypesList)) {
            WebhookLogger::warning('Nenhum tipo vÃ¡lido encontrado, usando tipo padrÃ£o');
            return ['PadrÃ£o'];
        }
        
        WebhookLogger::success('Lista de tipos criada com sucesso', [
            'total_tokens' => count($tokenTypesList),
            'tipos_distribuicao' => array_count_values($tokenTypesList)
        ]);
        
        return $tokenTypesList;
    }
    
    private function updateTokensInFirebase($codcarrinho, $tokens, $tokenTypesList) {
        // Criar estrutura de tokens para o Firebase
        $tokensData = [];
        
        foreach ($tokens as $index => $token) {
            $tokenKey = 'token' . ($index + 1);
            $tokensData[$tokenKey] = $token;
        }
        
        // Criar estrutura de tipos para o Firebase
        $typesData = [];
        foreach ($tokenTypesList as $index => $type) {
            $typeKey = 'tokentype' . ($index + 1);
            $typesData[$typeKey] = $type;
        }
        
        // Atualizar no Firebase
        $this->firebase->put("cookiesfixo/$codcarrinho/tokens", $tokensData);
        $this->firebase->put("cookiesfixo/$codcarrinho/tokentypes", $typesData);
        
        WebhookLogger::success('Tokens e tipos atualizados no Firebase', [
            'tokens_count' => count($tokensData),
            'types_count' => count($typesData)
        ]);
    }
    
    private function processToken($eventid, $usercpf, $codcarrinho, $token, $tokentype, $paymentId) {
        // Buscar dados do carrinho
        $cookieData = $this->firebase->get("cookiesfixo/$codcarrinho");
        if (!$cookieData) {
            WebhookLogger::error('Dados do carrinho nÃ£o encontrados', ['codcarrinho' => $codcarrinho]);
            return;
        }
        
        $unt = $cookieData['unt'] ?? 1;
        $valortotal = $cookieData['valortotal'] ?? 0;
        $methodpayment = 'CARTÃƒO';
        
        // Salvar em ingressos disponÃ­veis
        $ticketPath = "ingressos/$eventid/disponiveis/$token";
        $ticketData = [
            'compradorcpf' => $usercpf,
            'horariovalidado' => null,
            'validado' => false,
            'token' => $token,
            'methodpayment' => $methodpayment,
            'isvalidaded' => false,
            'datebuy' => date('Y-m-d'),
            'horariocompra' => date('H:i:s'),
            'tipo' => $tokentype, // Adicionar o tipo do token
        ];
        
        $this->firebase->put($ticketPath, $ticketData);
        
        // Salvar em ingressoscomprados do usuÃ¡rio
        $userTicketPath = "users/cpf/$usercpf/ingressoscomprados/$token";
        $userTicketData = [
            'eventid' => $eventid,
            'compradorcpf' => $usercpf,
            'unt' => $unt,
            'valortotal' => $valortotal,
            'methodpayment' => $methodpayment,
            'tipo' => $tokentype,
            'token' => $token,
        ];
        
        $this->firebase->put($userTicketPath, $userTicketData);
        
        // Processar vendas da empresa
        $this->processCompanySales($eventid, $usercpf, $codcarrinho, $token, $unt, $valortotal, $methodpayment, $tokentype);
        
        WebhookLogger::debug('Token processado', [
            'token' => substr($token, 0, 8) . '...',
            'tipo' => $tokentype,
            'evento' => $eventid
        ]);
    }
    
    private function verifyTokensInPaths($eventid, $usercpf, $tokens) {
        WebhookLogger::info('ðŸ” Verificando tokens nos caminhos');
        
        $missingTokens = [];
        
        foreach ($tokens as $token) {
            // Caminho 1: ingressos/disponiveis
            $path1 = "ingressos/$eventid/disponiveis/$token";
            $data1 = $this->firebase->get($path1);
            if (!$data1) {
                $missingTokens[] = ['token' => substr($token, 0, 8) . '...', 'caminho' => 'disponiveis'];
                // Tentar recriar
                $this->recreateTokenInPath1($eventid, $token, $usercpf);
            }
            
            // Caminho 2: users/ingressoscomprados
            $path2 = "users/cpf/$usercpf/ingressoscomprados/$token";
            $data2 = $this->firebase->get($path2);
            if (!$data2) {
                $missingTokens[] = ['token' => substr($token, 0, 8) . '...', 'caminho' => 'usuario'];
                // Tentar recriar
                $this->recreateTokenInPath2($eventid, $token, $usercpf);
            }
            
            // Caminho 3: empresas/vendas (buscar empresa vinculada)
            $eventData = $this->firebase->get("eventos/$eventid");
            $linkedCompanyId = $eventData['empresavinculada'] ?? null;
            if ($linkedCompanyId) {
                $path3 = "empresas/$linkedCompanyId/vendas/vendasrealizadas/$eventid/$token";
                $data3 = $this->firebase->get($path3);
                if (!$data3) {
                    $missingTokens[] = ['token' => substr($token, 0, 8) . '...', 'caminho' => 'empresa'];
                    // Tentar recriar
                    $this->recreateTokenInPath3($linkedCompanyId, $eventid, $token, $usercpf);
                }
            }
        }
        
        if (empty($missingTokens)) {
            WebhookLogger::success('âœ… Todos os tokens verificados e existentes nos 3 caminhos');
        } else {
            WebhookLogger::error('âŒ Tokens ausentes encontrados e recriados', ['tokens_ausentes' => $missingTokens]);
        }
    }
    
    private function recreateTokenInPath1($eventid, $token, $usercpf) {
        $ticketData = [
            'compradorcpf' => $usercpf,
            'horariovalidado' => null,
            'validado' => false,
            'token' => $token,
            'methodpayment' => 'CARTÃƒO',
            'isvalidaded' => false,
            'datebuy' => date('Y-m-d'),
            'horariocompra' => date('H:i:s'),
        ];
        
        $this->firebase->put("ingressos/$eventid/disponiveis/$token", $ticketData);
        WebhookLogger::success('ðŸ”§ Token recriado em disponÃ­veis', ['token' => substr($token, 0, 8) . '...']);
    }
    
    private function recreateTokenInPath2($eventid, $token, $usercpf) {
        $userTicketData = [
            'eventid' => $eventid,
            'compradorcpf' => $usercpf,
            'methodpayment' => 'CARTÃƒO',
            'token' => $token,
            'tipo' => 'PadrÃ£o',
        ];
        
        $this->firebase->put("users/cpf/$usercpf/ingressoscomprados/$token", $userTicketData);
        WebhookLogger::success('ðŸ”§ Token recriado no perfil do usuÃ¡rio', ['token' => substr($token, 0, 8) . '...']);
    }
    
    private function recreateTokenInPath3($linkedCompanyId, $eventid, $token, $usercpf) {
        $salesData = [
            'compradorcpf' => $usercpf,
            'datebuy' => date('Y-m-d'),
            'horariocompra' => date('H:i:s'),
            'methodpayment' => 'CARTÃƒO',
            'token' => $token,
        ];
        
        $this->firebase->put("empresas/$linkedCompanyId/vendas/vendasrealizadas/$eventid/$token", $salesData);
        WebhookLogger::success('ðŸ”§ Token recriado nas vendas da empresa', ['token' => substr($token, 0, 8) . '...']);
    }
    
    private function processCompanySales($eventid, $usercpf, $codcarrinho, $token, $unt, $valortotal, $methodpayment, $tokentype) {
        // Buscar empresa vinculada
        $eventData = $this->firebase->get("eventos/$eventid");
        $linkedCompanyId = $eventData['empresavinculada'] ?? null;
        
        if (!$linkedCompanyId) {
            return;
        }
        
        // Criar estrutura de vendas se nÃ£o existir
        $this->ensureCompanySalesStructure($linkedCompanyId);
        
        // Salvar venda
        $salesPath = "empresas/$linkedCompanyId/vendas/vendasrealizadas/$eventid/$token";
        $salesData = [
            'compradorcpf' => $usercpf,
            'datebuy' => date('Y-m-d'),
            'horariocompra' => date('H:i:s'),
            'codcarrinho' => $codcarrinho,
            'unt' => $unt,
            'valortotal' => $valortotal,
            'methodpayment' => $methodpayment,
            'tipo' => $tokentype, // Adicionar o tipo do token
        ];
        
        $this->firebase->put($salesPath, $salesData);
        
        // Atualizar saldo da empresa (apenas uma vez por pagamento)
        static $saldoUpdated = [];
        if (!isset($saldoUpdated[$linkedCompanyId])) {
            $this->updateCompanyBalance($linkedCompanyId, $valortotal);
            $saldoUpdated[$linkedCompanyId] = true;
        }
    }
    
    private function ensureCompanySalesStructure($linkedCompanyId) {
        // Verificar e criar estrutura de vendas
        $vendasNode = $this->firebase->get("empresas/$linkedCompanyId/vendas");
        
        // Se houve um erro de comunicaÃ§Ã£o (false), logar e nÃ£o prosseguir para evitar sobrescrita acidental
        if ($vendasNode === false) {
            WebhookLogger::error("Erro crÃ­tico ao verificar nÃ³ de vendas para empresa. Abortando criaÃ§Ã£o/verificaÃ§Ã£o de estrutura.", ["id_empresa" => $linkedCompanyId]);
            return; // Aborta a execuÃ§Ã£o para evitar sobrescrever dados
        }

        // Se o nÃ³ nÃ£o existe (null), entÃ£o cria com um array vazio
        if ($vendasNode === null) {
            $this->firebase->put("empresas/$linkedCompanyId/vendas", []);
            WebhookLogger::debug("NÃ³ de vendas criado (anteriormente inexistente) para empresa.", ["id_empresa" => $linkedCompanyId]);
        }
        
        // Repetir a lÃ³gica para vendasrealizadas
        $vendasRealizadasNode = $this->firebase->get("empresas/$linkedCompanyId/vendas/vendasrealizadas");
        
        // Se houve um erro de comunicaÃ§Ã£o (false), logar e nÃ£o prosseguir
        if ($vendasRealizadasNode === false) {
            WebhookLogger::error("Erro crÃ­tico ao verificar nÃ³ de vendas realizadas para empresa. Abortando criaÃ§Ã£o/verificaÃ§Ã£o de estrutura.", ["id_empresa" => $linkedCompanyId]);
            return; // Aborta a execuÃ§Ã£o
        }

        // Se o nÃ³ nÃ£o existe (null), entÃ£o cria com um array vazio
        if ($vendasRealizadasNode === null) {
            $this->firebase->put("empresas/$linkedCompanyId/vendas/vendasrealizadas", []);
            WebhookLogger::debug("NÃ³ de vendas realizadas criado (anteriormente inexistente) para empresa.", ["id_empresa" => $linkedCompanyId]);
        }
    }
    
    private function updateCompanyBalance($linkedCompanyId, $valortotal) {
        $companyData = $this->firebase->get("empresas/$linkedCompanyId");
        if (!$companyData) {
            WebhookLogger::error('Dados da empresa nÃ£o encontrados', ['id_empresa' => $linkedCompanyId]);
            return;
        }
        
        $saldoDisponivel = $companyData['saldo_disponivel'] ?? 0;
        $valorComDesconto = $valortotal - ($valortotal * 0.10); // 10% de desconto
        $novoSaldo = $saldoDisponivel + $valorComDesconto;
        
        $this->firebase->put("empresas/$linkedCompanyId/saldo_disponivel", $novoSaldo);
        
        WebhookLogger::success('Saldo da empresa atualizado', [
            'id_empresa' => $linkedCompanyId,
            'saldo_anterior' => $saldoDisponivel,
            'novo_saldo' => $novoSaldo,
            'valor_adicionado' => $valorComDesconto,
            'valor_original' => $valortotal
        ]);
    }
    
    private function sendConfirmationEmail($usercpf, $eventid, $tokens, $paymentId) {
        WebhookLogger::debug('Enviando email de confirmaÃ§Ã£o', [
            'cpf_usuario' => $usercpf,
            'id_evento' => $eventid,
            'id_pagamento' => $paymentId,
            'quantidade_tokens' => count($tokens)
        ]);
        
        try {
            // Buscar dados do usuÃ¡rio
            $userData = $this->firebase->get("users/cpf/$usercpf");
            $email = $userData['email'] ?? 'nao-responda@piauitickets.com';
            $fullName = $userData['fullname'] ?? 'UsuÃ¡rio';
            
            // Buscar dados do evento
            $eventData = $this->firebase->get("eventos/$eventid");
            $eventName = $eventData['nomeevento'] ?? 'Evento Desconhecido';
            
            @file_get_contents(getenv('MOCK_URL') . '/smtp'); // TESTE: envio de e-mail simulado
            
            WebhookLogger::success('Email de confirmaÃ§Ã£o enviado', [
                'email' => $email,
                'nome_completo' => $fullName,
                'nome_evento' => $eventName,
                'id_pagamento' => $paymentId
            ]);
            
        } catch (Exception $e) {
            WebhookLogger::error('Falha ao enviar email de confirmaÃ§Ã£o', [
                'erro' => $e->getMessage(),
                'cpf_usuario' => $usercpf,
                'id_pagamento' => $paymentId
            ]);
        }
    }
    
    private function generateEmailBody($eventName, $fullName) {
        return '
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #000000;
            color: #ffffff;
        }
        .container {
            width: 100%;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #1f1f1f;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
        }
        h1 { color: #ffffff; }
        h2 { color: #ffffff; }
        p {
            font-size: 16px;
            color: #e0e0e0;
            line-height: 1.6;
        }
        .event-info {
            margin: 20px 0;
            padding: 10px;
            background-color: #333333;
            border: 1px solid #444444;
            border-radius: 4px;
        }
        .footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #cccccc;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Obrigado pela Compra, ' . htmlspecialchars($fullName) . '!</h1>
        <p>Seu ingresso foi gerado com sucesso.</p>
        
        <div class="event-info">
            <h2>Compra processada com sucesso</h2>
            <p><strong>Veja seu ingresso fazendo login em sua conta na Ã¡rea do UsuÃ¡rio. EVENTO:</strong> ' . htmlspecialchars($eventName) . '</p>
        </div>
        
        <div class="footer">
            <p>PI TICKETS - Todos os direitos reservados</p>
        </div>
    </div>
</body>
</html>';
    }
}

function processWebhook() {
    WebhookLogger::info('ðŸš€ NotificaÃ§Ã£o recebida');
    
    // Ler dados do webhook
    $input = file_get_contents("php://input");
    
    if (!$input) {
        http_response_code(400);
        WebhookLogger::error('Nenhum dado recebido');
        echo json_encode(['error' => 'Nenhum dado recebido']);
        return;
    }
    
    // Decodificar JSON
    $data = json_decode($input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        http_response_code(400);
        WebhookLogger::error('JSON invÃ¡lido');
        echo json_encode(['error' => 'JSON invÃ¡lido']);
        return;
    }
    
    // Validar estrutura dos dados
    if (!isset($data['action'], $data['type'], $data['data']['id'])) {
        http_response_code(400);
        WebhookLogger::error('Dados incompletos');
        echo json_encode(['error' => 'Dados incompletos']);
        return;
    }
    
    // Responder imediatamente ao Mercado Pago
    http_response_code(200);
    echo json_encode(['status' => 'received']);
    
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    }
    
    // Extrair dados do webhook
    $action = $data['action'];
    $type = $data['type'];
    $paymentId = $data['data']['id'];
    
    // Processar apenas eventos de pagamento
    if ($type !== 'payment' || !in_array($action, ['payment.created', 'payment.updated'])) {
        return;
    }
    
    // Inicializar managers
    $firebase = new FirebaseManager(getenv('FIREBASE_URL'));
    $paymentManager = new PaymentManager($firebase);
    $ticketProcessor = new TicketProcessor($firebase);
    
    // Verificar se jÃ¡ foi processado
    if ($paymentManager->isPaymentAlreadyProcessed($paymentId)) {
        return;
    }
    
    // Buscar detalhes do pagamento
    $paymentDetails = $paymentManager->getPaymentDetails($paymentId);
    if (!$paymentDetails) {
        WebhookLogger::error('Falha ao obter detalhes do pagamento', ['id' => $paymentId]);
        return;
    }
    
    $status = $paymentDetails['status'];
    
    if ($status === 'approved') {
        WebhookLogger::success('âœ… Pagamento aprovado', ['id' => $paymentId]);
    } else {
        WebhookLogger::info('â³ Status do pagamento', ['id' => $paymentId, 'status' => $status]);
    }
    
    // Processar baseado na aÃ§Ã£o
    if ($action === 'payment.created') {
        $pontesmpData = $firebase->get("pontesmp/$paymentId");
        if ($pontesmpData) {
            if ($status !== 'approved') {
                // Se nÃ£o estiver aprovado ainda, coloca como pendente
                $paymentManager->updatePaymentStatus($paymentId, 'pending');
            }
        }
    }

    // Se for approved (tanto no created quanto updated), processa
    if (($action === 'payment.updated' || $action === 'payment.created') && $status === 'approved') {
        if ($paymentManager->updatePaymentStatus($paymentId, 'aprovada')) {
            if ($ticketProcessor->processTickets($paymentId)) {
                WebhookLogger::success('ðŸŽ‰ Processamento concluÃ­do com sucesso', ['id' => $paymentId]);
            } else {
                WebhookLogger::error('Falha ao processar ingressos', ['id' => $paymentId]);
            }
        }
    }
}

try {
    processWebhook();
} catch (Exception $e) {
    WebhookLogger::error('Processamento do webhook falhou com exceÃ§Ã£o', [
        'erro' => $e->getMessage(),
        'arquivo' => $e->getFile(),
        'linha' => $e->getLine(),
        'trace' => $e->getTraceAsString()
    ]);
    
    http_response_code(500);
    echo json_encode(['error' => 'Erro interno do servidor']);
} catch (Error $e) {
    WebhookLogger::error('Processamento do webhook falhou com erro fatal', [
        'erro' => $e->getMessage(),
        'arquivo' => $e->getFile(),
        'linha' => $e->getLine(),
        'trace' => $e->getTraceAsString()
    ]);
    
    http_response_code(500);
    echo json_encode(['error' => 'Erro fatal do servidor']);
}

WebhookLogger::info('ExecuÃ§Ã£o do webhook concluÃ­da', [
    'pico_memoria' => memory_get_peak_usage(true),
    'tempo_execucao' => microtime(true) - $_SERVER['REQUEST_TIME_FLOAT']
]);
?>
