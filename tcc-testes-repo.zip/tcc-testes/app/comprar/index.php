<?php

// Configurar o tempo de vida da sessão (ex: 3 dias)
ini_set("session.gc_maxlifetime", 259200);
ini_set("session.cookie_lifetime", 259200);

// Iniciar sessão para verificar login
session_start();

// Verificar se o usuário já está logado
$is_logged_in = isset($_SESSION["user_data"]);
$user_data_json = $is_logged_in ? json_encode($_SESSION["user_data"]) : "null";

// Cabeçalhos HTTP
header("Access-Control-Allow-Origin: *");
header("Referrer-Policy: no-referrer-when-downgrade");
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

// --- Funções do código original (totalmente preservadas) ---
function getEventDetails($eventId)
{
    // E4: os dados do evento vem da API de cache (servidor 3, Redis); se ela falhar, le o banco direto.
    $cacheUrl = getenv('CACHE_URL');
    if ($cacheUrl) {
        $ctx = stream_context_create(['http' => ['timeout' => 5]]);
        $resp = @file_get_contents(rtrim($cacheUrl, '/') . '/evento/' . $eventId, false, $ctx);
        if ($resp !== false && $resp !== 'null') {
            return json_decode($resp, true);
        }
    }
    $url = rtrim(getenv('FIREBASE_URL'), '/') . '/eventos/' . $eventId . '.json';
    $response = file_get_contents($url);
    if ($response === FALSE) {
        die('Erro ao obter dados do Firebase');
    }
    return json_decode($response, true);
}

function isSocialMediaBrowser() {
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    return preg_match('/FBAN|FBAV|Instagram/', $userAgent);
}

function getOperatingSystem() {
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    if (preg_match('/iPhone|iPad|iPod/', $userAgent)) {
        return 'iOS';
    } elseif (preg_match('/Android/', $userAgent)) {
        return 'Android';
    }
    return 'Other';
}

// Obtendo a URL atual
$requestUri = $_SERVER['REQUEST_URI'];

preg_match('#/comprar/(\d+)/#', $requestUri, $matches);

if (!isset($matches[1])) {
    die('ID do evento não encontrado na URL');
}

$eventId = $matches[1];
$eventDetails = getEventDetails($eventId);

if (!$eventDetails) {
    die('Evento não encontrado');
}

// === BUSCAR LIMITES POR TIPO DE INGRESSO DA API ===
$limitesAPI = null;
$limitesPorTipo = [];

try { if (getenv('CHAMA_ORGANIZADOR') === '1') { // TESTE: desligado no estagio E1
    // 🆕 VERIFICAR SE PRECISA TROCAR LOTE AUTOMATICAMENTE
    $verificarLoteUrl = getenv('MOCK_URL') . '/verificar-lote';
    $verificarLoteData = json_encode(['eventoId' => $eventId]);
    
    $verificarLoteOptions = [
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/json',
            'content' => $verificarLoteData,
            'timeout' => 5
        ]
    ];
    
    $verificarLoteContext = stream_context_create($verificarLoteOptions);
    $verificarLoteResponse = @file_get_contents($verificarLoteUrl, false, $verificarLoteContext);
    
    if ($verificarLoteResponse !== false) {
        $verificarLoteResult = json_decode($verificarLoteResponse, true);
        
        if ($verificarLoteResult && isset($verificarLoteResult['trocado']) && $verificarLoteResult['trocado'] === true) {
            // Lote foi trocado! Recarregar dados do evento
            error_log('🔄 LOTE TROCADO AUTOMATICAMENTE! Recarregando dados do evento...');
            $eventDetails = getEventDetails($eventId); // Buscar dados atualizados
        }
    }
    
    // Buscar configurações e limites do evento
    $apiUrl = getenv('MOCK_URL') . '/configuracoes-evento?eventoId=' . $eventId;
    $apiResponse = @file_get_contents($apiUrl);
    
    if ($apiResponse !== false) {
        $limitesAPI = json_decode($apiResponse, true);
        
        if ($limitesAPI && isset($limitesAPI['success']) && $limitesAPI['success'] === true) {
            // Criar um mapa de limites por tipo de ingresso
            if (isset($limitesAPI['limitePorTipo']) && is_array($limitesAPI['limitePorTipo'])) {
                foreach ($limitesAPI['limitePorTipo'] as $limite) {
                    $limitesPorTipo[$limite['tipo']] = [
                        'ativo' => $limite['ativo'],
                        'limite' => $limite['limite'],
                        'vendido' => $limite['vendido'],
                        'disponivel' => $limite['disponivel'],
                        'esgotado' => $limite['esgotado']
                    ];
                }
            }
        }
    }
} } catch (Exception $e) {
    // Se a API não estiver disponível, continua normalmente sem limites
    error_log('Erro ao buscar limites da API: ' . $e->getMessage());
}

// Preço do ingresso
$ticketPrice = isset($eventDetails['valortotal']) && $eventDetails['valortotal'] !== null && $eventDetails['valortotal'] !== "null"
    ? (float) $eventDetails['valortotal']
    : (isset($eventDetails['valorbruto']) ? (float) $eventDetails['valorbruto'] : 0);

// --- Verificação de preços promocionais ---
$promocionalData = null;
if (isset($eventDetails['promocional']) && is_array($eventDetails['promocional'])) {
    $promocionalData = $eventDetails['promocional'];
}

    // --- Limite de compra por CPF ---
$limitarcompra = false;
$limitedecompracpf = null;

if (isset($eventDetails['limitar']['limitarcompra']) && $eventDetails['limitar']['limitarcompra'] === true) {
    $limitarcompra = true;
    $limitedecompracpf = isset($eventDetails['limitar']['limitedecompracpf']) ? (int) $eventDetails['limitar']['limitedecompracpf'] : null;
}

// Redirecionamento para fora do navegador de rede social
if (isSocialMediaBrowser()) {
    $os = getOperatingSystem();
    $url = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

    echo "<script>
        if (window.navigator && window.navigator.userAgent) {
            var userAgent = navigator.userAgent || '';
            if (userAgent.includes('Instagram') || userAgent.includes('FBAV')) {
                if ('$os' === 'iOS') {
                    window.open('$url', '_blank');
                } else if ('$os' === 'Android') {
                    window.location.href = 'googlechrome://' + '$url';
                } else {
                    window.location.href = '$url';
                }
            }
        }
    </script>";
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($eventDetails["nomeevento"] ?? "Detalhes do Evento"); ?> | PI TICKETS</title>
    <link rel="stylesheet" href="style.css"> 
    <link rel="icon" href="../../../images/favicon.ico" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="32x32" href="../../../images/favicon-32x32.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&display=swap">
    <script>
        const IS_LOGGED_IN = <?php echo json_encode($is_logged_in); ?>;
        const USER_DATA = <?php echo $user_data_json; ?>;
        const EVENT_ID = <?php echo json_encode($eventId); ?>;
        const LIMITAR_COMPRA_ATIVO = <?php echo $limitarcompra ? 'true' : 'false'; ?>;
        const LIMITE_POR_CPF = <?php echo $limitedecompracpf ?? 'null'; ?>;
        const PROMOCIONAL_DATA = <?php echo json_encode($promocionalData); ?>;
    </script>
</head>
<body>
    <header> 
        <a href="/index.php"><img src="../../../images/logo.png" alt="Logo PI TICKETS" class="logo"></a> 
        <div class="header-links"> 
            <a href="/cadastro">Cadastro</a> 
            <a href="/login">Área do Usuário</a> 
            <a href="/area-do-organizador">Área do Organizador</a> 
        </div> 
        <button class="menu-button"> 
            <div></div> <div></div> <div></div> 
        </button> 
        <div class="menu"> 
            <a href="/cadastro">Cadastro</a> 
            <a href="/login">Área do Usuário</a> 
            <a href="/area-do-organizador">Área do Organizador</a> 
        </div> 
    </header> 

    <main class="event-page-container">
        <div class="event-visual-column">
            <img src="<?php echo htmlspecialchars($eventDetails["imageurl"] ?? ""); ?>" alt="<?php echo htmlspecialchars($eventDetails["nomeevento"] ?? "Imagem do Evento"); ?>" class="event-image-vertical">
        </div>

        <div class="event-info-column">
            <h1><?php echo htmlspecialchars($eventDetails["nomeevento"] ?? "Nome do Evento"); ?></h1>
            <div class="event-meta">
                <p><i class="fas fa-calendar-alt"></i> <strong>Data:</strong>&nbsp;<?php echo htmlspecialchars($eventDetails["datainicio"] ?? "N/D"); ?></p>
                <p><i class="fas fa-clock"></i> <strong>Hora:</strong>&nbsp;<?php echo htmlspecialchars($eventDetails["aberturaportas"] ?? "N/D"); ?></p>
                <p><i class="fas fa-map-marker-alt"></i> <strong>Local:</strong>&nbsp;<?php echo htmlspecialchars($eventDetails["local"] ?? "N/D"); ?></p>
            </div>
            
            <h2>Sobre o Evento</h2>
            <p class="event-description"><?php echo nl2br(htmlspecialchars($eventDetails["informaçõesadicionais"] ?? "Sem informações adicionais.")); ?></p>
            
            <!-- <div class="map-container-inline">
                <h3>Localização</h3>
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3974.210039344851!2d-42.7950527!3d-5.069677!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x78e3900213e58d7%3A0x385738887abd4f0a!2sDominique%20Bar!5e0!3m2!1spt-BR!2sbr!4v1736734380299!5m2!1spt-BR!2sbr" 
                    width="100%" 
                    height="250" 
                    style="border:0; border-radius: 8px;" 
                    allowfullscreen="" 
                    loading="lazy" 
                    referrerpolicy="no-referrer-when-downgrade">
                </iframe>
            </div>  !-->
        </div>

        <div class="ticket-purchase-column">
            <div class="ticket-form-container-redesigned">
                <form id="ticketForm" action="/checkout" method="GET">
                    <div class="ticket-header">
                        <h2><i class="fas fa-ticket-alt"></i> Ingressos</h2>
                        <p><strong>Lote:</strong> <?php echo htmlspecialchars($eventDetails["nameloteevent"] ?? "Atual"); ?></p>
                        <hr>
                    </div>

                    <!-- Aviso fixo removido, o alerta dinâmico será usado -->

                    <div id="ticket-types" class="ticket-types-container-redesigned">
    <?php
    if (isset($eventDetails["tipos"]) && is_array($eventDetails["tipos"])) {
        // Ordena por idselection
        usort($eventDetails["tipos"], function ($a, $b) {
            return ($a["idselection"] ?? 999) <=> ($b["idselection"] ?? 999);
        });

        foreach ($eventDetails["tipos"] as $details) {
            $valor_com_taxa = (float)($details["valorbruto"] ?? 0);
            $valor_sem_taxa = $valor_com_taxa / 1.10; // Assumindo taxa de 10%
            $taxa = $valor_com_taxa - $valor_sem_taxa;
            
            $nomeTipo = $details["nometipo"] ?? "Tipo Indefinido";

            // Verificar se existe preço promocional para este tipo
            $valor_promocional = null;
            $quantidade_promocional = null;
            if ($promocionalData && isset($promocionalData['quantidadecart']) && isset($promocionalData['valorbruto'])) {
                $quantidade_promocional = (int)$promocionalData['quantidadecart'];
                $valor_promocional = (float)$promocionalData['valorbruto'];
            }
            
            // === VERIFICAR LIMITE DA API ===
            $limiteMax = 5; // Padrão
            $tipoEsgotado = false;
            $mensagemLimite = '';
            
            if (isset($limitesPorTipo[$nomeTipo])) {
                $limiteInfo = $limitesPorTipo[$nomeTipo];
                
                if ($limiteInfo['ativo']) {
                    if ($limiteInfo['esgotado']) {
                        $tipoEsgotado = true;
                        // Não mostrar mensagem ao lado, só o ESGOTADO vermelho
                    } else {
                        // Limitar ao número disponível
                        $limiteMax = min($limiteInfo['disponivel'], 5);
                        
                        // Mostrar aviso APENAS se restam 5 ou menos
                        if ($limiteInfo['disponivel'] <= 5) {
                            $mensagemLimite = '<span style="color: #cc0000; font-size: 0.85rem; font-weight: 600;">(Restam apenas ' . $limiteInfo['disponivel'] . ')</span>';
                        }
                    }
                }
            }

            echo '<div class="ticket-type-redesigned' . ($tipoEsgotado ? ' esgotado' : '') . '" 
                    data-valorbruto="' . htmlspecialchars($valor_com_taxa) . '" 
                    data-nometipo="' . htmlspecialchars($nomeTipo) . '"
                    data-valorpromocional="' . htmlspecialchars($valor_promocional ?? '') . '"
                    data-quantidadepromocional="' . htmlspecialchars($quantidade_promocional ?? '') . '"
                    data-limite-max="' . $limiteMax . '"
                    data-esgotado="' . ($tipoEsgotado ? 'true' : 'false') . '">
                    <div class="ticket-type-info">
                        <span class="ticket-type-name">' . htmlspecialchars($nomeTipo) . '</span>';
            
            if (!$tipoEsgotado) {
                echo '<span class="ticket-price">R$ ' . number_format($valor_sem_taxa, 2, ',', '.') . '</span>
                        <span class="ticket-tax">+ R$ ' . number_format($taxa, 2, ',', '.') . ' (taxa)</span>';
                
                // Mostrar aviso de estoque baixo
                if (!empty($mensagemLimite)) {
                    echo '<div style="margin-top: 4px;">' . $mensagemLimite . '</div>';
                }
            } else {
                echo '<span class="ticket-price" style="color: #cc0000; font-weight: bold; font-size: 1.1rem;">ESGOTADO</span>';
            }
            
            // Se existe promoção, mostrar informação promocional
            if (!$tipoEsgotado && $valor_promocional && $quantidade_promocional) {
                echo '<span class="promotional-info" style="color: #28a745; font-size: 0.8rem; font-weight: bold;">Preço promocional para ' . $quantidade_promocional . ' ingressos!</span>';
            }
            
            echo '</div>
                    <div class="ticket-quantity">';
            
            if ($tipoEsgotado) {
                echo '<button type="button" class="quantity-btn minus" disabled style="opacity: 0.3; cursor: not-allowed;"><i class="fas fa-minus"></i></button>
                        <input type="number" class="quantity-input" value="0" min="0" max="0" readonly disabled style="opacity: 0.5;">
                        <button type="button" class="quantity-btn plus" disabled style="opacity: 0.3; cursor: not-allowed;"><i class="fas fa-plus"></i></button>';
            } else {
                echo '<button type="button" class="quantity-btn minus" onclick="adjustQuantity(this, -1)"><i class="fas fa-minus"></i></button>
                        <input type="number" class="quantity-input" value="0" min="0" max="' . $limiteMax . '" readonly>
                        <button type="button" class="quantity-btn plus" onclick="adjustQuantity(this, 1)"><i class="fas fa-plus"></i></button>';
            }
            
            echo '</div>
                </div>';
        }
    } else {
        echo '<p style="text-align: center;">Nenhum tipo de ingresso disponível no momento.</p>';
    }
    ?>
</div>
<?php
if ($limitarcompra === true && !empty($limitedecompracpf)) {
    echo '<div style="color: #cc0000; font-size: 0.875rem; text-align: center; font-family: Helvetica, Arial, sans-serif; margin-top: 1rem;">
        Esse evento tem limite de compra por CPF de até ' . htmlspecialchars($limitedecompracpf) . ' ingresso(s).
    </div>';
}
?>
<div id="promo-message" class="alert alert-success" style="display: none; margin-top: 10px;"></div>

<div class="total-container-redesigned">
    <p>Total: <strong id="total">R$ 0,00</strong></p>
</div>

<div id="quantity-alert" class="alert alert-danger" style="display: none;">Selecione pelo menos 1 ingresso.</div>


<input type="hidden" name="event_id" value="<?php echo htmlspecialchars($eventId); ?>">
<input type="hidden" name="event_name" value="<?php echo htmlspecialchars($eventDetails["nomeevento"] ?? ""); ?>">
<input type="hidden" name="event_image" value="<?php echo htmlspecialchars($eventDetails["imageurl"] ?? ""); ?>">
<input type="hidden" name="total" id="total_input" value="0">
<!-- Campo oculto account_cookie será adicionado via JS antes do submit -->

<button type="button" class="buy-button" onclick="handlePurchaseClick()">Comprar Ingressos</button>

                </form>
            </div>
        </div>
    </main>

    <footer> 
        <p>&copy; <?php echo date("Y"); ?> PI TICKETS. Todos os direitos reservados.</p> 
        <p> 
            <a href="https://wa.me/5518981719745?text=Olá,%20preciso%20de%20ajuda..."> 
                <img src="https://img.icons8.com/ios-filled/50/ffffff/whatsapp.png" alt="WhatsApp" class="footer-icon"> 
                <strong style="color: white;">(18) 98171-9745</strong> 
            </a> | 
            <a href="mailto:atendimento@piauitickets.com"> 
                <strong style="color: white;">atendimento@piauitickets.com</strong> 
            </a> | 
            <a href="../../../termos"> 
                <strong style="color: white;">Termos de Serviço</strong> 
            </a> 
        </p>
    </footer> 

    <!-- Pop-up de Login Original -->
    <div id="loginPopup" class="popup-overlay">
        <div class="popup-content">
            <button class="close-popup" onclick="closePopup('loginPopup')">&times;</button>
            <h2><i class="fas fa-user-circle"></i> Vincule sua Conta</h2>
            <p>Faça o login para continuar a compra:</p>
            <form id="loginForm" onsubmit="loginUser(event)">
                <div class="form-group">
                    <label for="cpf"><i class="fas fa-id-card"></i> CPF</label>
                    <input type="text" id="cpf" name="cpf" placeholder="Digite seu CPF (apenas números)" required inputmode="numeric">
                </div>
                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Senha</label>
                    <input type="password" id="password" name="password" placeholder="Digite sua senha" required>
                </div>
                <button type="submit" class="btn btn-primary">LOGAR</button>
                <p id="loginMessage" class="error-message"></p>
                <p class="form-links">
                    <a href="/recoverypassword">Esqueceu sua senha?</a>
                    <span> | </span>
                    <a href="/cadastro">Não tem conta? Cadastre-se</a>
                </p>
            </form>
        </div>
    </div>

    <!-- NOVO Pop-up de Seleção de Conta -->
    <div id="accountSelectionPopup" class="popup-overlay">
        <div class="popup-content">
             <button class="close-popup" onclick="closePopup('accountSelectionPopup')">&times;</button>
            <h2><i class="fas fa-user-check"></i> Continuar Compra</h2>
            <p>Você já está logado como:</p>
            <p><strong id="loggedInUserName"></strong> (<span id="loggedInUserEmail"></span>)</p>
            <div class="popup-actions">
                 <button type="button" class="btn btn-success" onclick="continueWithAccount()"><i class="fas fa-check"></i> Continuar com esta conta</button>
                 <button type="button" class="btn btn-secondary" onclick="changeAccount()"><i class="fas fa-exchange-alt"></i> Não, trocar a conta</button>
            </div>
        </div>
    </div>

    <!-- Pop-up de Verificação (pode ser reutilizado ou removido se o fluxo mudar) -->
    <div id="verificationPopup" class="popup-overlay">
        <div class="popup-content">
            <button class="close-popup" onclick="closePopup('verificationPopup')">&times;</button>
            <h2><i class="fas fa-check-circle"></i> Conta Verificada!</h2>
            <p id="verificationName"></p>
            <button id="goToCheckout" class="btn btn-primary" onclick="startCheckoutProcess()">IR PARA CHECKOUT</button>
        </div>
    </div>

    <!-- Pop-up de Carregamento -->
    <div id="loadingPopup" class="popup-overlay loading-popup">
        <div class="loading-popup-content">
            <h2><i class="fas fa-spinner fa-spin"></i> Processando...</h2>
            <p>Adicionando os itens ao carrinho e preparando o checkout.</p>
            <!-- <img src="/images/cartgif.gif" alt="Carregando"> -->
        </div>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="script.js" defer></script>
</body>
</html>