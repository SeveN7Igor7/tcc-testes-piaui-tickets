<?php
// Coleta os dados da URL
$eventId = $_GET["event_id"] ?? "";
$eventName = $_GET["event_name"] ?? "";
$ticketPrice = $_GET["ticket_price"] ?? 0;
$quantity = $_GET["quantidade"] ?? 1;
$total = $_GET["total"] ?? 0;
$accountCookie = $_GET["account_cookie"] ?? "";

// URL do Firebase Realtime Database
$firebaseUrl = rtrim(getenv('FIREBASE_URL'), '/') . '/'; // TESTE: banco de teste

// Função para buscar dados do Firebase
function fetchFirebaseData($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

// ==============================================
// CÓDIGO PARA VERIFICAR SE EVENTO ESTÁ ABERTO (Original)
// ==============================================
$eventStatusUrl = $firebaseUrl . "eventos/" . $eventId . ".json";
$eventData = fetchFirebaseData($eventStatusUrl);

// Verifica o status de venda
$vendaAberta = true; // Default
if (isset($eventData["vendaaberta"])) {
    if (is_bool($eventData["vendaaberta"])) {
        $vendaAberta = $eventData["vendaaberta"];
    }
    elseif (is_array($eventData["vendaaberta"]) || is_object($eventData["vendaaberta"])) {
        $vendaAberta = $eventData["vendaaberta"]["vendaaberta"] ?? true;
    }
}

$semTaxa = isset($eventData["semtaxasite"]) && $eventData["semtaxasite"] === true;

// Se vendaaberta for false, mostra mensagem de evento encerrado (Original)
if ($vendaAberta === false) {
    echo '<!DOCTYPE html><html lang="pt-br"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Vendas Desativadas</title><style>body{font-family:Arial,sans-serif;margin:0;padding:0;display:flex;justify-content:center;align-items:center;height:100vh;background-color:#f8f9fa}.event-block{text-align:center;background:white;padding:2rem;border-radius:8px;box-shadow:0 0 20px rgba(0,0,0,.1);max-width:500px;width:90%}.event-block h1{color:#dc3545;margin-bottom:1rem}.event-block img{width:100px;margin-bottom:1.5rem}.event-block a{display:inline-block;margin-top:1.5rem;padding:.75rem 1.5rem;background:#007bff;color:white;text-decoration:none;border-radius:4px;font-weight:bold}</style></head><body><div class="event-block"><img src="https://cdn-icons-png.flaticon.com/512/564/564619.png" alt="Evento encerrado"><h1>Vendas Desativadas</h1><p>As vendas desse evento estão indisponíveis.</p><p>Para mais informações, entre em contato com o organizador do evento.</p><a href="/">Voltar à página inicial</a></div></body></html>';
    exit();
}
// ==============================================
// FIM DO CÓDIGO DE VERIFICAÇÃO
// ==============================================

$methodpaymentcupom = "CUPOM";
$methodpaymentpix = "PIX";
$methodpaymentcard = "CARTÃO"; // Ensure this is defined for the JS block

// Busca o user ID associado ao cookie (Original)
$cookieUrl = $firebaseUrl . "cookies/" . $accountCookie . ".json";
$cookieData = fetchFirebaseData($cookieUrl);

if (isset($cookieData["user"])) {
    $userCpf = $cookieData["user"];
    $userUrl = $firebaseUrl . "users/cpf/" . $userCpf . ".json";
    $userData = fetchFirebaseData($userUrl);
    $fullName = $userData["fullname"] ?? "Nome não encontrado";
    $emailAccount = $userData["email"] ?? "Email Associado não Encontrado";
} else {
    $fullName = "Usuário não encontrado";
    $userCpf = null; // Ensure $userCpf is defined
    $emailAccount = "Email não encontrado";
}

// Busca dados do carrinho (Original)
$cartUrl = $firebaseUrl . "cookies/" . $accountCookie . ".json";
$cartData = fetchFirebaseData($cartUrl);

// Se o carrinho tiver a key "semtaxa" ativa, também remove a taxa de serviço da exibição (além da flag do evento)
if (isset($cartData["semtaxa"]) && $cartData["semtaxa"] === true) {
    $semTaxa = true;
}

// ==============================================
// VERIFICAÇÃO DE EXPIRAÇÃO DO CARRINHO (10 minutos)
// ==============================================
$TEMPO_LIMITE_CARRINHO = 600; // 10 minutos em segundos
$cartTimestamp = $cartData["timestamp"] ?? null;
$criadoEm = $cartTimestamp ? strtotime($cartTimestamp) : false;
$carrinhoExpirado = ($criadoEm === false) || ((time() - $criadoEm) > $TEMPO_LIMITE_CARRINHO);

if ($carrinhoExpirado) {
    echo '<!DOCTYPE html><html lang="pt-br"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Carrinho Expirado</title><style>body{font-family:Arial,sans-serif;margin:0;padding:0;display:flex;justify-content:center;align-items:center;height:100vh;background-color:#f8f9fa}.event-block{text-align:center;background:white;padding:2rem;border-radius:8px;box-shadow:0 0 20px rgba(0,0,0,.1);max-width:500px;width:90%}.event-block h1{color:#dc3545;margin-bottom:1rem}.event-block img{width:100px;margin-bottom:1.5rem}.event-block a{display:inline-block;margin-top:1.5rem;padding:.75rem 1.5rem;background:#007bff;color:white;text-decoration:none;border-radius:4px;font-weight:bold}</style></head><body><div class="event-block"><img src="https://cdn-icons-png.flaticon.com/512/564/564619.png" alt="Carrinho expirado"><h1>Carrinho Expirado</h1><p>O tempo para finalizar essa compra (10 minutos) foi excedido e os itens reservados foram liberados.</p><p>Por favor, volte à página do evento e refaça a seleção dos ingressos.</p><a href="/">Voltar à página inicial</a></div></body></html>';
    exit();
}

// Segundos restantes até o carrinho expirar, calculado no servidor (fonte confiável de verdade)
$tempoRestanteSegundos = max(0, $TEMPO_LIMITE_CARRINHO - (time() - $criadoEm));
// ==============================================
// FIM DA VERIFICAÇÃO DE EXPIRAÇÃO
// ==============================================

$unt = $cartData["unt"] ?? "Não encontrado";
$valorTotal = (float)($cartData["valortotal"] ?? 0.00);
$valorTotalAdicional = isset($cartData["valortotaladicional"]) ? (float) $cartData["valortotaladicional"] : null;
$temValorAdicional = ($valorTotal == 0.0) && $valorTotalAdicional !== null;
$valorTotalExibicao = $temValorAdicional ? $valorTotalAdicional : $valorTotal;
$valorTotalpix = number_format($valorTotalExibicao, 2, ",", ".");
$valorEmCentavos = (int) round($valorTotalExibicao * 100);

$cupomUtilizado = isset($cartData["cupomutilizado"]) && $cartData["cupomutilizado"] === true;
$cupomKey = $cartData["cupomkey"] ?? null;
$valorOriginal = isset($cartData["valororiginal"]) ? (float) $cartData["valororiginal"] : null;

// Busca os tipos de ingresso (Original)
$tiposUrl = $firebaseUrl . "cookies/" . $accountCookie . "/tipos.json";
$tiposData = fetchFirebaseData($tiposUrl);
$nometipos = [];
if (is_array($tiposData)) {
    foreach ($tiposData as $key => $tipo) {
        if (isset($tipo["nometipo"])) {
            $nometipos[] = $tipo["nometipo"];
        }
    }
}

// Verifica se o evento/carrinho tem taxa personalizada (ex: 8% ao invés dos 10% padrão)
$taxaPersonalizada = isset($cartData["taxapersonalizada"]) ? (float) $cartData["taxapersonalizada"] : null;
$temTaxaPersonalizada = $taxaPersonalizada !== null && $taxaPersonalizada > 0;

// Calcula valor base e taxa (Original)
if ($semTaxa) {
    $valorBase = $valorTotalExibicao;
    $taxaServico = 0;
} elseif ($temValorAdicional) {
    $valorBase = 0;
    $taxaServico = $valorTotalAdicional;
} elseif ($temTaxaPersonalizada) {
    // Valor total já foi calculado com a taxa personalizada (base + taxa real)
    $divisorTaxa = 1 + ($taxaPersonalizada / 100);
    $valorBase = $valorTotal / $divisorTaxa;
    $taxaServico = $valorBase * ($taxaPersonalizada / 100);
} else {
    $valorBase = $valorTotal / 1.10;
    $taxaServico = $valorBase * 0.10;
}

// Format total for card payment (Original logic)
$totalcard = $valorTotalExibicao; // Assuming $totalcard should be the full value in the original logic
$totalFormatted = number_format($totalcard, 2, ',', '.'); // Format for display

// Sem taxa no Pix (cookie: semtaxapix === true) - so controla o selo no botao do Pix
$semTaxaPix = isset($cartData['semtaxapix']) && $cartData['semtaxapix'] === true;
$aplicaSemTaxaPix = $semTaxaPix && !$semTaxa && !$temValorAdicional;

// ==============================================
// TAXA PERSONALIZADA NO PIX (pode ser diferente/menor do que a taxa do cartão)
// ==============================================
$taxaPersonalizadaPix = isset($cartData['taxapersonalizadapix']) ? (float) $cartData['taxapersonalizadapix'] : null;
$temTaxaPersonalizadaPix = $taxaPersonalizadaPix !== null && $taxaPersonalizadaPix > 0;

if ($semTaxa || $aplicaSemTaxaPix) {
    $taxaServicoPix = 0;
    $valorTotalPixSemSeguro = $valorBase;
} elseif ($temValorAdicional) {
    $taxaServicoPix = $taxaServico;
    $valorTotalPixSemSeguro = $valorTotalExibicao;
} elseif (isset($cartData['valortaxapersonalizadapix'])) {
    $valorTotalPixSemSeguro = (float) $cartData['valortaxapersonalizadapix'];
    $taxaServicoPix = $valorTotalPixSemSeguro - $valorBase;
} elseif ($temTaxaPersonalizadaPix) {
    $taxaServicoPix = $valorBase * ($taxaPersonalizadaPix / 100);
    $valorTotalPixSemSeguro = $valorBase + $taxaServicoPix;
} else {
    // Sem configuração específica de taxa pro Pix: usa a mesma taxa do cartão
    $taxaServicoPix = $taxaServico;
    $valorTotalPixSemSeguro = $valorTotalExibicao;
}

// Pix tem taxa de serviço menor que a do cartão? (pra mostrar o selo "TAXA MENOR")
$temTaxaMenorPix = !$aplicaSemTaxaPix && ($taxaServicoPix < $taxaServico - 0.004);

// ==============================================
// PROTEÇÃO DE REEMBOLSO (cookie: comprasegura === true / valorcompraseguro = valor total com o seguro incluso)
// Não é oferecida se o carrinho já tiver a taxa adicional (taxaadicional === true) ativa
// ==============================================
$taxaAdicionalAtiva = isset($cartData['taxaadicional']) && ($cartData['taxaadicional'] === true || $cartData['taxaadicional'] === 'true');
$temOfertaSeguro = isset($cartData['valorcompraseguro']) && !$taxaAdicionalAtiva;
$compraSegura = isset($cartData['comprasegura']) && $cartData['comprasegura'] === true;
$valorCompraSeguro = $temOfertaSeguro ? (float) $cartData['valorcompraseguro'] : null;
$valorSeguro = round($valorTotalExibicao * 0.10, 2); // valor do seguro em si: 10% do valor total (sem o seguro)
$valorSeguroFormatted = number_format($valorSeguro, 2, ',', '.');

// A Proteção de Reembolso também tem um preço próprio pro Pix, calculado em cima do total do Pix (sem seguro)
$valorSeguroPix = round($valorTotalPixSemSeguro * 0.10, 2);
$valorCompraSeguroPix = isset($cartData['valorcompraseguropix']) ? (float) $cartData['valorcompraseguropix'] : null;
if ($valorCompraSeguroPix === null && $temOfertaSeguro) {
    $valorCompraSeguroPix = $valorTotalPixSemSeguro + $valorSeguroPix;
}

if ($compraSegura && $valorCompraSeguro !== null) {
    $valorTotalExibicao = $valorCompraSeguro;
    $valorTotalpix = number_format($valorTotalExibicao, 2, ",", ".");
    $valorEmCentavos = (int) round($valorTotalExibicao * 100);
    $totalcard = $valorTotalExibicao;
    $totalFormatted = number_format($totalcard, 2, ',', '.');
}

// Valor final do Pix, considerando o estado atual (marcado ou não) da Proteção de Reembolso
$valorTotalPixFinal = ($compraSegura && $valorCompraSeguroPix !== null) ? $valorCompraSeguroPix : $valorTotalPixSemSeguro;
// ==============================================
// FIM PROTEÇÃO DE REEMBOLSO
// ==============================================

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - PI TICKETS</title>
    <link rel="icon" href="../images/favicon.ico" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="32x32" href="../images/favicon-32x32.png">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Lato:wght@400;700&display=swap">
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Embedded Combined Styles -->
    <style>
        /* === Original Header, Footer & Menu Styles === */
        body, html {
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif; /* Default font */
            display: flex;
            min-height: 100vh;
            flex-direction: column;
        }

        header {
            width: 100%;
            background-color: black;
            color: white;
            padding: 10px 0;
            text-align: center;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky; /* Make header sticky */
            top: 0;
            z-index: 1030; /* Ensure header is above most content */
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .logo {
            max-width: 110px;
            margin-left: 1.5em;
        }

        .header-links {
            margin-right: 20px;
        }

        .header-links a {
            color: black;
            text-decoration: none;
            margin-left: 20px;
            font-size: 16px;
            background-color: white;
            padding: 10px 20px 10px 20px;
            border-radius: 5px;
            transition: background-color 0.2s, color 0.2s;
        }

        .header-links a:hover {
            text-decoration: underline; /* Original hover effect */
            background-color: white; /* Ensure background doesn't change on hover unless intended */
        }

        footer {
            text-align: center;
            padding: 10px;
            background-color: #f0f0f0;
            color: #333; /* Original color */
            margin-top: auto; /* Push footer to bottom */
            font-size: 1rem; /* Default size */
        }

        /* Mobile Menu Styles (Original) */
        .menu-button {
            display: none; /* Hidden by default, shown in media query */
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 10px;
            margin-right: 15px;
            transition: transform 0.3s ease-in-out;
        }
        .menu-button div {
            width: 30px; /* Original width */
            height: 3px;
            background: white;
            margin: 5px 0; /* Original margin */
            border-radius: 3px;
            transition: transform 0.3s ease-in-out, opacity 0.3s ease-in-out;
        }

        .menu {
            display: none;
            position: absolute;
            top: 60px; /* Original position */
            right: 10px;
            background: white;
            color: black;
            width: 200px; /* Original width */
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            z-index: 1000;
            padding: 10px;
        }
        .menu a {
            display: block;
            color: black;
            text-decoration: none;
            margin: 10px 0; /* Original margin */
            font-size: 16px;
        }
        .menu a:hover {
            text-decoration: underline;
        }

        /* === Timer de Expiração do Carrinho === */
        .cart-timer-banner {
            position: sticky;
            top: 0;
            z-index: 1020;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            width: 100%;
            padding: 0.5rem 1rem;
            background: #fff3cd;
            color: #664d03;
            font-size: 0.9rem;
            font-weight: 600;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.08);
            transition: background-color 0.3s ease, color 0.3s ease;
        }

        .cart-timer-icon {
            font-size: 0.95rem;
        }

        .cart-timer-banner strong {
            font-variant-numeric: tabular-nums;
            font-size: 1rem;
        }

        .cart-timer-banner.cart-timer-warning {
            background: #ffe1a8;
            color: #7a4d00;
        }

        .cart-timer-banner.cart-timer-danger {
            background: #f8d7da;
            color: #842029;
            animation: cartTimerPulse 1s ease-in-out infinite;
        }

        @keyframes cartTimerPulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.65; }
        }

        /* === Global Loader & Popup Styles (Not Scoped) === */
        .spinner-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255, 255, 255, 0.85);
            display: none; /* Hidden by default */
            justify-content: center;
            align-items: center;
            z-index: 1060; /* Highest z-index */
            backdrop-filter: blur(3px);
        }

        .spinner {
            border: 5px solid #e9ecef;
            border-top: 5px solid #0d6efd; /* Using primary color from scoped styles */
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 0.8s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .custom-popup-backdrop {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            display: none; /* Hidden by default */
            justify-content: center;
            align-items: center;
            z-index: 1050;
            padding: 15px;
        }

        .custom-popup-content {
            background: #fff;
            padding: 1.5rem 2rem;
            border-radius: 0.5rem;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            max-width: 450px;
            width: 100%;
            text-align: center;
            position: relative;
            animation: fadeInPopup 0.3s ease-out;
        }

        @keyframes fadeInPopup {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .custom-popup-content .close-btn {
            position: absolute;
            top: 10px;
            right: 15px;
            font-size: 1.8rem;
            color: #aaa;
            background: none;
            border: none;
            cursor: pointer;
            line-height: 1;
            padding: 5px;
        }

        .custom-popup-content .close-btn:hover {
            color: #333;
        }

        .custom-popup-content h3 {
            font-size: 1.25rem;
            margin-top: 0.5rem;
            margin-bottom: 1rem;
            color: #212529; /* Use default dark color */
        }

        .custom-popup-content p {
            font-size: 1rem;
            color: #555;
            margin-bottom: 1.5rem;
        }

        .loading-popup {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            display: none; /* Hidden by default */
            justify-content: center;
            align-items: center;
            z-index: 1055; /* Below spinner overlay */
            flex-direction: column;
            padding: 15px;
        }

        .loading-popup-content {
            background: #fff;
            padding: 2rem;
            border-radius: 0.5rem;
            text-align: center;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
            animation: fadeInPopup 0.3s ease-out;
        }

        .loading-popup-content h2 {
            font-size: 1.15rem;
            margin-bottom: 1rem;
            color: #212529; /* Use default dark color */
            max-width: 300px;
        }

        .loading-popup-content img {
            width: 70px;
            height: auto;
            margin-top: 0.5rem;
        }

        /* === Checkout Styles Scoped to #checkout-content === */
        #checkout-content {
            /* === Bootstrap Overrides & General Styles === */
            --bs-primary: #0d6efd;
            --bs-secondary: #6c757d;
            --bs-success: #198754;
            --bs-danger: #dc3545;
            --bs-warning: #ffc107;
            --bs-info: #0dcaf0;
            --bs-light: #f8f9fa;
            --bs-dark: #212529;
            --bs-body-font-family: 'Lato', sans-serif;
            --bs-body-bg: #f4f7f9;
            --bs-body-color: #343a40;
            --bs-border-color: #dee2e6;

            background-color: var(--bs-body-bg);
            color: var(--bs-body-color);
            font-family: var(--bs-body-font-family);
            flex: 1;
            padding-top: 2rem;
            padding-bottom: 3rem;
        }

        #checkout-content .card {
            border: none;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            border-radius: 0.5rem;
            margin-bottom: 1.5rem;
            background-color: #fff;
        }

        #checkout-content .card-header {
            background-color: #fff;
            border-bottom: 1px solid var(--bs-border-color);
            font-size: 1.25rem;
            font-weight: 700;
            padding: 1rem 1.25rem;
            color: var(--bs-dark);
            border-radius: 0.5rem 0.5rem 0 0 !important;
        }

        #checkout-content .card-body {
            padding: 1.5rem;
        }

        /* === Checkout Details Section === */
        #checkout-content .checkout-details h1 {
            display: none;
        }

        #checkout-content .checkout-details p {
            margin-bottom: 0.75rem;
            font-size: 0.95rem;
            color: #555;
        }

        #checkout-content .checkout-details strong {
            color: var(--bs-dark);
            font-weight: 700;
        }

        #checkout-content .checkout-details ul {
            list-style: none;
            padding-left: 0;
            margin-top: 0.5rem;
            margin-bottom: 1rem;
        }

        #checkout-content .checkout-details li {
            font-size: 0.95rem;
            margin-bottom: 0.4rem;
            display: flex;
            align-items: center;
        }

        #checkout-content .checkout-details li::before {
            content: "\f00c"; /* Font Awesome Check */
            font-family: "Font Awesome 6 Free";
            font-weight: 900;
            color: var(--bs-success);
            margin-right: 8px;
            font-size: 0.9em;
        }

        #checkout-content #valorAntigo {
            color: var(--bs-danger) !important;
            font-weight: normal;
            font-size: 0.9em;
            text-decoration: line-through;
            opacity: 0.8;
        }

        #checkout-content .total-section {
            border-top: 1px solid var(--bs-border-color);
            padding-top: 1rem;
            margin-top: 1rem;
        }

        #checkout-content #valorTotal {
            font-size: 1.4em;
            font-weight: 700;
            color: var(--bs-success);
            margin-bottom: 0;
        }

        #checkout-content .pix-sem-taxa-badge {
            position: absolute;
            top: -8px;
            right: -6px;
            background: var(--bs-success);
            color: #fff;
            font-size: 0.6rem;
            font-weight: 700;
            padding: 2px 6px;
            border-radius: 999px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.15);
            letter-spacing: 0.02em;
            white-space: nowrap;
        }

        /* === Proteção de Reembolso === */
        #checkout-content .refund-protection {
            margin-top: 0.75rem;
            padding: 0.6rem 0.75rem;
            border-radius: 0.4rem;
            background: #f8f9fa;
            border: 1px solid var(--bs-border-color);
        }

        #checkout-content .refund-protection .form-check {
            display: flex;
            align-items: center;
            gap: 0.4rem;
            margin-bottom: 0.25rem;
        }

        #checkout-content .refund-protection .form-check-input {
            width: 0.95em;
            height: 0.95em;
            margin-top: 0;
            flex-shrink: 0;
            cursor: pointer;
        }

        #checkout-content .refund-protection .form-check-label {
            font-weight: 600;
            font-size: 0.85rem;
            color: var(--bs-dark);
            cursor: pointer;
        }

        #checkout-content .refund-protection-text {
            font-size: 0.72rem;
            color: #6c757d;
            line-height: 1.35;
            margin-bottom: 0;
        }

        /* === Coupon Section === */
        #checkout-content .coupon {
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px dashed #ced4da;
        }

        #checkout-content .coupon label {
            font-weight: 700;
            margin-bottom: 0.5rem;
            font-size: 1rem;
            color: var(--bs-dark);
        }

        #checkout-content .coupon .input-group {
            margin-bottom: 0.75rem;
        }

        #checkout-content .coupon .form-control {
            border-radius: 0.375rem 0 0 0.375rem !important;
        }

        #checkout-content .coupon .btn {
            border-radius: 0 0.375rem 0.375rem 0 !important;
        }

        #checkout-content .coupon p {
            font-size: 0.85em !important;
            color: var(--bs-secondary);
            margin-top: 0.5rem;
            margin-bottom: 0;
        }

        #checkout-content .coupon input[readonly] {
            background-color: #e9ecef !important;
            cursor: not-allowed !important;
        }

        /* === Payment Methods Section === */
        #checkout-content .payment-methods h2 {
            display: none;
        }

        #checkout-content .payment-buttons {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }

        #checkout-content .payment-buttons .btn {
            border: 2px solid var(--bs-border-color);
            padding: 0.75rem;
            transition: all 0.2s ease-in-out;
            background-color: #fff;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-width: 110px;
            border-radius: 0.5rem;
            text-align: center;
            text-decoration: none;
            color: var(--bs-dark);
            cursor: pointer; /* Ensure buttons are clickable */
        }

        #checkout-content .payment-buttons .btn img {
            width: 45px;
            height: 45px;
            object-fit: contain;
            margin-bottom: 0.5rem;
        }

        #checkout-content .payment-buttons .btn span {
            font-size: 0.9rem;
            font-weight: 600;
            color: var(--bs-dark);
        }

        #checkout-content .payment-buttons .btn:hover {
            border-color: #adb5bd;
            background-color: #f8f9fa;
            transform: translateY(-2px);
        }

        #checkout-content .payment-buttons .btn.selected {
            border-color: var(--bs-primary);
            background-color: #e7f1ff;
            box-shadow: 0 0 0 0.2rem rgba(13, 110, 253, 0.25);
            transform: translateY(-2px);
        }

        #checkout-content #paymentDetails {
            margin-top: 1rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--bs-border-color);
        }

        #checkout-content #paymentDetails h3 {
            font-size: 1.15rem;
            font-weight: 700;
            margin-bottom: 1.25rem;
            text-align: center;
            color: var(--bs-dark);
        }

        /* === PIX Payment Specific Styles === */
        #checkout-content .payment-result {
            text-align: center;
            padding: 1.5rem;
            border: 1px solid var(--bs-border-color);
            border-radius: 0.5rem;
            background-color: var(--bs-light);
            margin-top: 1rem;
        }

        #checkout-content .payment-result h3 {
            font-size: 1.2em;
            color: var(--bs-dark);
            margin-bottom: 1rem;
        }

        #checkout-content #qrCodeContainer {
            margin: 1.5rem 0;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        #checkout-content #qrCodeContainer img {
            max-width: 180px;
            height: auto;
            border: 1px solid #dee2e6;
            border-radius: 5px;
            padding: 8px;
            background-color: #fff;
            margin-bottom: 1rem;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        #checkout-content #qrCode {
            font-family: monospace;
            word-break: break-all;
            background-color: #e9ecef;
            padding: 0.75rem 1rem;
            border-radius: 5px;
            border: 1px solid #ced4da;
            font-size: 0.9em;
            max-width: 100%;
            box-sizing: border-box;
            text-align: left;
            margin-bottom: 1rem;
            white-space: normal;
            line-height: 1.4;
            color: #495057;
        }

        #checkout-content .payment-result p {
            font-size: 0.9rem;
            color: #555;
            margin-bottom: 0.5rem;
        }

        #checkout-content .payment-result p strong {
            color: var(--bs-dark);
        }

        /* === Card Payment Specific Styles (Mercado Pago Brick) === */
        #checkout-content #cardPaymentBrick_container {
            padding: 0.5rem 0;
        }

        /* === Media Queries === */
        /* Original Mobile Menu Breakpoint */
        @media (max-width: 768px) {
            .header-links {
                display: none;
            }
            .menu-button {
                display: flex;
            }
            .menu-button.open div:nth-child(1) {
                transform: rotate(-45deg) translate(-5px, 6px);
            }
            .menu-button.open div:nth-child(2) {
                opacity: 0;
            }
            .menu-button.open div:nth-child(3) {
                transform: rotate(45deg) translate(-5px, -6px);
            }
            .menu {
                /* display: none; /* Handled by JS */
                position: fixed;
                top: 60px;
                left: 0;
                width: 100vw;
                height: calc(100vh - 60px);
                background-color: rgba(255, 255, 255, 0.95);
                box-shadow: 0 2px 4px rgba(0,0,0,0.3);
                overflow-y: auto;
                z-index: 1001;
                padding-top: 20px;
                opacity: 0;
                transition: opacity 0.3s ease-in-out;
            }
            .menu.show {
                display: block;
                opacity: 1;
            }
            .menu a {
                margin: 15px 20px;
                font-size: 18px;
                text-align: center;
            }

            /* Scoped Checkout Styles for Mobile */
            #checkout-content {
                padding-top: 1.5rem;
                padding-bottom: 2rem;
            }
            #checkout-content .card-body {
                padding: 1.25rem;
            }
            #checkout-content .payment-buttons {
                gap: 0.75rem;
            }
            #checkout-content .payment-buttons .btn {
                min-width: 90px;
                padding: 0.6rem;
            }
            #checkout-content .payment-buttons .btn img {
                width: 40px;
                height: 40px;
                margin-bottom: 0.4rem;
            }
            #checkout-content .payment-buttons .btn span {
                font-size: 0.8rem;
            }
        }

        /* Original Small Mobile Breakpoint */
        @media (max-width: 480px) {
            .logo {
                max-width: 80px;
            }
            footer {
                font-size: 14px;
            }

            /* Scoped Checkout Styles for Small Mobile */
             #checkout-content .payment-buttons {
                justify-content: space-around;
             }
             #checkout-content .payment-buttons .btn {
                 min-width: 80px;
             }
        }

        /* Bootstrap Grid Breakpoint */
        @media (max-width: 991.98px) {
            #checkout-content .row > div {
                order: initial !important; /* Reset order on smaller screens */
            }
        }
    </style>

    <!-- Mercado Pago Security Script (Original) -->
    <script src="https://www.mercadopago.com/v2/security.js" view="home"></script>

</head>
<body>

<!-- ===== LOADER OVERLAY (Global) ===== -->
<div class="spinner-overlay" id="spinnerOverlay">
    <div class="spinner"></div>
</div>
<!-- =================================== -->

<!-- Header (Original Structure) -->
<header>
    <a href="/index.php"><img src="../images/logo.png" alt="Logo da Empresa" class="logo"></a>
    <div class="header-links"> <!-- Original class -->
        <a href="/cadastro">Cadastro</a>
        <a href="../login">Área do Usuário</a>
        <a href="/area-do-organizador">Área do Organizador</a>
    </div>
    <button class="menu-button"> <!-- Original class -->
        <div></div>
        <div></div>
        <div></div>
    </button>
    <div class="menu"> <!-- Original class -->
        <a href="/cadastro">Cadastro</a>
        <a href="/login">Área do Usuário</a>
        <a href="/area-do-organizador">Área do Organizador</a>
    </div>
</header>

<!-- ===== TIMER DE EXPIRAÇÃO DO CARRINHO ===== -->
<div class="cart-timer-banner" id="cartTimerBanner">
    <i class="fas fa-clock cart-timer-icon"></i>
    <span>Finalize sua compra em <strong id="cartTimerDisplay">10:00</strong></span>
</div>
<!-- =========================================== -->

<!-- Main Content Wrapper with ID for Scoped Styles -->
<div id="checkout-content" class="container-lg">
    <div class="row g-4">
        <!-- Checkout Details Column -->
        <div class="col-lg-5 order-lg-last">
            <div class="card checkout-details">
                <div class="card-header">
                    Resumo da Compra
                </div>
                <div class="card-body">
                    <p><strong>Evento:</strong> <?php echo htmlspecialchars($eventName); ?></p>
                    <p><strong>Titular:</strong> <?php echo htmlspecialchars($fullName); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($emailAccount); ?></p>
                    <p><strong>Quantidade:</strong> <?php echo htmlspecialchars($unt); ?></p>
                    <p><strong>Código do Carrinho: </strong><?php echo htmlspecialchars($accountCookie); ?></p>

                    <?php if (!empty($nometipos)): ?>
                        <h5 class="mt-3 mb-2">Seus Ingressos:</h5>
                        <ul>
                            <?php foreach ($nometipos as $nometipo): ?>
                                <li><?php echo htmlspecialchars($nometipo); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p class="text-muted">Nenhum tipo de ingresso encontrado.</p>
                    <?php endif; ?>

                    <hr class="my-3">

                    <?php if ($cupomUtilizado && $valorOriginal): ?>
                        <p id="valorAntigo" class="text-end">
                            Valor Original: R$ <?php echo number_format($valorOriginal, 2, ',', '.'); ?>
                        </p>
                    <?php endif; ?>

                    <p class="d-flex justify-content-between"><span>Valor Ingressos:</span> <span><?php echo $temValorAdicional ? 'Gratuito' : ('R$ ' . number_format($valorBase, 2, ',', '.')); ?></span></p>

                    <div id="linhaTaxaServicoCartao">
                    <?php if ($semTaxa): ?>
                        <p class="d-flex justify-content-between"><span>Taxa de Serviço:</span> <span>Sem taxas</span></p>
                    <?php elseif ($temValorAdicional): ?>
                        <p class="d-flex justify-content-between"><span>Taxa de Serviço:</span> <span>R$ <?php echo number_format($taxaServico, 2, ",", "."); ?></span></p>
                    <?php elseif ($temTaxaPersonalizada): ?>
                        <p class="d-flex justify-content-between"><span>Taxa de Serviço (<?php echo number_format($taxaPersonalizada, $taxaPersonalizada == floor($taxaPersonalizada) ? 0 : 2, ',', '.'); ?>%):</span> <span>R$ <?php echo number_format($taxaServico, 2, ",", "."); ?></span></p>
                    <?php else: ?>
                        <p class="d-flex justify-content-between"><span>Taxa de Serviço (10%):</span> <span>R$ <?php echo number_format($taxaServico, 2, ",", "."); ?></span></p>
                    <?php endif; ?>
                    </div>

                    <?php
                        if ($taxaPersonalizadaPix !== null) {
                            $taxaPercentualPixExibicao = $taxaPersonalizadaPix;
                        } elseif ($valorBase > 0) {
                            $taxaPercentualPixExibicao = round(($taxaServicoPix / $valorBase) * 100, 2);
                        } else {
                            $taxaPercentualPixExibicao = 10;
                        }
                    ?>
                    <div id="linhaTaxaServicoPix" style="display:none;">
                    <?php if ($semTaxa || $aplicaSemTaxaPix): ?>
                        <p class="d-flex justify-content-between"><span>Taxa de Serviço:</span> <span>Sem taxas</span></p>
                    <?php elseif ($temValorAdicional): ?>
                        <p class="d-flex justify-content-between"><span>Taxa de Serviço:</span> <span>R$ <?php echo number_format($taxaServicoPix, 2, ",", "."); ?></span></p>
                    <?php else: ?>
                        <p class="d-flex justify-content-between"><span>Taxa de Serviço (<?php echo number_format($taxaPercentualPixExibicao, $taxaPercentualPixExibicao == floor($taxaPercentualPixExibicao) ? 0 : 2, ',', '.'); ?>%):</span> <span>R$ <?php echo number_format($taxaServicoPix, 2, ",", "."); ?></span></p>
                    <?php endif; ?>
                    </div>

                    <?php if ($compraSegura && $valorCompraSeguro !== null): ?>
                        <div id="linhaProtecaoCartao">
                            <p class="d-flex justify-content-between"><span>Proteção de Reembolso:</span> <span>R$ <?php echo $valorSeguroFormatted; ?></span></p>
                        </div>
                        <div id="linhaProtecaoPix" style="display:none;">
                            <p class="d-flex justify-content-between"><span>Proteção de Reembolso:</span> <span>R$ <?php echo number_format($valorSeguroPix, 2, ',', '.'); ?></span></p>
                        </div>
                    <?php endif; ?>

                    <div class="total-section d-flex justify-content-between align-items-center">
                        <span class="fw-bold fs-5">Valor Total:</span>
                        <span id="valorTotal">R$ <?php echo number_format($valorTotalExibicao, 2, ',', '.'); ?></span>
                    </div>

                    <!-- Coupon Section (Original Structure with Bootstrap classes) -->
                    <div class="coupon">
                        <?php if ($cupomUtilizado): ?>
                            <label for="coupon" class="form-label">Cupom Aplicado:</label>
                            <input type="text" id="coupon" name="coupon" class="form-control" value="<?php echo htmlspecialchars($cupomKey); ?>" readonly>
                        <?php else: ?>
                            <label for="coupon" class="form-label">Cupom de desconto:</label>
                            <div class="input-group mb-2">
                                <input type="text" id="coupon" name="coupon" class="form-control" placeholder="Insira seu cupom">
                                <!-- Using original onclick but Bootstrap button -->
                                <button class="btn btn-primary" onclick="aplicarCupom()">Aplicar</button>
                            </div>
                            <p></p>
                        <?php endif; ?>
                    </div>

                    <?php if ($temOfertaSeguro): ?>
                    <div class="refund-protection">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="comprasegura" <?php echo $compraSegura ? 'checked' : ''; ?> onchange="toggleProtecaoReembolso(this)">
                            <label class="form-check-label" for="comprasegura">
                                Proteção de reembolso
                            </label>
                        </div>
                        <p class="refund-protection-text">
                            Declaro que desejo contratar a Proteção de Reembolso no valor de <strong>R$ <span id="valorSeguroTexto"><?php echo $valorSeguroFormatted; ?></span></strong>, garantindo o reembolso de até 100% do ingresso em casos como acidente, doença e outros previstos nos Termos de uso. Confirmo que li e concordo com os <a href="https://piauitickets.com/termos/" target="_blank" rel="noopener">Termos de uso da Proteção de Reembolso</a> da PI TICKETS.
                        </p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Payment Methods Column -->
        <div class="col-lg-7 order-lg-first">
            <div class="card payment-methods" id="paymentMethodsContainer">
                 <div class="card-header">
                    Forma de Pagamento
                </div>
                <div class="card-body">
                    <!-- Using original onclick but Bootstrap buttons -->
                    <div class="payment-buttons">
                        <button id="cartaoButton" class="btn" onclick="showPaymentMethod('cartao')">
                            <img src="/images/bank-card.png" alt="Cartão">
                            <span>Cartão</span>
                        </button>
                        <button id="pixButton" class="btn position-relative" onclick="showPaymentMethod('pix')">
                            <?php if ($aplicaSemTaxaPix): ?>
                                <span class="pix-sem-taxa-badge">SEM TAXA</span>
                            <?php elseif ($temTaxaMenorPix): ?>
                                <span class="pix-sem-taxa-badge">TAXA MENOR</span>
                            <?php endif; ?>
                            <img src="/images/pixicon2.png" alt="Pix">
                            <span>Pix</span>
                        </button>
                    </div>
                    <div id="paymentDetails">
                         <p class="text-center text-muted">Selecione uma forma de pagamento acima.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> <!-- End #checkout-content -->

<!-- Footer (Original Structure) -->
<footer>
    <p>&copy; <?php echo date('Y'); ?> @PITICKETS</p>
    <!-- Add original footer links/content if any -->
</footer>

<!-- Popups (Global HTML Structure) -->
<div id="payment-status-popup" class="custom-popup-backdrop">
    <div class="custom-popup-content">
        <button class="close-btn" onclick="this.closest('.custom-popup-backdrop').style.display='none'">&times;</button>
        <h3 id="popup-title">Aviso</h3>
        <p id="popup-message">Mensagem do sistema.</p>
    </div>
</div>

<div id="popUpGratuito" class="custom-popup-backdrop">
    <div class="custom-popup-content">
        <h3><i class="fas fa-gift text-success me-2"></i>Cupom Gratuito Aplicado!</h3>
        <p>Você conseguiu um ingresso gratuito! Clique no botão abaixo para resgatar.</p>
        <!-- Using original onclick but Bootstrap button -->
        <button onclick="resgatarIngresso()" class="btn btn-success btn-lg">RESGATAR INGRESSO</button>
    </div>
</div>

<div id="cartExpiredPopup" class="custom-popup-backdrop">
    <div class="custom-popup-content">
        <h3><i class="fas fa-hourglass-end text-danger me-2"></i>Carrinho Expirado</h3>
        <p>O tempo para finalizar essa compra (10 minutos) foi excedido e os itens reservados foram liberados.</p>
        <button onclick="location.reload()" class="btn btn-danger btn-lg">ATUALIZAR PÁGINA</button>
    </div>
</div>

<!-- Original Loading Popups (GIFs) -->
<div id="loadingPopup" class="loading-popup"> <div class="loading-popup-content"> <h2><i class="fas fa-check-circle text-success me-2"></i>Pedido Realizado!</h2> <p>Aguarde, estamos te redirecionando...</p> <img src="../images/animacaoapv.gif" alt="Carregando"> </div></div>
<div id="loadingPopup2" class="loading-popup"> <div class="loading-popup-content"> <h2><i class="fas fa-times-circle text-danger me-2"></i>Pagamento Recusado</h2> <p>Verifique os dados ou limite do cartão.</p> <img src="../images/animacaorec2.gif" alt="Carregando"> </div></div>
<div id="loadingPopup3" class="loading-popup"> <div class="loading-popup-content"> <h2><i class="fas fa-exclamation-circle text-warning me-2"></i>Pagamento Recusado</h2> <p>Código de segurança (CVV) inválido.</p> <img src="../images/animacaorec2.gif" alt="Carregando"> </div></div>
<div id="loadingPopup4" class="loading-popup"> <div class="loading-popup-content"> <h2><i class="fas fa-hourglass-half text-info me-2"></i>Pagamento em Análise</h2> <p>Aguarde a confirmação do gateway.</p> <img src="../images/animacaorec2.gif" alt="Carregando"> </div></div>


<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<!-- jQuery (Required by original menu script) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<!-- Mercado Pago SDK -->
<script src="https://sdk.mercadopago.com/js/v2"></script>

<!-- ORIGINAL JavaScript Logic -->
<script>
    // --- Loader Functions (Using new spinner overlay ID) ---
    const spinnerOverlay = document.getElementById('spinnerOverlay');
    function showLoader() {
        if (spinnerOverlay) spinnerOverlay.style.display = 'flex';
    }
    function hideLoader() {
        if (spinnerOverlay) spinnerOverlay.style.display = 'none';
    }

    // --- Timer de Expiração do Carrinho (10 minutos) ---
    let cartTempoRestante = <?php echo (int) $tempoRestanteSegundos; ?>;
    let cartTimerIntervalId = null;

    function formatCartTimer(segundos) {
        const s = Math.max(0, segundos);
        const m = Math.floor(s / 60);
        const sec = s % 60;
        return String(m).padStart(2, '0') + ':' + String(sec).padStart(2, '0');
    }

    function showCartExpiredPopup() {
        // Desabilita interações de pagamento e cupom pra evitar ações depois de expirado
        document.querySelectorAll('#checkout-content button, #checkout-content input').forEach(el => el.disabled = true);
        const popup = document.getElementById('cartExpiredPopup');
        if (popup) popup.style.display = 'flex';
    }

    function tickCartTimer() {
        const display = document.getElementById('cartTimerDisplay');
        const banner = document.getElementById('cartTimerBanner');
        if (display) display.textContent = formatCartTimer(cartTempoRestante);

        if (banner) {
            banner.classList.toggle('cart-timer-warning', cartTempoRestante <= 180 && cartTempoRestante > 60);
            banner.classList.toggle('cart-timer-danger', cartTempoRestante <= 60);
        }

        if (cartTempoRestante <= 0) {
            clearInterval(cartTimerIntervalId);
            showCartExpiredPopup();
            return;
        }

        cartTempoRestante--;
    }

    tickCartTimer();
    cartTimerIntervalId = setInterval(tickCartTimer, 1000);

    // --- Helper Function for Popups (Using new popup structure) ---
    function showPopupMessage(message, title = "Aviso") {
        const popup = document.getElementById('payment-status-popup');
        const titleElement = document.getElementById('popup-title');
        const msgElement = document.getElementById('popup-message');
        if (popup && msgElement && titleElement) {
            titleElement.textContent = title;
            msgElement.textContent = message;
            popup.style.display = 'flex';
        }
    }

    // --- Toggle da Proteção de Reembolso (marca/desmarca comprasegura no cookie) ---
    function toggleProtecaoReembolso(checkbox){
        const novoValor = checkbox.checked;
        const valorAnterior = !novoValor;
        showLoader();

        let formData = new FormData();
        formData.append("accountCookie", "<?php echo htmlspecialchars($accountCookie); ?>");
        formData.append("comprasegura", novoValor ? "true" : "false");

        fetch("protecaoreembolso.php", {
            method: "POST",
            body: formData
        }).then(response => {
            if (!response.ok) throw new Error("Falha ao atualizar a proteção de reembolso.");
            return response.json();
        }).then(data => {
            if (data.error) throw new Error(data.error);
            location.reload();
        }).catch(error => {
            console.error("Erro ao atualizar proteção de reembolso:", error);
            showPopupMessage("Erro ao atualizar a Proteção de Reembolso. Tente novamente.");
            checkbox.checked = valorAnterior;
            hideLoader();
        });
    }

   // --- Original aplicarCupom function (Modified to use show/hideLoader and showPopupMessage) ---
    function aplicarCupom(){
        let e=document.getElementById("coupon").value.trim();
        if (!e) {
            showPopupMessage("Por favor, insira um código de cupom.");
            return;
        }
        const currentEventId = <?php echo json_encode($eventId); ?>;
        const cartTicketTypes = <?php echo json_encode($nometipos); ?>;
        if (currentEventId == '29414' && Array.isArray(cartTicketTypes)) {

    if (e.toUpperCase() === '15ALMOCOVIP' && cartTicketTypes.includes('Meia')) {
        showPopupMessage("O uso do cupom 15ALMOCOVIP está bloqueado para o tipo Meia", "Aviso");
        return;
    }

if (
    (e.toUpperCase() === 'VIPIFIL' ||
     e.toUpperCase() === 'VIPICLUB' ||
     e.toUpperCase() === 'VIPIGUEST' ||
     e.toUpperCase() === 'VIPIPAT') &&
    !cartTicketTypes.every(t => t === 'Meia para todos')
) {
    showPopupMessage(
        'Os cupom inserido é válido apenas para o ingresso: "Meia para todos".',
        'Aviso'
    );
    return;
}


}

        showLoader(); // Use new loader function
        const accountCookie = "<?php echo htmlspecialchars($accountCookie); ?>";
        // Validação e aplicação do cupom acontecem juntas, no servidor, em uma única requisição
        fetch(`cupons.php?cupom=${encodeURIComponent(e)}&event_id=<?php echo $eventId; ?>&account_cookie=${encodeURIComponent(accountCookie)}`)
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    showPopupMessage(data.error);
                    hideLoader();
                    return;
                }
                if (data.isFree) {
                    const freePopup = document.getElementById('popUpGratuito');
                    if (freePopup) freePopup.style.display = 'flex';
                    hideLoader();
                } else {
                    location.reload();
                }
            })
            .catch(err => {
                console.error("Erro ao aplicar o cupom:", err);
                showPopupMessage("Erro ao aplicar o cupom!");
                hideLoader();
            });
    }

    // --- Original Free Ticket Redemption (Modified for new popup) ---
    function resgatarIngresso() {
        showLoader();
        console.log("Resgatando ingresso gratuito...");
        setTimeout(() => {
            showPopupMessage("Ingresso gratuito resgatado com sucesso! Você será redirecionado em breve.", "Sucesso!");
        }, 2000);
    }

    // --- Original showPaymentMethod function (Modified for Bootstrap buttons and loader) ---
    function selectPaymentMethod(selectedButton) {
        document.querySelectorAll('#checkout-content .payment-buttons .btn').forEach(btn => btn.classList.remove('selected'));
        if (selectedButton) {
            selectedButton.classList.add('selected');
        }
    }

    // --- Resumo da compra: valores mudam conforme o método de pagamento selecionado (taxa/seguro podem ser menores no Pix) ---
    function formatBRL(valor) {
        return valor.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }

    const resumoValoresCartao = {
        valorTotal: <?php echo json_encode($valorTotalExibicao); ?>
    };
    const resumoValoresPix = {
        valorTotal: <?php echo json_encode($valorTotalPixFinal); ?>,
        valorSeguro: <?php echo json_encode($valorSeguroPix); ?>
    };

    function atualizarResumoPorMetodo(metodo) {
        const linhaTaxaCartao = document.getElementById('linhaTaxaServicoCartao');
        const linhaTaxaPix = document.getElementById('linhaTaxaServicoPix');
        const linhaProtecaoCartao = document.getElementById('linhaProtecaoCartao');
        const linhaProtecaoPix = document.getElementById('linhaProtecaoPix');
        const valorTotalEl = document.getElementById('valorTotal');
        const valorSeguroTextoEl = document.getElementById('valorSeguroTexto');

        const ehPix = metodo === 'pix';

        if (linhaTaxaCartao) linhaTaxaCartao.style.display = ehPix ? 'none' : '';
        if (linhaTaxaPix) linhaTaxaPix.style.display = ehPix ? '' : 'none';
        if (linhaProtecaoCartao) linhaProtecaoCartao.style.display = ehPix ? 'none' : '';
        if (linhaProtecaoPix) linhaProtecaoPix.style.display = ehPix ? '' : 'none';

        if (valorTotalEl) {
            valorTotalEl.textContent = 'R$ ' + formatBRL(ehPix ? resumoValoresPix.valorTotal : resumoValoresCartao.valorTotal);
        }
        if (valorSeguroTextoEl && ehPix) {
            valorSeguroTextoEl.textContent = formatBRL(resumoValoresPix.valorSeguro);
        } else if (valorSeguroTextoEl && !ehPix) {
            valorSeguroTextoEl.textContent = '<?php echo $valorSeguroFormatted; ?>';
        }
    }

    function showPaymentMethod(e) {
        selectPaymentMethod(document.getElementById(e === 'cartao' ? 'cartaoButton' : 'pixButton')); // Visually select button
        atualizarResumoPorMetodo(e);
        let paymentDetails = document.getElementById("paymentDetails");
        let amount = parseFloat("<?php echo htmlspecialchars($totalFormatted); ?>".replace(".", "").replace(",", "."));
        let fullNameParts = "<?php echo htmlspecialchars($fullName); ?>".split(" ");
        let firstName = fullNameParts[0];
        let lastName = fullNameParts.slice(1).join(" ");
        const usercpfdata = '<?php echo $userCpf; ?>';
        const eventoid = '<?php echo htmlspecialchars($eventId); ?>';

        paymentDetails.innerHTML = ''; // Clear previous details

        if (e === "cartao") {
            paymentDetails.innerHTML = `<div id="cardPaymentBrick_container"></div>`;

            // --- START: Original Bricks Logic from pasted_content.txt ---
            const script = document.createElement('script');
            script.src = 'https://sdk.mercadopago.com/js/v2';
            script.onload = () => {
                const mp = new MercadoPago('TEST-chave-publica-removida', { locale: 'pt-BR' });
                const bricksBuilder = mp.bricks();

                const renderCardPaymentBrick = async () => {
                    const settings = {
                        initialization: {
                            amount: amount,
                            payer: { email: "<?php echo htmlspecialchars($emailAccount); ?>", first_name: firstName, last_name: lastName },
                        },
                        customization: {
                            visual: { style: { customVariables: { theme: 'default' } } }, // Original theme
                        },
                        paymentMethods: {
                            types: { excluded: ['debit_card'] },
                            maxInstallments: 4,
                        },
                        callbacks: {
                            onReady: () => {
                                console.log('O Brick foi carregado com sucesso!');
                                // hideLoader(); // Loader should be hidden by onReady in the original logic if needed, but it wasn\'t there. Keeping it out for fidelity.
                            },
                            onError: (error) => {
                                console.error('Erro ao carregar o Brick:', error);
                                showPopupMessage('Erro ao carregar o formulário de pagamento. Tente novamente.'); // Use existing popup for error
                                hideLoader(); // Hide loader on error
                            },
                            onSubmit: (cardFormData) => {
                                showLoader(); // Show loader on submit
                                const deviceInfo = generateDeviceInfo();
                                console.log("Device Info gerado:", deviceInfo);
                                console.log("Card form data:", cardFormData);

                                // Enviar apenas dados necessários - API buscará valor do Firebase
                                return fetch("/api/pagamentocardmp/pagamentocardmp.php", {
                                    method: "POST",
                                    headers: { "Content-Type": "application/json" },
                                    body: JSON.stringify({
                                        token: cardFormData.token,
                                        installments: cardFormData.installments,
                                        payment_method_id: cardFormData.payment_method_id,
                                        issuer_id: cardFormData.issuer_id,
                                        payer: { 
                                            address: {
                                                street_name: '',
                                                street_number: '',
                                                zip_code: ''
                                            }
                                        },
                                        device_info: deviceInfo,
                                        external_reference: "<?php echo htmlspecialchars($accountCookie); ?>"
                                    }),
                                })
                                .then(response => response.json())
                                .then(data => {
                                    console.log('Resposta da API de Pagamento Cartão:', data);
                                    if (data.error || !data.payment_response || !data.payment_response.id) {
                                        throw new Error(data.message || data.error || 'Erro desconhecido no processamento do pagamento.');
                                    }

                                    const paymentId = data.payment_response.id;
                                    const paymentStatus = data.payment_response.status;
                                    const statusDetail = data.payment_response.status_detail;

                                    // Verificar se Firebase foi atualizado
                                    if (data.firebase_updated === false) {
                                        console.warn("⚠️ Atenção: Firebase não foi atualizado completamente.", data.firebase_errors);
                                    }

                                    // Show appropriate original loading popup based on status
                                    let popupIdToShow = null;
                                    if (paymentStatus === 'approved') popupIdToShow = 'loadingPopup';
                                    else if (paymentStatus === 'in_process' || paymentStatus === 'pending') popupIdToShow = 'loadingPopup4';
                                    else if (paymentStatus === 'rejected') {
                                        if (statusDetail === 'cc_rejected_bad_filled_security_code') popupIdToShow = 'loadingPopup3';
                                        else popupIdToShow = 'loadingPopup2'; // Other rejections
                                    } else popupIdToShow = 'loadingPopup2'; // Default rejection/error

                                    const popupElement = document.getElementById(popupIdToShow);
                                    if (popupElement) popupElement.style.display = 'flex'; // Use flex to show

                                    // Redirect after a delay
                                    setTimeout(() => {
                                        window.location.href = `/paymentcard?idcarrinho=<?php echo htmlspecialchars($accountCookie); ?>`;
                                    }, 5000);
                                })
                                .catch(error => {
                                    console.error("Erro no processamento do pagamento com cartão:", error);
                                    showPopupMessage(`Erro no pagamento: ${error.message}. Tente novamente.`);
                                    hideLoader();
                                });
                            },
                        },
                    };
                    // Ensure container exists before creating Brick
                    if (document.getElementById('cardPaymentBrick_container')) {
                        await bricksBuilder.create('cardPayment', 'cardPaymentBrick_container', settings);
                    } else {
                         console.error('Container do Brick de Cartão não encontrado.');
                         hideLoader();
                    }
                };
                renderCardPaymentBrick();
            };
            document.body.appendChild(script); // Append the script to load it
            // --- END: Original Bricks Logic from pasted_content.txt ---
        }
        else if (e === "pix") {
            paymentDetails.innerHTML = `
                <h3 class="mb-3">Pagamento com Pix</h3>
                <p class="text-center mb-3">Clique no botão abaixo para gerar o código PIX e o QR Code.</p>
                <div class="d-grid">
                    <button onclick="processPixPayment()" class="btn btn-success btn-lg">Gerar PIX</button>
                </div>
            `;
        }
    }

    // --- Original generateDeviceInfo function ---
    function generateDeviceInfo(){
        let e=localStorage.getItem("device_info");
        return e||(e=JSON.stringify({device_id:"device_"+Math.random().toString(36).substr(2,9)+Date.now(),ip:"",user_agent:navigator.userAgent}),localStorage.setItem("device_info",e)),JSON.parse(e)
    }

    // --- Função de pagamento PIX com segurança integrada ---
    function processPixPayment(){
        showLoader();
        let accountCookie = "<?php echo htmlspecialchars($accountCookie); ?>";
        let paymentDetailsDiv = document.getElementById("paymentDetails");
        
        if(!paymentDetailsDiv){
            console.error("Erro: O elemento com ID \"paymentDetails\" não foi encontrado no DOM."); 
            hideLoader(); 
            return;
        }

        paymentDetailsDiv.innerHTML = `
            <div class="text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Gerando PIX...</span>
                </div>
                <p class="mt-2">Gerando código PIX, aguarde...</p>
            </div>
        `;

        // Enviar apenas accountCookie - API buscará dados do Firebase
        const paymentData = {
            accountCookie: accountCookie
        };

        fetch("/api/apimercadopago.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(paymentData)
        })
        .then(response => response.json())
        .then(responseData => {
            if(responseData.error){
                paymentDetailsDiv.innerHTML = `<div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Falha ao gerar PIX: ${responseData.error}. Recarregue a página e tente novamente.
                </div>`;
                
                // Registrar erro no cookie
                fetch("/api/update_cookie_error.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ accountCookie: accountCookie, qrcodeerror: true })
                });
                hideLoader();
            } else {
                // Verificar se Firebase foi atualizado com sucesso
                if (responseData.firebase_updated === false) {
                    console.warn("⚠️ Atenção: Firebase não foi atualizado completamente.", responseData.firebase_errors);
                    // Continuar mesmo assim, pois o PIX foi gerado
                }
                
                // Gerar QR Code usando API pública
                let qrCodeImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(responseData.qr_code)}`;
                paymentDetailsDiv.innerHTML = formatPixData(responseData, qrCodeImageUrl);
                
                console.log("✅ PIX gerado com sucesso! ID:", responseData.ticket_id);
                hideLoader();
            }
        })
        .catch(error => {
            console.error("Erro durante a requisição PIX:", error);
            paymentDetailsDiv.innerHTML = `<div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i>
                Falha ao gerar PIX. Verifique sua conexão e tente novamente.
            </div>`;
            hideLoader();
        });
    }

    // --- Função para formatar dados do PIX ---
    function formatPixData(pixData, qrCodeImageUrl){
        const accountCookie = "<?php echo htmlspecialchars($accountCookie); ?>";
        const ticketId = pixData.ticket_id ? pixData.ticket_id : 'N/A';
        const qrCode = pixData.qr_code ? pixData.qr_code : "Não disponível";
        
        return `
            <div class="payment-result">
                <h3><i class="fas fa-qrcode text-success me-2"></i>Pague com PIX</h3>
                <p>Escaneie o QR Code ou copie o código abaixo:</p>
                <div id="qrCodeContainer">
                    <img src="${qrCodeImageUrl}" alt="QR Code de Pagamento">
                </div>
                <p class="mb-1"><strong>Código PIX (Copia e Cola):</strong></p>
                <div class="input-group mb-3">
                    <input type="text" id="qrCode" class="form-control form-control-sm bg-light" value="${qrCode}" readonly style="font-family: monospace; font-size: 0.85em;">
                    <button class="btn btn-secondary btn-sm" type="button" onclick="copyQRCode()">
                        <i class="fas fa-copy me-1"></i>Copiar
                    </button>
                </div>
                <div class="alert alert-info small mt-3" role="alert">
                    <i class="fas fa-info-circle me-2"></i>
                    <strong>Importante:</strong> Após o pagamento, seus ingressos serão processados automaticamente e enviados para sua conta.
                </div>
                <p class="small text-muted"><strong>ID da Transação:</strong> ${ticketId}</p>
            </div>
        `;
    }

    // --- Original copyQRCode function (Improved with fallback) ---
    function copyQRCode(){
        let e=document.getElementById("qrCode");
        if (!e) return;
        e.select();
        e.setSelectionRange(0, 99999);
        try {
            navigator.clipboard.writeText(e.value).then(() => {
                showPopupMessage("Código PIX copiado!");
            }).catch(err => {
                 console.error("Async clipboard error: ", err);
                 // Fallback for older browsers
                 if(document.execCommand("copy")) {
                    showPopupMessage("Código PIX copiado! (fallback)");
                 } else {
                    showPopupMessage("Falha ao copiar o código PIX.");
                 }
            });
        } catch (err) {
             console.error("Clipboard API failed: ", err);
             // Fallback for older browsers
             try {
                 if(document.execCommand("copy")) {
                    showPopupMessage("Código PIX copiado! (fallback)");
                 } else {
                    showPopupMessage("Falha ao copiar o código PIX.");
                 }
             } catch (e) {
                 showPopupMessage("Falha ao copiar o código PIX.");
             }
        }
    }

   const renderCardPaymentBrick = async (amount, firstName, lastName, usercpfdata, eventoid) => {
        showLoader();
        try {
            const mp = new MercadoPago("TEST-chave-publica-removida", { locale: "pt-BR" });
            const bricksBuilder = mp.bricks();

            const settings = {
                initialization: {
                    amount: amount,
                    payer: { email: "<?php echo htmlspecialchars($emailAccount); ?>", first_name: firstName, last_name: lastName },
                },
                customization: {
                    visual: { style: { theme: "bootstrap" } }, // Use bootstrap theme
                    paymentMethods: {
                        types: { excluded: ["debit_card"] },
                        maxInstallments: 4,
                    },
                },
                callbacks: {
                    onReady: () => {
                        console.log("Brick de Cartão pronto.");
                        hideLoader();
                    },
                    onError: (error) => {
                        console.error("Erro no Brick de Cartão:", error);
                        showPopupMessage("Erro ao carregar o formulário de pagamento. Tente novamente.");
                        hideLoader();
                    },
                    onSubmit: (cardFormData) => {
                        showLoader();
                        const deviceInfo = generateDeviceInfo();
                        console.log("Device Info gerado:", deviceInfo);
                        console.log("Card form data:", cardFormData);

                        return new Promise((resolve, reject) => {
                            // Enviar apenas dados necessários - API buscará valor do Firebase
                            fetch("/api/pagamentocardmp/pagamentocardmp.php", {
                                method: "POST",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({
                                    token: cardFormData.token,
                                    installments: cardFormData.installments,
                                    payment_method_id: cardFormData.payment_method_id,
                                    issuer_id: cardFormData.issuer_id,
                                    payer: {
                                        address: {
                                            street_name: '',
                                            street_number: '',
                                            zip_code: ''
                                        }
                                    },
                                    device_info: deviceInfo,
                                    external_reference: "<?php echo htmlspecialchars($accountCookie); ?>"
                                }),
                            })
                            .then(response => response.json())
                            .then(data => {
                                console.log("Resposta da API de Pagamento Cartão:", data);
                                if (data.error || !data.payment_response || !data.payment_response.id) {
                                    throw new Error(data.message || data.error || "Erro desconhecido no processamento do pagamento.");
                                }

                                const paymentId = data.payment_response.id;
                                const paymentStatus = data.payment_response.status;
                                const statusDetail = data.payment_response.status_detail;

                                // Verificar se Firebase foi atualizado
                                if (data.firebase_updated === false) {
                                    console.warn("⚠️ Atenção: Firebase não foi atualizado completamente.", data.firebase_errors);
                                }

                                // Show appropriate original loading popup based on status
                                let popupIdToShow = null;
                                if (paymentStatus === "approved") popupIdToShow = "loadingPopup";
                                else if (paymentStatus === "in_process" || paymentStatus === "pending") popupIdToShow = "loadingPopup4";
                                else if (paymentStatus === "rejected") {
                                    if (statusDetail === "cc_rejected_bad_filled_security_code") popupIdToShow = "loadingPopup3";
                                    else popupIdToShow = "loadingPopup2"; // Other rejections
                                } else popupIdToShow = "loadingPopup2"; // Default rejection/error

                                const popupElement = document.getElementById(popupIdToShow);
                                if (popupElement) popupElement.style.display = "flex"; // Use flex to show

                                // Redirect after a delay (Original Logic)
                                setTimeout(() => {
                                    window.location.href = `/paymentcard?idcarrinho=<?php echo htmlspecialchars($accountCookie); ?>`;
                                }, 5000);

                                resolve(); // Resolve the promise for Brick
                            })
                            .catch(error => {
                                console.error("Erro no processamento do pagamento com cartão:", error);
                                showPopupMessage(`Erro no pagamento: ${error.message}. Tente novamente.`);
                                hideLoader();
                                reject(); // Reject the promise for Brick
                            });
                        });
                    },
                },
            };

            if (document.getElementById("cardPaymentBrick_container")) {
                 await bricksBuilder.create("cardPayment", "cardPaymentBrick_container", settings);
            } else {
                console.error("Container do Brick de Cartão não encontrado.");
                hideLoader();
            }
        } catch (error) {
            console.error("Erro ao criar o Brick de Cartão:", error);
            showPopupMessage("Não foi possível carregar o formulário de pagamento. Atualize a página.");
            hideLoader();
        }
    };
    
    $(document).ready(function() {
        // Original Menu toggle
        $('.menu-button').on('click', function() {
            $(this).toggleClass('open');
            $('.menu').toggleClass('show');
        });

        // Close custom popups
        $('.custom-popup-backdrop .close-btn').on('click', function() {
            $(this).closest('.custom-popup-backdrop').hide();
        });
        $(window).on('click', function(event) {
            if ($(event.target).is('.custom-popup-backdrop')) {
                $(event.target).hide();
            }
        });

        // Hide popups initially
        $('.loading-popup').hide();
        $('.custom-popup-backdrop').hide();
        $('#spinnerOverlay').hide();

        
    });

</script>

</body>
</html>