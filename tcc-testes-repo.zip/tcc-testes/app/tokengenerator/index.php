<?php
// Gerador de codigos de ingresso (versao original, sem a funcao nao utilizada)
function generateRandomCode() {
    $letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $numbers = '0123456789';
    $randomLetters = substr(str_shuffle($letters), 0, 5);
    $randomNumbers = substr(str_shuffle($numbers), 0, 3);
    $codeArray = str_split($randomLetters . $randomNumbers);
    shuffle($codeArray);
    return implode('', $codeArray);
}
header('Content-Type: application/json');
echo json_encode(['token' => generateRandomCode()]);
