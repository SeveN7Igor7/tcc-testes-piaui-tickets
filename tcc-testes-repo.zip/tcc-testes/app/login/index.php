<?php
// Configurar o tempo de vida da sessão para 3 dias (259200 segundos)
ini_set('session.gc_maxlifetime', 259200);
ini_set('session.cookie_lifetime', 259200);

// Iniciar sessão após as configurações
session_start();

// URL do Firebase Realtime Database
$firebaseUrl = rtrim(getenv('FIREBASE_URL'), '/') . '/'; // TESTE: banco de teste

// Inicializa variáveis padrão
$cpf_email = isset($_POST['cpf_email']) ? $_POST['cpf_email'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$cpf_email = preg_replace('/[^0-9]/', '', $cpf_email); // Apenas números para CPF
$message = '';
$userInfo = '';
$showPhonePopup = false; // Inicializa como falso por padrão
$userData = null;

$chave_criptografia = getenv('CHAVE_SENHA'); // TESTE: chave apenas de teste

// Função para descriptografar a senha
function descriptografarSenha($senha_criptografada, $chave) {
    $metodo = "AES-256-CBC";
    $senha_criptografada = base64_decode($senha_criptografada);
    $iv_length = openssl_cipher_iv_length($metodo);
    $iv = substr($senha_criptografada, 0, $iv_length);
    $criptografado = substr($senha_criptografada, $iv_length);
    return openssl_decrypt($criptografado, $metodo, $chave, 0, $iv);
}

// Função para buscar dados do Firebase
function fetchFirebaseData($url) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

// Verificar se já existe uma sessão ativa
if (isset($_SESSION['user_data'])) {
    $userData = $_SESSION['user_data'];
    $cpf_email = $userData['cpf'];
    
    // Verificar se os dados da sessão estão atualizados
    $userUrl = $firebaseUrl . 'users/cpf/' . $cpf_email . '.json';
    $latestUserData = fetchFirebaseData($userUrl);
    
    // Atualizar dados da sessão se necessário
    if ($latestUserData) {
        $_SESSION['user_data'] = $latestUserData;
        $userData = $latestUserData;
    }
}

// Verifica se a entrada é um CPF ou email
if (isset($_POST['login'])) {
    // Se for um email ou conter letras, exibe mensagem de erro
    if (!ctype_digit($cpf_email)) {
        $message = 'Por favor, insira somente números no campo CPF!';
    } else {
        // Verifica se a entrada é um email válido
        if (filter_var($cpf_email, FILTER_VALIDATE_EMAIL)) {
            $message = 'Por favor, insira apenas números no campo CPF!';
        } else {
            // ----------- NOVA LÓGICA DE LOGIN VIA API ------------
            $apiUrl = getenv('SITE_URL') . '/api/validacao.php'; // TESTE: mesmo servidor, como em producao
            
            $postFields = [
                'cpf' => $cpf_email,
                'password' => $password
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $apiUrl);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $apiResponse = curl_exec($ch);
            curl_close($ch);

            $apiData = json_decode($apiResponse, true);

            if ($apiData && isset($apiData['success']) && $apiData['success'] === true) {
                $userData = $apiData['user'];
                $message = 'Login bem-sucedido!';

                // Armazenar dados do usuário na sessão
                $_SESSION['user_data'] = $userData;
                $_SESSION['login_time'] = time();

                // Verificar se o telefone está cadastrado
                if (!isset($userData['telefone']) || empty($userData['telefone'])) {
                    $showPhonePopup = true;
                }
            } else {
                $message = $apiData['message'] ?? 'CPF ou senha inválidos!';
            }
            // ------------------------------------------------------
        }
    }
}


// Função para processar logout
if (isset($_GET['logout'])) {
    // Destruir a sessão
    session_unset();
    session_destroy();
    
    // Redirecionar para a página de login
    header('Location: index.php');
    exit;
}

// Função para gerar informações do usuário (mantida para compatibilidade)
function gerarInfoUsuario($user, $firebaseUrl) {
    $output = "<div class='user-info'>";
    $output .= "<h2>Bem-vindo, " . htmlspecialchars($user['fullname']) . "!</h2>";
    $output .= "<p><strong>Email:</strong> " . htmlspecialchars($user['email']) . "</p>";
    $output .= "<p><strong>Ingressos adquiridos:</strong></p>";

    if (isset($user['ingressoscomprados']) && !empty($user['ingressoscomprados'])) {
        foreach ($user['ingressoscomprados'] as $token => $ticket) {
            $eventId = $ticket['eventid'];
            $ticketDetailsUrl = $firebaseUrl . 'eventos/' . $eventId . '.json';
            $eventDetails = fetchFirebaseData($ticketDetailsUrl);

            $ticketTypeUrl = $firebaseUrl . 'users/cpf/' . $user['cpf'] . '/ingressoscomprados/' . $token . '.json';
            $ticketData = fetchFirebaseData($ticketTypeUrl);
            $ticketType = $ticketData['tipo'] ?? 'Tipo não especificado';

            if ($eventDetails) {
                $output .= "<div class='ticket-info'>";
                $output .= "<p><strong>Seu Ingresso:</strong> " . htmlspecialchars($token) . "</p>";
                $output .= "<p><strong>Nome do Evento:</strong> " . htmlspecialchars($eventDetails['nomeevento']) . "</p>";
                $output .= "<p><strong>Tipo do Ingresso:</strong> " . htmlspecialchars($ticketType) . "</p>";
                $output .= "</div>";
            }
        }
    } else {
        $output .= "<p>Você ainda não comprou ingressos.</p>";
    }
    $output .= "</div>";
    return $output;
}

// Função para obter eventos únicos dos ingressos do usuário
function getUniqueEvents($userData, $firebaseUrl) {
    $events = [];
    
    if (isset($userData['ingressoscomprados']) && !empty($userData['ingressoscomprados'])) {
        foreach ($userData['ingressoscomprados'] as $token => $ticket) {
            $eventId = $ticket['eventid'];
            
            // Buscar detalhes do evento se ainda não estiver na lista
            if (!isset($events[$eventId])) {
                $eventDetailsUrl = $firebaseUrl . 'eventos/' . $eventId . '.json';
                $eventDetails = fetchFirebaseData($eventDetailsUrl);
                
                if ($eventDetails) {
                    $events[$eventId] = [
                        'id' => $eventId,
                        'name' => $eventDetails['nomeevento'] ?? 'Evento sem nome'
                    ];
                }
            }
        }
    }
    
    return $events;
}

// Função para contar ingressos por evento
function countTicketsByEvent($userData) {
    $eventCounts = [];
    
    if (isset($userData['ingressoscomprados']) && !empty($userData['ingressoscomprados'])) {
        foreach ($userData['ingressoscomprados'] as $token => $ticket) {
            $eventId = $ticket['eventid'];
            
            if (!isset($eventCounts[$eventId])) {
                $eventCounts[$eventId] = 1;
            } else {
                $eventCounts[$eventId]++;
            }
        }
    }
    
    return $eventCounts;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Área do Usuário | PI TICKETS</title>
    <link rel="icon" href="../images/favicon.ico" type="image/x-icon">
    <link rel="icon" type="image/png" sizes="32x32" href="../images/favicon-32x32.png">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700;900&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="script.js" defer></script>
    <style>
        /* Estilos gerais para a página de perfil */
        :root {
            --primary-color: #007bff;
            --primary-dark: #0056b3;
            --primary-light: #e6f2ff;
            --secondary-color: #f0f0f0;
            --accent-color: #ff5722;
            --accent-dark: #e64a19;
            --accent-light: #ffccbc;
            --text-color: #333;
            --text-light: #666;
            --text-dark: #111;
            --white: #ffffff;
            --success: #28a745;
            --warning: #ffc107;
            --danger: #dc3545;
            --gray-100: #f8f9fa;
            --gray-200: #e9ecef;
            --gray-300: #dee2e6;
            --gray-400: #ced4da;
            --gray-500: #adb5bd;
            --gray-600: #6c757d;
            --gray-700: #495057;
            --gray-800: #343a40;
            --gray-900: #212529;
            --shadow-sm: 0 2px 4px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 8px rgba(0,0,0,0.1);
            --shadow-lg: 0 8px 16px rgba(0,0,0,0.1);
            --shadow-xl: 0 12px 24px rgba(0,0,0,0.15);
            --radius-sm: 4px;
            --radius-md: 8px;
            --radius-lg: 12px;
            --radius-xl: 16px;
            --transition: all 0.3s ease;
        }
        
        /* Reset global para evitar overflow */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            max-width: 100%;
        }
        
        /* Estilos para o formulário de login */
        .login-form-container {
            max-width: 450px;
            margin: 50px auto;
            padding: 30px;
            background: linear-gradient(to bottom, #ffffff, #f8f9fa);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-lg);
            text-align: center;
            border: 1px solid var(--gray-200);
            transition: var(--transition);
        }

        .login-form-container:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-xl);
        }

        .login-form-container h2 {
            color: var(--primary-color);
            font-size: 1.8em;
            margin-bottom: 25px;
            position: relative;
            padding-bottom: 15px;
        }

        .login-form-container h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background: linear-gradient(to right, var(--primary-color), var(--primary-light));
            border-radius: 3px;
        }

        #loginForm {
            display: flex;
            flex-direction: column;
            gap: 20px;
            margin-bottom: 20px;
        }

        #loginForm input {
            padding: 15px;
            border: 2px solid var(--gray-300);
            border-radius: var(--radius-md);
            font-size: 16px;
            transition: var(--transition);
            width: 100%;
        }

        #loginForm input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.1);
            outline: none;
        }

        #loginForm input::placeholder {
            color: var(--gray-500);
        }

        #loginForm button {
            background: linear-gradient(to right, var(--primary-color), var(--primary-dark));
            color: white;
            border: none;
            padding: 15px;
            border-radius: var(--radius-md);
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        #loginForm button:hover {
            background: linear-gradient(to right, var(--primary-dark), var(--primary-color));
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .login-form-container p {
            margin-top: 20px;
            color: var(--gray-600);
        }

        .login-form-container p a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
        }

        .login-form-container p a:hover {
            color: var(--primary-dark);
            text-decoration: underline;
        }

        /* Mensagem de erro/sucesso no login */
        .login-form-container > p {
            padding: 10px;
            margin-top: 15px;
            border-radius: var(--radius-md);
            background-color: var(--gray-100);
            color: var(--gray-800);
            font-weight: 500;
        }

        /* Animação de entrada para o formulário */
        @keyframes formFadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .login-form-container {
            animation: formFadeIn 0.5s ease-out;
        }

        body {
            background-color: #f5f7fa;
            color: var(--text-color);
            font-family: 'Lato', sans-serif;
            overflow-x: hidden; /* Prevenir scroll horizontal */
            width: 100%;
            position: relative;
        }

        /* Estilo do modal */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6);
            animation: fadeIn 0.3s ease;
            backdrop-filter: blur(5px);
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        .modal-content {
            background-color: var(--white);
            margin: 10% auto;
            padding: 30px;
            border-radius: var(--radius-lg);
            width: 90%;
            max-width: 500px;
            box-shadow: var(--shadow-xl);
            animation: slideIn 0.4s ease-out;
            position: relative;
            border-top: 5px solid var(--primary-color);
        }

        @keyframes slideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        .close {
            position: absolute;
            top: 15px;
            right: 20px;
            color: var(--gray-600);
            font-size: 28px;
            font-weight: bold;
            transition: var(--transition);
        }

        .close:hover, .close:focus {
            color: var(--gray-900);
            text-decoration: none;
            cursor: pointer;
        }

        /* Layout principal da página de perfil */
        .profile-container {
            width: 95%;
            max-width: 1200px;
            margin: 30px auto;
            display: grid;
            grid-template-columns: 300px 1fr;
            grid-gap: 30px;
            position: relative;
        }

        /* Sidebar do perfil */
        .profile-sidebar {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            border-radius: var(--radius-lg);
            padding: 30px;
            color: var(--white);
            box-shadow: var(--shadow-lg);
            position: sticky;
            top: 30px;
            height: fit-content;
        }

        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background-color: var(--white);
            margin: 0 auto 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 50px;
            color: var(--primary-color);
            box-shadow: var(--shadow-md);
            border: 4px solid rgba(255, 255, 255, 0.2);
            overflow: hidden;
            position: relative;
        }

        .profile-avatar::after {
            content: '';
            position: absolute;
            top: -10px;
            left: -10px;
            right: -10px;
            bottom: -10px;
            background: linear-gradient(45deg, rgba(255,255,255,0.1), rgba(255,255,255,0));
            transform: rotate(45deg);
            pointer-events: none;
        }

        .profile-name {
            font-size: 1.8em;
            font-weight: 700;
            text-align: center;
            margin-bottom: 5px;
            color: var(--white);
            text-shadow: 0 1px 2px rgba(0,0,0,0.1);
        }

        .profile-info {
            margin: 25px 0;
        }

        .profile-info-item {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .profile-info-item:last-child {
            border-bottom: none;
        }

        .profile-info-icon {
            width: 30px;
            margin-right: 15px;
            text-align: center;
            font-size: 18px;
        }

        .profile-info-text {
            flex: 1;
        }

        .profile-info-label {
            font-size: 0.85em;
            opacity: 0.8;
            margin-bottom: 3px;
        }

        .profile-info-value {
            font-weight: 600;
            font-size: 1.05em;
        }

        .logout-link {
            display: block;
            text-align: center;
            background-color: rgba(255, 255, 255, 0.15);
            color: var(--white);
            text-decoration: none;
            padding: 12px;
            border-radius: var(--radius-md);
            margin-top: 30px;
            font-weight: 600;
            transition: var(--transition);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .logout-link:hover {
            background-color: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
        }

        /* Conteúdo principal */
        .profile-content {
            display: flex;
            flex-direction: column;
            gap: 30px;
            width: 100%;
            max-width: 100%;
        }

        .content-card {
            background-color: var(--white);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
            overflow: hidden;
            transition: var(--transition);
            width: 100%;
        }

        .content-card:hover {
            box-shadow: var(--shadow-lg);
        }

        .card-header {
            padding: 20px 25px;
            border-bottom: 1px solid var(--gray-200);
            display: flex;
            align-items: center;
            justify-content: space-between;
            background-color: var(--gray-100);
        }

        .card-title {
            font-size: 1.4em;
            font-weight: 700;
            color: var(--gray-800);
            margin: 0;
            display: flex;
            align-items: center;
        }

        .card-title i {
            margin-right: 12px;
            color: var(--primary-color);
            font-size: 1.2em;
        }

        .card-body {
            padding: 30px; /* Aumentado para dar mais espaço */
            overflow: hidden;
            position: relative;
            width: 100%;
        }

        /* Seletor de eventos */
        .event-selector-container {
            margin-bottom: 30px; /* Aumentado para dar mais espaço */
            width: 100%;
        }

        .event-selector-label {
            display: block;
            margin-bottom: 15px; /* Aumentado para dar mais espaço */
            font-weight: 600;
            color: var(--gray-700);
            font-size: 1.1em; /* Aumentado para melhor legibilidade */
        }

        .event-selector {
            width: 100%;
            padding: 18px; /* Aumentado para dar mais espaço */
            border: 2px solid var(--gray-300);
            border-radius: var(--radius-md);
            font-size: 18px; /* Aumentado para melhor legibilidade */
            background-color: var(--white);
            cursor: pointer;
            transition: var(--transition);
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23333' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right 15px center;
            background-size: 15px;
            padding-right: 45px;
            color: var(--gray-800);
            font-weight: 500;
        }

        .event-selector:hover, .event-selector:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.1);
            outline: none;
        }

        /* Mensagem quando não há ingressos */
        .no-tickets-message {
            text-align: center;
            padding: 60px 30px; /* Aumentado para dar mais espaço */
            color: var(--gray-600);
            font-style: italic;
            background-color: var(--gray-100);
            border-radius: var(--radius-md);
            border: 1px dashed var(--gray-300);
            font-size: 1.2em; /* Aumentado para melhor legibilidade */
        }

        /* Classe para esconder elementos */
        .hidden {
            display: none !important;
        }

        /* MODIFICAÇÃO: Container de tickets com altura automática para exibição vertical */
        #tickets-container {
            min-height: 400px; /* Aumentado significativamente */
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            overflow: visible;
            margin: 0;
            padding: 20px 0; /* Adicionado padding vertical */
            width: 100%;
            gap: 30px; /* Aumentado o espaçamento entre ingressos */
        }

        /* Cartão de ingresso com dimensões máximas e contenção - OTIMIZADO PARA MOBILE */
        .ticket-card {
            background: var(--white);
            border-radius: var(--radius-lg); /* Aumentado para bordas mais suaves */
            overflow: visible;
            box-shadow: var(--shadow-md); /* Aumentado para sombra mais visível */
            transition: var(--transition);
            position: relative;
            border: 2px solid var(--gray-200); /* Aumentado a espessura da borda */
            height: auto;
            max-height: none;
            display: flex;
            flex-direction: column;
            max-width: 100%; /* Aumentado para 100% para ocupar toda a largura disponível */
            width: 100%; /* Aumentado para 100% para ocupar toda a largura disponível */
            margin: 0 auto 30px; /* Aumentado a margem inferior */
        }

        .ticket-card:hover {
            transform: translateY(-5px); /* Adicionado efeito hover */
            box-shadow: var(--shadow-lg);
        }

        /* Cabeçalho do ingresso com overflow controlado - OTIMIZADO */
        .ticket-header {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: var(--white);
            padding: 30px; /* Aumentado ainda mais */
            position: relative;
            overflow: hidden;
            z-index: 1;
            flex-shrink: 0;
        }

        /* Correção do efeito de onda para não causar overflow */
        .ticket-header:after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 0;
            right: 0;
            height: 16px;
            background-image: radial-gradient(circle at 8px 8px, transparent 10px, var(--white) 11px);
            background-size: 16px 16px;
            background-position: -8px -8px;
            z-index: 2;
        }

        /* Nome do evento com texto controlado - OTIMIZADO */
        .ticket-event-name {
            font-size: 1.8em; /* Aumentado ainda mais */
            font-weight: 700;
            margin: 0;
            line-height: 1.3;
            text-shadow: 0 1px 2px rgba(0,0,0,0.1);
            white-space: normal;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
        }

        /* ID do evento com texto controlado */
        .ticket-event-id {
            font-size: 1.1em; /* Aumentado */
            opacity: 0.8;
            margin-top: 12px; /* Aumentado */
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        /* Corpo do ingresso com overflow controlado - OTIMIZADO */
        .ticket-body {
            padding: 30px; /* Aumentado ainda mais */
            flex: 1;
            overflow: visible;
            display: flex;
            flex-direction: column;
            min-height: 250px; /* Aumentado ainda mais */
            max-height: none;
        }

        /* Linhas de informação com contenção - OTIMIZADO */
        .ticket-info-row {
            margin-bottom: 30px; /* Aumentado */
            padding-bottom: 30px; /* Aumentado */
            border-bottom: 1px dashed var(--gray-300);
            width: 100%;
            overflow: visible;
        }

        .ticket-info-row:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        /* Rótulos de informação com tamanho controlado */
        .ticket-info-label {
            font-size: 1.2em; /* Aumentado */
            color: var(--gray-600);
            margin-bottom: 15px; /* Aumentado */
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        /* Valores de informação com texto controlado - OTIMIZADO */
        .ticket-info-value {
            font-weight: 600;
            color: var(--gray-800);
            font-size: 1.5em; /* Aumentado ainda mais */
            word-break: break-word;
            overflow-wrap: break-word;
        }

        /* Código do ingresso com quebra de palavra controlada - OTIMIZADO PARA MOBILE */
        .ticket-code {
            background-color: var(--gray-100);
            padding: 20px; /* Aumentado */
            border-radius: var(--radius-md);
            font-family: monospace;
            font-size: 1.7em; /* Aumentado ainda mais */
            letter-spacing: 1px;
            border: 2px dashed var(--gray-300);
            text-align: center;
            word-break: break-all;
            overflow-wrap: break-word;
            max-width: 100%;
            overflow: visible;
            margin: 15px 0; /* Aumentado */
            display: block;
            box-shadow: inset 0 0 8px rgba(0,0,0,0.05);
        }

        /* Container do QR code com dimensões controladas - OTIMIZADO */
        .ticket-qr-container {
            background-color: var(--white);
            padding: 30px; /* Aumentado */
            border-top: 2px solid var(--gray-200);
            text-align: center;
            overflow: visible;
            width: 100%;
            flex-shrink: 0;
            margin-top: auto;
        }

        /* QR code com tamanho máximo e centralização - OTIMIZADO */
        .ticket-qr-code {
            display: inline-block;
            padding: 20px; /* Aumentado */
            background-color: var(--white);
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-md);
            transition: var(--transition);
            max-width: 100%;
            margin: 0 auto;
        }

        .ticket-qr-code img {
            max-width: 100%;
            height: auto;
            border: 2px solid var(--gray-200);
            border-radius: var(--radius-sm);
            padding: 10px; /* Aumentado */
            transition: var(--transition);
            display: block;
        }

        /* Contador de ingressos reposicionado */
        .ticket-counter {
            position: absolute;
            top: 15px;
            right: 15px;
            background-color: var(--accent-color);
            color: white;
            border-radius: 50%;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
            z-index: 5;
        }

        /* Correção para animação de destaque sem quebrar layout */
        @keyframes pulse {
            0% { transform: scale(1); box-shadow: var(--shadow-md); }
            50% { transform: scale(1.02); box-shadow: var(--shadow-lg); }
            100% { transform: scale(1); box-shadow: var(--shadow-md); }
        }

        .ticket-card.highlight {
            animation: pulse 1.5s ease-in-out;
            border: 2px solid var(--accent-color);
        }

        /* Estatísticas do evento */
        .event-stats {
            display: flex;
            justify-content: space-between;
            background: linear-gradient(to right, var(--primary-light), var(--white));
            border-radius: var(--radius-md);
            padding: 20px;
            margin-top: 25px;
            border: 2px solid var(--gray-200);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
        }

        .event-stats:hover {
            box-shadow: var(--shadow-md);
            transform: translateY(-2px);
        }

        .event-stat-item {
            text-align: center;
            padding: 0 20px;
            position: relative;
        }

        .event-stat-item:not(:last-child)::after {
            content: '';
            position: absolute;
            right: 0;
            top: 20%;
            height: 60%;
            width: 1px;
            background-color: var(--gray-300);
        }

        .event-stat-value {
            font-size: 2em;
            font-weight: 700;
            color: var(--primary-color);
            text-shadow: 0 1px 2px rgba(0,0,0,0.05);
        }

        .event-stat-label {
            font-size: 1em;
            color: var(--gray-600);
            margin-top: 8px;
        }

        /* Responsividade aprimorada - OTIMIZADA PARA SAMSUNG S20 FE */
        @media (max-width: 992px) {
            .profile-container {
                grid-template-columns: 1fr;
                width: 92%;
            }
            
            .profile-sidebar {
                position: relative;
                top: 0;
                margin-bottom: 20px;
            }
            
            .ticket-card {
                max-width: 100%;
                width: 100%;
            }
        }

        @media (max-width: 768px) {
            .profile-container {
                width: 95%;
                margin: 20px auto;
            }
            
            .ticket-body {
                padding: 25px;
                min-height: 220px;
            }
            
            .ticket-qr-container {
                padding: 25px;
            }
            
            .ticket-qr-code {
                padding: 15px;
                max-width: 95%;
            }
            
            .ticket-code {
                font-size: 1.5em;
                padding: 18px;
            }
            
            .event-stats {
                flex-direction: column;
                align-items: center;
            }
            
            .event-stat-item {
                margin-bottom: 15px;
                width: 100%;
            }
            
            .event-stat-item:not(:last-child)::after {
                display: none;
            }
            
            .card-body {
                padding: 20px;
            }
        }

        /* Correção específica para Samsung S20 FE e dispositivos similares */
        @media (max-width: 412px) {
            .profile-container {
                width: 95%;
                margin: 15px auto;
                grid-gap: 20px;
            }
            
            .profile-sidebar {
                padding: 20px;
            }
            
            .profile-avatar {
                width: 100px;
                height: 100px;
                font-size: 40px;
            }
            
            .profile-name {
                font-size: 1.5em;
            }
            
            .card-header {
                padding: 15px;
            }
            
            .card-title {
                font-size: 1.2em;
            }
            
            .card-body {
                padding: 15px;
            }
            
            .ticket-header {
                padding: 20px;
            }
            
            .ticket-event-name {
                font-size: 1.5em;
            }
            
            .ticket-body {
                padding: 20px;
                min-height: 200px;
            }
            
            .ticket-info-row {
                margin-bottom: 20px;
                padding-bottom: 20px;
            }
            
            .ticket-info-value {
                font-size: 1.3em;
            }
            
            .ticket-code {
                font-size: 1.3em;
                padding: 15px;
                letter-spacing: 0.5px;
            }
            
            .ticket-qr-code {
                max-width: 90%;
            }
        }

        /* Correção específica para dispositivos muito pequenos */
        @media (max-width: 360px) {
            .profile-container {
                width: 95%;
                margin: 12px auto;
                grid-gap: 15px;
            }
            
            .profile-sidebar {
                padding: 15px;
            }
            
            .profile-avatar {
                width: 90px;
                height: 90px;
                font-size: 35px;
            }
            
            .profile-name {
                font-size: 1.3em;
            }
            
            .card-header {
                padding: 12px;
            }
            
            .card-title {
                font-size: 1.1em;
            }
            
            .card-body {
                padding: 12px;
            }
            
            .ticket-header {
                padding: 15px;
            }
            
            .ticket-event-name {
                font-size: 1.3em;
            }
            
            .ticket-body {
                padding: 15px;
                min-height: 180px;
            }
            
            .ticket-info-row {
                margin-bottom: 15px;
                padding-bottom: 15px;
            }
            
            .ticket-info-value {
                font-size: 1.2em;
            }
            
            .ticket-code {
                font-size: 1.1em;
                padding: 12px;
                letter-spacing: 0;
            }
            
            .ticket-qr-code {
                max-width: 85%;
                padding: 10px;
            }
            
            .ticket-qr-code img {
                padding: 5px;
            }
        }

        /* Mensagens de notificação */
        .message-container {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 20px;
            border-radius: var(--radius-md);
            background-color: var(--white);
            box-shadow: var(--shadow-lg);
            display: flex;
            align-items: center;
            z-index: 1000;
            transform: translateX(120%);
            transition: transform 0.3s ease;
            max-width: 350px;
        }

        .message-container.show {
            transform: translateX(0);
        }

        .message-container.success {
            border-left: 4px solid var(--success);
        }

        .message-container.error {
            border-left: 4px solid var(--danger);
        }

        .message-icon {
            margin-right: 15px;
            font-size: 24px;
        }

        .message-container.success .message-icon {
            color: var(--success);
        }

        .message-container.error .message-icon {
            color: var(--danger);
        }

        .message-text {
            font-size: 14px;
            color: var(--text-color);
        }
    </style>
</head>
<body>
    <header>
        <a href="/index.php"><img src="../images/logo.png" alt="Logo da Empresa" class="logo"></a>
        <div class="header-links">
            <a href="/cadastro">Cadastro</a>
            <a href="../login">Área do Usuário</a>
            <a href="/area-do-organizador">Área do Organizador</a>
        </div>
        <button class="menu-button">
            <div></div>
            <div></div>
            <div></div>
        </button>
        <div class="menu">
            <a href="/cadastro">Cadastro</a>
            <a href="/login">Área do Usuário</a>
            <a href="/area-do-organizador">Área do Organizador</a>
        </div>
    </header>
    
    <main>
        <?php
        // Verificar se os dados do usuário estão disponíveis
        if (isset($userData)) {
            // Exibindo o telefone (se presente)
            if (isset($userData['telefone']) && !empty($userData['telefone'])) {
                echo "<script>console.log('Telefone encontrado: " . htmlspecialchars($userData['telefone']) . "');</script>";
            } else {
                // Se não houver telefone, exibe o pop-up
                echo "<script>console.log('Telefone não encontrado ou vazio. Exibindo pop-up de pendência.');</script>";
                echo "<script>
                    document.addEventListener('DOMContentLoaded', function() {
                        document.getElementById('updateModal').style.display = 'block';
                    });
                </script>";
            }
        }
        ?>

        <?php if (isset($userData)) : ?>
            <!-- Layout da página de perfil -->
            <div class="profile-container">
                <!-- Sidebar do perfil -->
                <div class="profile-sidebar" data-user-cpf="<?php echo htmlspecialchars($userData['cpf']); ?>">
                    <div class="profile-avatar">
                        <i class="fas fa-user"></i>
                    </div>
                    <h2 class="profile-name"><?php echo htmlspecialchars($userData['fullname']); ?></h2>
                    
                    <div class="profile-info">
                        <div class="profile-info-item">
                            <div class="profile-info-icon">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <div class="profile-info-text">
                                <div class="profile-info-label">Email</div>
                                <div class="profile-info-value"><?php echo htmlspecialchars($userData['email']); ?></div>
                            </div>
                        </div>
                        
                        <div class="profile-info-item">
                            <div class="profile-info-icon">
                                <i class="fas fa-id-card"></i>
                            </div>
                            <div class="profile-info-text">
                                <div class="profile-info-label">CPF</div>
                                <div class="profile-info-value"><?php echo htmlspecialchars($userData['cpf']); ?></div>
                            </div>
                        </div>
                        
                        <div class="profile-info-item">
                            <div class="profile-info-icon">
                                <i class="fas fa-phone"></i>
                            </div>
                            <div class="profile-info-text">
                                <div class="profile-info-label">Telefone</div>
                                <div class="profile-info-value">
                                    <?php echo isset($userData['telefone']) && !empty($userData['telefone']) ? 
                                        htmlspecialchars($userData['telefone']) : 
                                        '<span style="color: rgba(255,255,255,0.6);">Não cadastrado</span>'; ?>
                                </div>
                            </div>
                        </div>
                        
                        <?php
                        // Contar ingressos
                        $ticketCount = isset($userData['ingressoscomprados']) ? count($userData['ingressoscomprados']) : 0;
                        ?>
                        <div class="profile-info-item">
                            <div class="profile-info-icon">
                                <i class="fas fa-ticket-alt"></i>
                            </div>
                            <div class="profile-info-text">
                                <div class="profile-info-label">Ingressos</div>
                                <div class="profile-info-value"><?php echo $ticketCount; ?> ingressos</div>
                            </div>
                        </div>
                    </div>
                    
                    <a href="index.php?logout=1" class="logout-link">
                        <i class="fas fa-sign-out-alt"></i> Sair
                    </a>
                </div>
                
                <!-- Conteúdo principal -->
                <div class="profile-content">
                    <!-- Card de ingressos -->
                    <div class="content-card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <i class="fas fa-ticket-alt"></i> Meus Ingressos
                            </h3>
                        </div>
                        
                        <div class="card-body">
                            <?php
                            // Obter eventos únicos
                            $events = getUniqueEvents($userData, $firebaseUrl);
                            
                            // Contar ingressos por evento
                            $eventCounts = countTicketsByEvent($userData);
                            
                            if (!empty($events)) :
                            ?>
                                <div class="event-selector-container">
                                    <label for="event-selector" class="event-selector-label">Selecione um evento para ver seus ingressos:</label>
                                    <select id="event-selector" class="event-selector">
                                        <option value="">Escolha um evento</option>
                                        <?php foreach ($events as $eventId => $event) : ?>
                                            <option value="<?php echo htmlspecialchars($eventId); ?>">
                                                <?php echo htmlspecialchars($event['name']); ?> 
                                                (<?php echo $eventCounts[$eventId]; ?> ingresso<?php echo $eventCounts[$eventId] > 1 ? 's' : ''; ?>)
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <!-- Container para exibir os ingressos do evento selecionado -->
                                <div id="tickets-container">
                                    <!-- Mensagem inicial quando nenhum evento está selecionado -->
                                    <div class="no-tickets-message">
                                        <i class="fas fa-ticket-alt" style="font-size: 2em; margin-bottom: 15px; opacity: 0.5;"></i>
                                        <p>Selecione um evento para ver seus ingressos.</p>
                                    </div>
                                </div>
                                
                                <!-- Estatísticas do evento (inicialmente ocultas) -->
                                <div id="event-stats" class="event-stats hidden">
                                    <div class="event-stat-item">
                                        <div class="event-stat-value" id="event-ticket-count">0</div>
                                        <div class="event-stat-label">Ingressos</div>
                                    </div>
                                    <div class="event-stat-item">
                                        <div class="event-stat-value" id="event-ticket-types">0</div>
                                        <div class="event-stat-label">Tipos</div>
                                    </div>
                                </div>
                            <?php else : ?>
                                <div class="no-tickets-message">
                                    <i class="fas fa-ticket-alt" style="font-size: 2em; margin-bottom: 15px; opacity: 0.5;"></i>
                                    <p>Você ainda não comprou ingressos.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Lista de ingressos (oculta inicialmente) -->
            <div class="hidden" id="all-tickets">
                <?php if (isset($userData['ingressoscomprados']) && !empty($userData['ingressoscomprados'])) : ?>
                    <?php foreach ($userData['ingressoscomprados'] as $token => $ticket) : ?>
                        <div class="ticket-card" data-event-id="<?php echo htmlspecialchars($ticket['eventid']); ?>">
                            <?php
                            // Pega o ID do evento do ingresso
                            $eventId = $ticket['eventid'];

                            // Busca os detalhes do evento no Firebase
                            $eventDetailsUrl = $firebaseUrl . 'eventos/' . $eventId . '.json';
                            $eventDetails = fetchFirebaseData($eventDetailsUrl);

                            // Verifica se os detalhes do evento foram encontrados
                            if ($eventDetails) {
                                // Pega o nome do evento
                                $eventName = $eventDetails['nomeevento'];
                            } else {
                                $eventName = 'Nome do evento não encontrado';
                            }
                            
                            // Busca o tipo do ingresso no Firebase
                            $ticketTypeUrl = $firebaseUrl . 'users/cpf/' . $cpf_email . '/ingressoscomprados/' . $token . '.json';
                            $ticketData = fetchFirebaseData($ticketTypeUrl);
                            $ticketType = $ticketData['tipo'] ?? 'Tipo não especificado';
                            ?>
                            
                            <div class="ticket-header">
                                <h4 class="ticket-event-name"><?php echo htmlspecialchars($eventName); ?></h4>
                                <div class="ticket-event-id">ID: <?php echo htmlspecialchars($ticket['eventid']); ?></div>
                            </div>
                            
                            <div class="ticket-body">
                                <div class="ticket-info-row">
                                    <div class="ticket-info-label">Tipo do Ingresso</div>
                                    <div class="ticket-info-value"><?php echo htmlspecialchars($ticketType); ?></div>
                                </div>
                                
                                <div class="ticket-info-row">
                                    <div class="ticket-info-label">Código do Ingresso</div>
                                    <div class="ticket-code"><?php echo htmlspecialchars($token); ?></div>
                                </div>
                            </div>
                            
                            <div class="ticket-qr-container">
                                <div class="ticket-qr-code">
                                    <!--<img src="https://api.invertexto.com/v1/qrcode?token=14908%7CSXeFFNfqJTUaor3UpfeK3O0i78UW1h3z&text=<?php echo urlencode($token); ?>&scale=5" alt="QR Code">-->
                                    <img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=<?php echo urlencode($token); ?>">
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        <?php else : ?>
            <!-- Formulário de login -->
            <div class="login-form-container">
                <h2>Acesse sua conta</h2>
                <form id="loginForm" method="POST">
                    <input type="text" name="cpf_email" placeholder="Seu CPF" required>
                    <input type="password" name="password" placeholder="Senha" required>
                    <button type="submit" name="login">Entrar</button>
                </form>
                <?php if (isset($message)) echo "<p>$message</p>"; ?>
                <p><a href="/recoverypassword">Esqueceu sua senha? Clique aqui</a></p>
            </div>
        <?php endif; ?>
    </main>

    <!-- Modal de Sucesso -->
    <div id="successModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="document.getElementById('successModal').style.display='none'">&times;</span>
            <h2>Login bem-sucedido!</h2>
            <p>Você será redirecionado em breve.</p>
        </div>
    </div>
    
    <footer>
        <p>&copy; 2024 PI TICKETS. Todos os direitos reservados.</p>
        <p>
            <a href="https://wa.me/5518981719745?text=Olá,%20preciso%20de%20ajuda...">
                <img src="https://img.icons8.com/ios-filled/50/ffffff/whatsapp.png" alt="WhatsApp" class="footer-icon">
                <strong>(18) 98171-9745</strong>
            </a> |
            <a href="mailto:atendimento@piauitickets.com">
                <strong>atendimento@piauitickets.com</strong>
            </a> |
            <a href="../termos">
                <strong>Termos de Serviço</strong>
            </a>
        </p>
    </footer>

    <script>
        // Script para inicializar o seletor de eventos
        document.addEventListener('DOMContentLoaded', function() {
            const eventSelector = document.getElementById('event-selector');
            const ticketsContainer = document.getElementById('tickets-container');
            const allTickets = document.getElementById('all-tickets');
            const eventStats = document.getElementById('event-stats');
            const eventTicketCount = document.getElementById('event-ticket-count');
            const eventTicketTypes = document.getElementById('event-ticket-types');
            
            if (eventSelector && ticketsContainer && allTickets) {
                eventSelector.addEventListener('change', function() {
                    const selectedEventId = this.value;
                    
                    // Limpar o container de ingressos
                    ticketsContainer.innerHTML = '';
                    
                    // Ocultar estatísticas
                    if (eventStats) {
                        eventStats.classList.add('hidden');
                    }
                    
                    if (selectedEventId) {
                        // Selecionar os ingressos do evento selecionado
                        const tickets = allTickets.querySelectorAll(`.ticket-card[data-event-id="${selectedEventId}"]`);
                        
                        if (tickets.length > 0) {
                            // Coletar tipos de ingressos únicos
                            const ticketTypes = new Set();
                            
                            // Adicionar todos os ingressos verticalmente
                            tickets.forEach((ticket, index) => {
                                const ticketClone = ticket.cloneNode(true);
                                
                                // Adicionar contador de ingressos
                                const counter = document.createElement('div');
                                counter.className = 'ticket-counter';
                                counter.textContent = `${index + 1}/${tickets.length}`;
                                ticketClone.appendChild(counter);
                                
                                // Adicionar o ingresso diretamente ao container
                                ticketsContainer.appendChild(ticketClone);
                                
                                // Coletar tipo de ingresso para estatísticas
                                const ticketTypeElement = ticketClone.querySelector('.ticket-info-value');
                                if (ticketTypeElement) {
                                    ticketTypes.add(ticketTypeElement.textContent.trim());
                                }
                            });
                            
                            // Atualizar estatísticas
                            if (eventStats && eventTicketCount && eventTicketTypes) {
                                eventTicketCount.textContent = tickets.length;
                                eventTicketTypes.textContent = ticketTypes.size;
                                eventStats.classList.remove('hidden');
                            }
                            
                            // Adicionar animação de destaque ao primeiro ingresso
                            const firstTicket = ticketsContainer.querySelector('.ticket-card');
                            if (firstTicket) {
                                firstTicket.classList.add('highlight');
                                setTimeout(() => {
                                    firstTicket.classList.remove('highlight');
                                }, 1000);
                            }
                        } else {
                            // Nenhum ingresso encontrado para o evento
                            const noTicketsMessage = document.createElement('div');
                            noTicketsMessage.className = 'no-tickets-message';
                            noTicketsMessage.innerHTML = `
                                <i class="fas fa-ticket-alt" style="font-size: 2em; margin-bottom: 15px; opacity: 0.5;"></i>
                                <p>Nenhum ingresso encontrado para este evento.</p>
                            `;
                            ticketsContainer.appendChild(noTicketsMessage);
                        }
                    } else {
                        // Nenhum evento selecionado
                        const selectEventMessage = document.createElement('div');
                        selectEventMessage.className = 'no-tickets-message';
                        selectEventMessage.innerHTML = `
                            <i class="fas fa-ticket-alt" style="font-size: 2em; margin-bottom: 15px; opacity: 0.5;"></i>
                            <p>Selecione um evento para ver seus ingressos.</p>
                        `;
                        ticketsContainer.appendChild(selectEventMessage);
                    }
                });
            }
            
            // Fechar modal
            const closeModal = document.getElementById('closeModal');
            if (closeModal) {
                closeModal.addEventListener('click', function() {
                    document.getElementById('updateModal').style.display = 'none';
                });
            }
        });
        
        // Função para mostrar mensagens
        function mostrarMensagem(texto, tipo) {
            // Remover mensagens anteriores
            const mensagemAnterior = document.querySelector('.message-container');
            if (mensagemAnterior) {
                mensagemAnterior.remove();
            }
            
            // Criar nova mensagem
            const mensagem = document.createElement('div');
            mensagem.className = `message-container ${tipo}`;
            
            const icone = document.createElement('div');
            icone.className = 'message-icon';
            icone.innerHTML = tipo === 'success' ? '<i class="fas fa-check-circle"></i>' : '<i class="fas fa-exclamation-circle"></i>';
            
            const texto_div = document.createElement('div');
            texto_div.className = 'message-text';
            texto_div.textContent = texto;
            
            mensagem.appendChild(icone);
            mensagem.appendChild(texto_div);
            document.body.appendChild(mensagem);
            
            // Mostrar mensagem
            setTimeout(() => {
                mensagem.classList.add('show');
            }, 100);
            
            // Esconder mensagem após 5 segundos
            setTimeout(() => {
                mensagem.classList.remove('show');
                setTimeout(() => {
                    mensagem.remove();
                }, 300);
            }, 5000);
        }
    </script>
</body>
</html>
