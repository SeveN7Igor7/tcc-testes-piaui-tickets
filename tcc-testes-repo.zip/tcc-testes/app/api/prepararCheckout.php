<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Content-Type: application/json; charset=utf-8");

// Responder preflight CORS rapidamente
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    // Preflight request - no body
    http_response_code(204);
    exit;
}

$firebase_base = rtrim(getenv('FIREBASE_URL'), '/') . '/';

$data = json_decode(file_get_contents("php://input"), true);
$cpf = preg_replace('/\D/', '', $data['cpf'] ?? '');
$eventid = $data['eventid'] ?? '';
$total = $data['total'] ?? 0;
$unt = $data['unt'] ?? 0;
$tipos = $data['tipos'] ?? [];
$codaffiliate = $data['codaffiliate'] ?? null;
$affiliate = $data['affiliate'] ?? null;
$semtaxa = $data['semtaxa'] ?? false;
$oferta = $data['oferta'] ?? null; // Nome da oferta (se for compra de oferta)

if (!$cpf || !$eventid || $unt <= 0 || empty($tipos)) {
    echo json_encode(["success" => false, "message" => "Dados incompletos"]);
    exit;
}

// ??? Pacotes por evento: N ingressos pelo valorbruto de 1 (definido no servidor, nï¿½o no cliente)
$pacotesPorEvento = [
    '71900' => ['TRIO PASS' => 3, 'QUINTETO PASS' => 5],
];

// Retorna a multiplicidade do tipo: para eventos com pacotes, ignora o 'type' enviado pelo cliente
function getMultiplicidade($eventid, $nometipo, $typeCliente) {
    global $pacotesPorEvento;
    if (isset($pacotesPorEvento[(string)$eventid])) {
        return $pacotesPorEvento[(string)$eventid][strtoupper(trim($nometipo))] ?? 1;
    }
    return intval($typeCliente ?? 1);
}

function getFirebase($url) {
    $response = file_get_contents($url);
    return json_decode($response, true);
}

function putFirebase($path, $data) {
    $url = rtrim(getenv('FIREBASE_URL'), '/') . "/{$path}.json";
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => "PUT",
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json']
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    return json_decode($response, true);
}

// 1. Busca dados do evento no Firebase
$evento = getFirebase($firebase_base . "eventos/{$eventid}.json");

if (!$evento) {
    echo json_encode([
        "success" => false,
        "message" => "Configuraï¿½ï¿½o incorreta, link encerrado ou evento com dados fornecidos invï¿½lidos para venda, contate o suporte"
    ]);
    exit;
}

// 1.1. Se for uma compra de OFERTA ou AFILIADO, buscar tipos especï¿½ficos ao invï¿½s do evento
$tiposParaValidar = [];
$isOferta = false;
$isAffiliate = false;

// Verificar se ï¿½ compra de AFILIADO
if (!empty($affiliate) && $affiliate === "true" && !empty($codaffiliate)) {
    // Compra de afiliado - buscar tipos do afiliado
    if (isset($evento['afiliados'][$codaffiliate]) && is_array($evento['afiliados'][$codaffiliate])) {
        $afiliadoData = $evento['afiliados'][$codaffiliate];
        
        // Verificar se o afiliado estï¿½ disponï¿½vel
        if (!isset($afiliadoData['disponivel']) || $afiliadoData['disponivel'] !== true) {
            echo json_encode([
                "success" => false,
                "message" => "Este link de afiliado nï¿½o estï¿½ mais disponï¿½vel."
            ]);
            exit;
        }
        
        // Usar tipos do afiliado
        if (isset($afiliadoData['tipos']) && is_array($afiliadoData['tipos'])) {
            $tiposParaValidar = $afiliadoData['tipos'];
            $isAffiliate = true;
        } else {
            echo json_encode([
                "success" => false,
                "message" => "Afiliado sem tipos de ingressos configurados."
            ]);
            exit;
        }
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Afiliado nï¿½o encontrado."
        ]);
        exit;
    }
}
// Se nï¿½o for afiliado, verificar se ï¿½ OFERTA
elseif (!empty($oferta)) {
    // Compra de oferta - buscar tipos da oferta
    if (isset($evento['ofertas'][$oferta]) && is_array($evento['ofertas'][$oferta])) {
        $ofertaData = $evento['ofertas'][$oferta];
        
        // Verificar se a oferta estï¿½ disponï¿½vel
        if (!isset($ofertaData['disponivel']) || $ofertaData['disponivel'] !== true) {
            echo json_encode([
                "success" => false,
                "message" => "Esta oferta nï¿½o estï¿½ mais disponï¿½vel."
            ]);
            exit;
        }
        
        // Usar tipos da oferta
        if (isset($ofertaData['tipos']) && is_array($ofertaData['tipos'])) {
            $tiposParaValidar = $ofertaData['tipos'];
            $isOferta = true;
        } else {
            echo json_encode([
                "success" => false,
                "message" => "Oferta sem tipos de ingressos configurados."
            ]);
            exit;
        }
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Oferta nï¿½o encontrada."
        ]);
        exit;
    }
} else {
    // Compra normal - usar tipos do evento
    if (!isset($evento['tipos'])) {
        echo json_encode([
            "success" => false,
            "message" => "Configuraï¿½ï¿½o incorreta, link encerrado ou evento com dados fornecidos invï¿½lidos para venda, contate o suporte"
        ]);
        exit;
    }
    $tiposParaValidar = $evento['tipos'];
}

// 2. VALIDAï¿½ï¿½O DE SEGURANï¿½A: Verificar se os valores enviados correspondem aos do Firebase
$valorTotalCalculado = 0;
$errosValidacao = [];

foreach ($tipos as $tipoKey => $tipoData) {
    $nometipo = $tipoData['nometipo'] ?? '';
    $untTipo = intval($tipoData['unt'] ?? 0);
    $valorbrutoRecebido = floatval($tipoData['valorbruto'] ?? 0);
    $multiplicity = getMultiplicidade($eventid, $nometipo, $tipoData['type'] ?? 1);

    // Buscar tipo nos tipos para validar (pode ser do evento, oferta ou afiliado)
    $tipoNoEvento = null;
    foreach ($tiposParaValidar as $key => $tipo) {
        if ($tipo['nometipo'] === $nometipo) {
            $tipoNoEvento = $tipo;
            break;
        }
    }
    
    if (!$tipoNoEvento) {
        $origem = $isAffiliate ? " no afiliado" : ($isOferta ? " na oferta" : " no evento");
        $errosValidacao[] = "Tipo de ingresso '{$nometipo}' nï¿½o encontrado" . $origem;
        continue;
    }

    // Validar multiplicidade: quantidade deve ser mï¿½ltipla de 'type'
    if ($multiplicity > 1 && $untTipo % $multiplicity !== 0) {
        $errosValidacao[] = "Quantidade para '{$nometipo}' invï¿½lida: este tipo exige mï¿½ltiplos de {$multiplicity}.";
        continue;
    }

    $grupos = $multiplicity > 1 ? intval($untTipo / $multiplicity) : $untTipo;

    // Extrair todos os valores vï¿½lidos deste tipo
    $valoresValidos = [];
    
    // Para OFERTAS e AFILIADOS: apenas o valorbruto ï¿½ vï¿½lido (sem preï¿½os promocionais adicionais)
    if ($isOferta || $isAffiliate) {
        $valorbrutoReal = floatval($tipoNoEvento['valorbruto'] ?? 0);
        $valoresValidos[] = $valorbrutoReal;

        // Taxa personalizada tambem vale para ofertas/afiliados (pagina promocional):
        // recupera o valor base (/1.10) e recalcula com a taxa personalizada do evento.
        if (($evento["pagvendaspersonalizada"] ?? false) === true && isset($evento["taxapersonalizada"])) {
            $taxaPercentualPersonalizada = floatval($evento["taxapersonalizada"]);
            $baseSemTaxaPersonalizada = round($valorbrutoReal / 1.10, 2);
            $valorComTaxaPersonalizada = round($baseSemTaxaPersonalizada * (1 + ($taxaPercentualPersonalizada / 100)), 2);
            if ($valorComTaxaPersonalizada > 0) {
                $valoresValidos[] = $valorComTaxaPersonalizada;
            }
        }
    } else {
        // Para EVENTO NORMAL: valorbruto + valores promocionais ativos
        
        // Adicionar valorbruto sempre
        $valorbrutoReal = floatval($tipoNoEvento['valorbruto'] ?? 0);
        $valoresValidos[] = $valorbrutoReal;

        // ?? Se o evento tiver taxa personalizada, o valor realmente cobrado do cliente
        // ï¿½ diferente do valorbruto padrï¿½o salvo no banco (que sempre embute 10% de taxa).
        // Recuperamos o valor base (/1.10) e recalculamos com a taxa personalizada real.
        if (($evento["pagvendaspersonalizada"] ?? false) === true && isset($evento["taxapersonalizada"])) {
            $taxaPercentualPersonalizada = floatval($evento["taxapersonalizada"]);
            $baseSemTaxaPersonalizada = round($valorbrutoReal / 1.10, 2);
            $valorComTaxaPersonalizada = round($baseSemTaxaPersonalizada * (1 + ($taxaPercentualPersonalizada / 100)), 2);
            if ($valorComTaxaPersonalizada > 0) {
                $valoresValidos[] = $valorComTaxaPersonalizada;
            }
        }
        
        // Percorrer todas as chaves do tipo para encontrar valores promocionais
        foreach ($tipoNoEvento as $chave => $valor) {
            // Verificar se ï¿½ uma chave de valor promocional (valorpromocionallink, valorpromocionallink1, etc.)
            if (preg_match('/^valorpromocionallink(\d*)$/', $chave, $matches)) {
                $sufixo = $matches[1]; // "" para sem sufixo, "1", "2", etc.
                $chaveAtivo = 'promocionallinkativo' . $sufixo;
                
                // Verificar se estï¿½ ativo
                if (isset($tipoNoEvento[$chaveAtivo]) && $tipoNoEvento[$chaveAtivo] === true) {
                    $valorPromocional = floatval($valor);
                    if ($valorPromocional > 0) {
                        $valoresValidos[] = $valorPromocional;
                    }
                }
            }
        }
        
        // ?? Verificar se o evento ou o pedido indicam sem taxa (valor SEM os 10% de taxa)
        // Aceita sem taxa quando: cliente enviou semtaxa:true OU evento tem semtaxa/semtaxapromocional definido
        if (($semtaxa === true) || (isset($evento['semtaxa']) && $evento['semtaxa'] === true) || (isset($evento['semtaxapromocional']) && $evento['semtaxapromocional'] === true)) {
            // Calcula o valor sem taxa: valorbruto / 1.10
            $valorSemTaxa = round($valorbrutoReal / 1.10, 2);
            if ($valorSemTaxa > 0) {
                $valoresValidos[] = $valorSemTaxa;
            }
        }
        
        // ?? Verificar se o evento tem casadinhastemp ativo (desconto por quantidade)
        // APENAS PARA EVENTOS NORMAIS, Nï¿½O PARA OFERTAS
        if (isset($evento['casadinhastemp']) && is_array($evento['casadinhastemp'])) {
            $casadinha = $evento['casadinhastemp'];
            
            // Verificar se casadinha estï¿½ ativo
            if (isset($casadinha['status']) && $casadinha['status'] === 'ativo') {
                // Percorrer todos os thresholds de casadinha
                foreach ($casadinha as $threshold => $valorCasadinha) {
                    if ($threshold !== 'status' && is_numeric($threshold)) {
                        // Usar 'grupos' (quantidade efetiva) ao avaliar thresholds para tipos com multiplicidade
                        if ($grupos >= intval($threshold)) {
                            $valorCasadinhaFloat = floatval($valorCasadinha);
                            if ($valorCasadinhaFloat > 0) {
                                $valoresValidos[] = $valorCasadinhaFloat;
                                // Se o evento ou pedido indicar sem taxa, aceitar tambï¿½m o valor de casadinha sem taxa
                                if (($semtaxa === true) || (isset($evento['semtaxa']) && $evento['semtaxa'] === true) || (isset($evento['semtaxapromocional']) && $evento['semtaxapromocional'] === true)) {
                                    $valorCasadinhaSemTaxa = round($valorCasadinhaFloat / 1.10, 2);
                                    if ($valorCasadinhaSemTaxa > 0) {
                                        $valoresValidos[] = $valorCasadinhaSemTaxa;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    // Verificar se o valor recebido corresponde a algum valor vï¿½lido
    $valorValido = false;
    $valorUtilizado = 0;
    
    foreach ($valoresValidos as $valorPermitido) {
        if (abs($valorbrutoRecebido - $valorPermitido) <= 0.01) {
            $valorValido = true;
            $valorUtilizado = $valorPermitido;
            break;
        }
    }
    
    // Se nenhum valor foi validado, registrar erro
    if (!$valorValido) {
        $valoresFormatados = array_map(function($v) {
            return 'R$ ' . number_format($v, 2, ',', '.');
        }, $valoresValidos);
        
        $errosValidacao[] = "Valor incorreto para '{$nometipo}': valores aceitos: " . implode(', ', $valoresFormatados) . " | recebido: R$ " . number_format($valorbrutoRecebido, 2, ',', '.');
        $valorUtilizado = $valorbrutoReal; // Usar valor bruto como fallback para cï¿½lculo
    }
    
    // Calcular valor total baseado no valor validado (usar 'grupos' para tipos com multiplicidade)
    $valorTotalCalculado += ($valorUtilizado * $grupos);
}

// Verificar se o valor total enviado corresponde ao calculado
if (abs($valorTotalCalculado - $total) > 0.01) {
    $errosValidacao[] = "Valor total incorreto: esperado R$ " . number_format($valorTotalCalculado, 2, ',', '.') . ", recebido R$ " . number_format($total, 2, ',', '.');
}

// Se houver erros de validaï¿½ï¿½o, bloquear
if (!empty($errosValidacao)) {
    // Registrar tentativa de fraude/manipulaï¿½ï¿½o
    $logDir = __DIR__ . '/logs';
    if (!file_exists($logDir)) {
        mkdir($logDir, 0777, true);
    }
    
    $logFileName = 'fraud_attempt_' . date('Y-m-d_H-i-s') . '_' . $cpf . '.json';
    $logFilePath = $logDir . '/' . $logFileName;
    
    $logContent = [
        '?? TipoAlerta' => 'TENTATIVA_MANIPULACAO_VALORES',
        '?? DataHora' => date('Y-m-d H:i:s'),
        '?? CPF' => $cpf,
        '?? EventoID' => $eventid,
        '??? Oferta' => $oferta ?? 'Nenhuma (compra normal)',
        '?? ValorRecebido' => $total,
        '?? ValorCalculado' => $valorTotalCalculado,
        '?? TiposRecebidos' => $tipos,
        '?? TiposValidados' => $tiposParaValidar,
        '  ? Erros' => $errosValidacao,
        '?? IP' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        '?? UserAgent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
    ];
    
    file_put_contents($logFilePath, json_encode($logContent, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    echo json_encode([
        "success" => false,
        "message" => "Configuraï¿½ï¿½o incorreta, link encerrado ou evento com dados fornecidos invï¿½lidos para venda, contate o suporte"
    ]);
    exit;
}

// 3. Verifica se o evento tem limite de compra
if (isset($evento['limitar']) && $evento['limitar']['limitarcompra'] === true) {
    $limite = intval($evento['limitar']['limitedecompracpf'] ?? 0);
    if ($limite > 0) {
        // 4. Verifica quantos ingressos esse CPF j  comprou para esse evento
        $comprados = getFirebase($firebase_base . "users/cpf/{$cpf}/ingressoscomprados.json");
        $quantidadeComprada = 0;
        if (is_array($comprados)) {
            foreach ($comprados as $item) {
                if (($item['eventid'] ?? '') === $eventid) {
                    $quantidadeComprada += 1;
                }
            }
        }

        if (($quantidadeComprada + $unt) > $limite) {
            echo json_encode([
                "success" => false,
                "message" => "Limite de compra atingido: voc  j  comprou {$quantidadeComprada} ingresso(s). Limite permitido: {$limite}."
            ]);
            exit;
        }
    }
}

// 5. Gera cookie e salva os dados VALIDADOS no Firebase (usando valores do Firebase, nï¿½o do cliente)
$cookie = substr(str_shuffle("abcdefghijklmnopqrstuvwxyz0123456789"), 0, 12);
$timestamp = date("c");

// Recriar tipos com valores validados do Firebase (do evento ou da oferta)
$tiposValidados = [];
foreach ($tipos as $tipoKey => $tipoData) {
    $nometipo = $tipoData['nometipo'] ?? '';
    $untTipo = intval($tipoData['unt'] ?? 0);
    $multiplicity = getMultiplicidade($eventid, $nometipo, $tipoData['type'] ?? 1);

    // Buscar valor real nos tipos validados (evento ou oferta)
    foreach ($tiposParaValidar as $key => $tipo) {
        if ($tipo['nometipo'] === $nometipo) {
            $tiposValidados[$nometipo] = [
                'nometipo' => $nometipo,
                'unt' => $untTipo,
                'type' => $multiplicity,
                'valorbruto' => floatval($tipo['valorbruto']) // Valor validado, nï¿½o do cliente
            ];
            break;
        }
    }
}

$payload = [
    "eventid" => $eventid,
    "timeout" => 300,
    "unt" => $unt,
    "user" => $cpf,
    "valortotal" => $valorTotalCalculado, // Usar valor calculado do Firebase, nï¿½o do cliente
    "paymentcompleted" => false,
    "generatedtoken" => false,
    "generatedtoken2" => false,
    "generatedtoken3" => false,
    "generatedtoken4" => false,
    "generatedtoken5" => false,
    "tipos" => $tiposValidados, // Usar tipos validados
    "timestamp" => $timestamp,
    "comprasegura" => true,
    "valorcompraseguro" => round($valorTotalCalculado * 1.1, 2), // valortotal + 10%
];

// Adiciona a chave 'semtaxa' ao payload se existir no evento
// ou se o cliente explicitamente enviou semtaxa:true no JSON
if ((isset($evento["semtaxa"]) && $evento["semtaxa"] === true) || ($semtaxa === true)) {
    $payload["semtaxa"] = true;
}

// ?? Adiciona a chave 'taxapersonalizada' ao payload se o evento tiver essa configuraï¿½ï¿½o
if (($evento["pagvendaspersonalizada"] ?? false) === true && isset($evento["taxapersonalizada"])) {
    $payload["taxapersonalizada"] = floatval($evento["taxapersonalizada"]);
}

// Adiciona o nome da oferta ao payload se for compra de oferta
if (!empty($oferta)) {
    $payload["oferta"] = $oferta;
}

// ?? Adiciona codaffiliate se enviado
if (!empty($codaffiliate)) {
    $payload["codaffiliate"] = $codaffiliate;
}

if (!empty($affiliate)) {
    $payload["affiliate"] = $affiliate;
}

putFirebase("cookies/{$cookie}", $payload);
putFirebase("cookiesfixo/{$cookie}", $payload);
putFirebase("users/cpf/{$cpf}/carrinhos/abertos/{$eventid}", [
    "quantidade" => $unt,
    "valortotal" => $valorTotalCalculado, // Usar valor calculado validado
    "tipos" => $tiposValidados, // Usar tipos validados
    "oferta" => $oferta ?? null, // Incluir nome da oferta se existir
    "codaffiliate" => $codaffiliate ?? null, // Incluir cï¿½digo do afiliado se existir
    "affiliate" => $affiliate ?? null, // Incluir flag de afiliado se existir
    "taxapersonalizada" => $payload["taxapersonalizada"] ?? null, // Incluir taxa personalizada se existir
    "last_update" => $timestamp
]);

echo json_encode([
    "success" => true,
    "cookie" => $cookie
]);
