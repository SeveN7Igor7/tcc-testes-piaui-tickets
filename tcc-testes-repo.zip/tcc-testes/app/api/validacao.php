<?php
header('Content-Type: application/json');

function descriptografarSenha($senha_criptografada, $chave) {
    $metodo = "AES-256-CBC";
    $senha_criptografada = base64_decode($senha_criptografada);
    $iv_length = openssl_cipher_iv_length($metodo);
    $iv = substr($senha_criptografada, 0, $iv_length);
    $criptografado = substr($senha_criptografada, $iv_length);
    return openssl_decrypt($criptografado, $metodo, $chave, 0, $iv);
}

$chave_criptografia = getenv('CHAVE_SENHA'); // TESTE: chave apenas de teste

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    error_log("POST request received");

    $cpf = $_POST['cpf'];
    $password = $_POST['password'];

    $url = rtrim(getenv('FIREBASE_URL'), '/') . '/users/cpf/' . urlencode($cpf) . '.json';
    $response = file_get_contents($url);
    $user = json_decode($response, true);
    $senha_descriptografada = descriptografarSenha($user['password'], $chave_criptografia);

    if ($user && $senha_descriptografada === $password) {
        unset($senha_descriptografada);
        echo json_encode(['success' => true, 'user' => $user]);
    } else {
        echo json_encode(['success' => false, 'message' => 'CPF ou senha inválidos.']);
    }
} else {
    http_response_code(405);
    echo json_encode(['message' => 'Método não permitido']);
}

?>
