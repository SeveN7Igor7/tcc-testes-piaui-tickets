<?php
// process_payment.php - Versão com segurança integrada


// TESTE: o SDK do Mercado Pago foi substituido por uma chamada HTTP ao servico simulado (MOCK_URL),
// mantendo a mesma sequencia de operacoes no banco de dados.
class MPApiException extends \Exception { public function getApiResponse() { return null; } }

// Passo 1: Configura o token de acesso do MercadoPago
// TESTE: token de acesso removido

// Recebe os dados do front-end
$data = json_decode(file_get_contents('php://input'), associative: true);

// ============================
// BUSCAR DADOS DO FIREBASE
// ============================
$firebaseBaseUrl = rtrim(getenv('FIREBASE_URL'), '/'); // TESTE: banco de teste

// Função auxiliar para fazer requisições ao Firebase
function fetchFirebase($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200) {
        return null;
    }
    
    return json_decode($response, true);
}

// Obter accountCookie (external_reference)
$accountCookie = isset($data['external_reference']) ? $data['external_reference'] : null;

if (!$accountCookie) {
    echo json_encode(['error' => 'Missing accountCookie (external_reference)']);
    http_response_code(400);
    exit;
}

// 1. Buscar dados do cookie
$cookieUrl = "{$firebaseBaseUrl}/cookies/{$accountCookie}.json";
$cookieData = fetchFirebase($cookieUrl);

if (!$cookieData) {
    echo json_encode(['error' => 'Cookie não encontrado no Firebase', 'accountCookie' => $accountCookie]);
    http_response_code(400);
    exit;
}

// 2. Extrair dados do cookie
$eventId = isset($cookieData['eventid']) ? $cookieData['eventid'] : null;
$valorTotal = isset($cookieData['valortotal']) ? floatval($cookieData['valortotal']) : null;
$valorTotalAdicional = isset($cookieData['valortotaladicional']) ? floatval($cookieData['valortotaladicional']) : null;
$userCpf = isset($cookieData['user']) ? $cookieData['user'] : null;

// Proteção de Reembolso: se o carrinho tiver comprasegura ativo, cobra o valorcompraseguro (total já com o seguro) em vez do valortotal normal
$compraSegura = isset($cookieData['comprasegura']) && $cookieData['comprasegura'] === true;
$valorCompraSeguro = isset($cookieData['valorcompraseguro']) ? floatval($cookieData['valorcompraseguro']) : null;

if ($compraSegura && $valorCompraSeguro !== null) {
    $valorTotal = $valorCompraSeguro;
} elseif ($valorTotal !== null && $valorTotal == 0.0 && $valorTotalAdicional !== null) {
    // Se o valor total for 0 (ex: cupom 100%), cobrar o valor adicional (taxa/serviço)
    $valorTotal = $valorTotalAdicional;
}

// Garantir formatação numérica correta (2 casas decimais, ponto como separador)
$valorTotal = ($valorTotal !== null) ? (float) number_format((float)$valorTotal, 2, '.', '') : null;

// Sanitizar CPF (remover pontos/traços)
$userCpfSanitized = $userCpf ? preg_replace('/\D/', '', $userCpf) : null;

if (!$eventId || $valorTotal === null || !$userCpf) {
    echo json_encode([
        'error' => 'Dados incompletos no cookie',
        'eventid' => $eventId,
        'valortotal' => $valorTotal,
        'user_cpf' => $userCpf
    ]);
    http_response_code(400);
    exit;
}

// 3. Buscar dados do usuário (email e nome)
$userUrl = "{$firebaseBaseUrl}/users/cpf/{$userCpf}.json";
$userData = fetchFirebase($userUrl);

if (!$userData) {
    echo json_encode(['error' => 'Dados do usuário não encontrados', 'user_cpf' => $userCpf]);
    http_response_code(400);
    exit;
}

$emailAccount = isset($userData['email']) ? $userData['email'] : null;
$fullName = isset($userData['fullname']) ? $userData['fullname'] : 'Cliente';

if (!$emailAccount) {
    echo json_encode(['error' => 'Email do usuário não encontrado']);
    http_response_code(400);
    exit;
}

// Separar nome
$fullNameParts = explode(' ', $fullName);
$firstName = $fullNameParts[0];
$lastName = isset($fullNameParts[1]) ? implode(' ', array_slice($fullNameParts, 1)) : '';

// 4. Buscar nome do evento
$eventUrl = "{$firebaseBaseUrl}/eventos/{$eventId}.json";
$eventData = fetchFirebase($eventUrl);
$eventName = isset($eventData['name']) ? $eventData['name'] : "Evento #{$eventId}";

// Validar valor total
if (!is_numeric($valorTotal) || $valorTotal <= 0) {
    echo json_encode(['error' => 'Invalid total value', 'total_received' => $valorTotal]);
    http_response_code(400);
    exit;
}

// Verifica se parâmetros do cartão estão presentes
if (!isset($data['token'], $data['installments'], $data['payment_method_id'], $data['issuer_id'])) {
    echo json_encode(['error' => 'Parâmetros do cartão ausentes']);
    http_response_code(400);
    exit;
}

// Gera um identificador único para o cabeçalho X-Idempotency-Key
$idempotencyKey = uniqid('card_key_', true);

// Passo 3: Cria o objeto de pagamento usando o SDK
// Garantir transaction_amount no formato esperado pela API do Mercado Pago
$transactionAmount = (float) number_format((float)$valorTotal, 2, '.', '');

$paymentData = [
    "transaction_amount" => $transactionAmount, // Valor do Firebase, formatado
    "token" => $data['token'],
    "description" => $eventName . " - Carrinho " . $accountCookie,
    'statement_descriptor' => 'PI TICKETS',
    "installments" => $data['installments'],
    "payment_method_id" => $data['payment_method_id'],
    "issuer_id" => $data['issuer_id'],
    "external_reference" => $accountCookie,
    "payer" => [
        "email" => $emailAccount,  // Email do Firebase
        "first_name" => $firstName,  // Nome do Firebase
        "last_name" => $lastName,    // Sobrenome do Firebase
        "identification" => [
            "type" => "CPF",
            "number" => $userCpfSanitized  // CPF sanitizado do Firebase
        ],
        "address" => [
            "street_name" => $data['payer']['address']['street_name'] ?? '',
            "street_number" => $data['payer']['address']['street_number'] ?? '',
            "zip_code" => $data['payer']['address']['zip_code'] ?? ''
        ]
    ],
    "additional_info" => [
        "items" => [
            [
                "id" => "item_" . $accountCookie,
                "title" => $eventName,
                "quantity" => 1,
                // unit_price também deve estar formatado corretamente
                "unit_price" => (float) number_format((float)$valorTotal, 2, '.', ''),
                "category_id" => "eventos",
                "description" => "Ingresso(s) para " . $eventName
            ]
        ]
    ]
];

// Se o device_id estiver presente, adiciona
if (isset($data['device_id'])) {
    $paymentData['device_id'] = $data['device_id'];
}

// Passo 4: Inicializa o cliente de pagamento do MercadoPago

try {
    // Passo 5: Cria as opções da requisição, incluindo o cabeçalho X-Idempotency-Key
    // Passo 6: Faz a requisição para criar o pagamento (TESTE: servico simulado no lugar do SDK)
    $chMp = curl_init(getenv('MOCK_URL') . '/v1/payments');
    curl_setopt($chMp, CURLOPT_POST, true);
    curl_setopt($chMp, CURLOPT_POSTFIELDS, json_encode($paymentData));
    curl_setopt($chMp, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($chMp, CURLOPT_HTTPHEADER, ["Content-Type: application/json", "X-Idempotency-Key: $idempotencyKey"]);
    curl_setopt($chMp, CURLOPT_TIMEOUT, 30);
    $payment = json_decode(curl_exec($chMp));
    curl_close($chMp);

    // ============================
    // ATUALIZAR FIREBASE (SEGURANÇA INTEGRADA)
    // ============================
    $firebaseUpdateSuccess = true;
    $firebaseErrors = [];

    if ($payment && isset($payment->id)) {
        $paymentId = $payment->id;
        $paymentStatus = $payment->status;
        $statusDetail = isset($payment->status_detail) ? $payment->status_detail : '';

        // Atualizar Cookie
        $cookieUpdateData = [
            'paymentIdcard' => $paymentId,
            'methodpaymenturl' => 'CARTÃO'
        ];

        $cookieUpdatePayload = json_encode($cookieUpdateData, JSON_INVALID_UTF8_SUBSTITUTE);

        $cookieUpdateUrl = "{$firebaseBaseUrl}/cookies/{$accountCookie}.json";
        $ch1 = curl_init($cookieUpdateUrl);
        curl_setopt($ch1, CURLOPT_CUSTOMREQUEST, "PATCH");
        curl_setopt($ch1, CURLOPT_POSTFIELDS, $cookieUpdatePayload);
        curl_setopt($ch1, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch1, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
        curl_setopt($ch1, CURLOPT_TIMEOUT, 10);
        $cookieResult = curl_exec($ch1);
        $cookieHttpCode = curl_getinfo($ch1, CURLINFO_HTTP_CODE);

        if (curl_errno($ch1)) {
            $firebaseUpdateSuccess = false;
            $firebaseErrors[] = "Erro ao atualizar cookie: " . curl_error($ch1);
        } elseif ($cookieHttpCode < 200 || $cookieHttpCode >= 300) {
            $firebaseUpdateSuccess = false;
            $firebaseErrors[] = "Erro ao atualizar cookie: HTTP {$cookieHttpCode} - {$cookieResult}";
        }
        curl_close($ch1);

        // Atualizar PontesMP
        // JSON_INVALID_UTF8_SUBSTITUTE evita que bytes inválidos vindos da resposta do Mercado Pago derrubem o encode inteiro
        $ponteMpUpdateData = [
            'usercpf' => $userCpfSanitized,
            'codcarrinho' => $accountCookie,
            'eventId' => $eventId,
            'paymentStatus' => $paymentStatus,
            'statusDetail' => $statusDetail,
            'paymentDetails' => json_decode(json_encode($payment, JSON_INVALID_UTF8_SUBSTITUTE), true), // Converter objeto para array
            'methodpaymenturl' => 'CARTÃO'
        ];

        $ponteMpPayload = json_encode($ponteMpUpdateData, JSON_INVALID_UTF8_SUBSTITUTE);
        if ($ponteMpPayload === false) {
            $firebaseUpdateSuccess = false;
            $firebaseErrors[] = "Erro ao atualizar pontesmp: falha ao codificar JSON - " . json_last_error_msg();
        } else {
            $ponteMpUrl = "{$firebaseBaseUrl}/pontesmp/{$paymentId}.json";
            $ch2 = curl_init($ponteMpUrl);
            curl_setopt($ch2, CURLOPT_CUSTOMREQUEST, "PUT");
            curl_setopt($ch2, CURLOPT_POSTFIELDS, $ponteMpPayload);
            curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch2, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
            curl_setopt($ch2, CURLOPT_TIMEOUT, 10);
            $ponteMpResult = curl_exec($ch2);
            $ponteMpHttpCode = curl_getinfo($ch2, CURLINFO_HTTP_CODE);

            if (curl_errno($ch2)) {
                $firebaseUpdateSuccess = false;
                $firebaseErrors[] = "Erro ao atualizar pontesmp: " . curl_error($ch2);
            } elseif ($ponteMpHttpCode < 200 || $ponteMpHttpCode >= 300) {
                $firebaseUpdateSuccess = false;
                $firebaseErrors[] = "Erro ao atualizar pontesmp: HTTP {$ponteMpHttpCode} - {$ponteMpResult}";
            }
            curl_close($ch2);
        }
    }

    // Passo 7: Retorna toda a resposta do pagamento em formato JSON
    header('Content-Type: application/json');
    
    // ============================
    // SALVAR LOG (ENTRADA + SAÍDA)
    // ============================
    $logDir = __DIR__ . '/../../api/registrologsapi';
    if (!file_exists($logDir)) {
        mkdir($logDir, 0777, true);
    }
    
    $logFileName = 'log_card_' . date('Y-m-d_H-i-s') . '_' . ($payment->id ?? 'error') . '.json';
    $logFilePath = $logDir . '/' . $logFileName;
    
    $logContent = [
        '&#128338; DataHora' => date('Y-m-d H:i:s'),
        '&#128179; TipoPagamento' => 'CARTÃO',
        '&#128229; RequisicaoRecebida' => [
            'accountCookie' => $accountCookie,
            'token_received' => isset($data['token']) ? 'Yes' : 'No',
            'installments' => $data['installments'] ?? null,
            'payment_method' => $data['payment_method_id'] ?? null,
            'raw_payload' => $data
        ],
        '&#128269; DadosBuscadosFirebase' => [
            'eventId' => $eventId,
            'eventName' => $eventName,
            'userCpf' => $userCpf,
            'email' => $emailAccount,
            'fullName' => $fullName,
            'compra_segura' => $compraSegura ?? false,
            'valor_total' => 'R$ ' . number_format($valorTotal, 2, ',', '.'),
            'cookie_data' => $cookieData
        ],
        '&#128228; EnviadoParaMercadoPago' => $paymentData,
        '&#128236; RespostaMercadoPago' => json_decode(json_encode($payment), true),
        '&#128293; FirebaseAtualizado' => $firebaseUpdateSuccess,
        '&#9888;&#65039; ErrosFirebase' => $firebaseErrors
    ];
    
    file_put_contents($logFilePath, json_encode($logContent, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    
    echo json_encode([
        'status' => 'success',
        'payment_response' => $payment,
        'firebase_updated' => $firebaseUpdateSuccess,
        'firebase_errors' => $firebaseErrors
    ]);
    http_response_code(200);

} catch (MPApiException $e) {
    // Erro ao processar a requisição com MercadoPago
    $apiResponse = $e->getApiResponse();
    $statusCode = $apiResponse ? $apiResponse->getStatusCode() : null;
    $content = $apiResponse ? $apiResponse->getContent() : null;

    // Salvar log de erro detalhado
    $errLogDir = __DIR__ . '/../../api/registrologsapi';
    if (!file_exists($errLogDir)) mkdir($errLogDir, 0777, true);
    $errLogFile = $errLogDir . '/mp_error_' . date('Y-m-d_H-i-s') . '_' . uniqid() . '.json';
    $errLog = [
        'timestamp' => date('c'),
        'type' => 'MPApiException',
        'status_code' => $statusCode,
        'mp_content' => $content,
        'sent_payload' => $paymentData,
        'raw_request' => $data
    ];
    file_put_contents($errLogFile, json_encode($errLog, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

    header('Content-Type: application/json');
    echo json_encode([
        'error' => 'Erro ao processar o pagamento',
        'status_code' => $statusCode,
        'content' => $content,
        'sent_payload' => $paymentData
    ]);
    http_response_code(500);
} catch (\Exception $e) {
    // Erro genérico
    header('Content-Type: application/json');
    echo json_encode(['error' => $e->getMessage()]);
    http_response_code(500);
}
?>