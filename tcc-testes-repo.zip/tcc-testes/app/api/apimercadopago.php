<?php

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');
 
// Lidar com preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Definir fuso hor�rio de Bras�lia
date_default_timezone_set('America/Sao_Paulo');

// Receber dados do frontend
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Depura��o: Verificar o JSON recebido e decodificado
if ($data === null) {
    echo json_encode(array('error' => 'Invalid JSON', 'input' => htmlspecialchars($input)));
    exit;
}

// Obter accountCookie (par�metro principal)
$accountCookie = isset($data['accountCookie']) ? $data['accountCookie'] : null;

// Validar se accountCookie foi enviado
if ($accountCookie === null) {
    echo json_encode(array('error' => 'Missing accountCookie parameter', 'received_data' => $data));
    exit;
}

// ============================
// BUSCAR DADOS DO FIREBASE
// ============================
$firebaseBaseUrl = rtrim(getenv('FIREBASE_URL'), '/'); // TESTE: banco de teste

// Fun��o auxiliar para fazer requisi��es ao Firebase
function fetchFirebase($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200) {
        return null;
    }
    
    return json_decode($response, true);
}

// 1. Buscar dados do cookie
$cookieUrl = "{$firebaseBaseUrl}/cookies/{$accountCookie}.json";
$cookieData = fetchFirebase($cookieUrl);

if (!$cookieData) {
    echo json_encode(array('error' => 'Cookie n�o encontrado no Firebase', 'accountCookie' => $accountCookie));
    exit;
}

// 2. Extrair dados do cookie
$eventId = isset($cookieData['eventid']) ? $cookieData['eventid'] : null;
$valorTotal = isset($cookieData['valortotal']) ? floatval($cookieData['valortotal']) : null;
$valorTotalAdicional = isset($cookieData['valortotaladicional']) ? floatval($cookieData['valortotaladicional']) : null;
$userCpf = isset($cookieData['user']) ? $cookieData['user'] : null;

if (!$eventId || $valorTotal === null || !$userCpf) {
    echo json_encode(array(
        'error' => 'Dados incompletos no cookie',
        'eventid' => $eventId,
        'valortotal' => $valorTotal,
        'user_cpf' => $userCpf
    ));
    exit;
}

// Protecao de Reembolso: se o carrinho tiver comprasegura ativo, cobra o valor com o seguro incluso em vez do valortotal normal
$compraSegura = isset($cookieData['comprasegura']) && $cookieData['comprasegura'] === true;
$valorCompraSeguro = isset($cookieData['valorcompraseguro']) ? floatval($cookieData['valorcompraseguro']) : null;
$valorCompraSeguroPix = isset($cookieData['valorcompraseguropix']) ? floatval($cookieData['valorcompraseguropix']) : null;
$usouValorAdicional = false;
$semTaxaPix = isset($cookieData['semtaxapix']) && $cookieData['semtaxapix'] === true;

// Taxa personalizada no Pix: pode ser diferente/menor do que a taxa do cartao
$taxaPersonalizada = isset($cookieData['taxapersonalizada']) ? floatval($cookieData['taxapersonalizada']) : null;
$taxaPersonalizadaPix = isset($cookieData['taxapersonalizadapix']) ? floatval($cookieData['taxapersonalizadapix']) : null;
$valorTaxaPersonalizadaPix = isset($cookieData['valortaxapersonalizadapix']) ? floatval($cookieData['valortaxapersonalizadapix']) : null;

if ($compraSegura && $valorCompraSeguroPix !== null) {
    // Carrinho com valor de seguro especifico pro Pix (ja considera a taxa personalizada do Pix)
    $valorTotal = $valorCompraSeguroPix;
} elseif ($compraSegura && $valorCompraSeguro !== null) {
    $valorTotal = $valorCompraSeguro;
} else {
    // Se o valor total for 0 (ex: cupom 100%), cobrar o valor adicional (taxa/servico)
    $usouValorAdicional = ($valorTotal == 0.0 && $valorTotalAdicional !== null);
    if ($usouValorAdicional) {
        $valorTotal = $valorTotalAdicional;
    } elseif ($valorTaxaPersonalizadaPix !== null) {
        // Valor do Pix ja calculado pelo carrinho com a taxa personalizada do Pix
        $valorTotal = $valorTaxaPersonalizadaPix;
    } elseif ($taxaPersonalizadaPix !== null && $taxaPersonalizadaPix > 0 && $taxaPersonalizada !== null && $taxaPersonalizada > 0) {
        // Deriva o valor base (sem taxa) a partir da taxa personalizada do cartao, e aplica a taxa do Pix
        $valorBase = $valorTotal / (1 + ($taxaPersonalizada / 100));
        $valorTotal = $valorBase * (1 + ($taxaPersonalizadaPix / 100));
    } elseif ($semTaxaPix && !$usouValorAdicional && $valorTotal !== null) {
        // Sem taxa no Pix: tira os 10% de taxa de servico padrao do valor antes de cobrar
        $valorTotal = $valorTotal / 1.10;
    }
}

// 3. Buscar email do usu�rio
$userEmailUrl = "{$firebaseBaseUrl}/users/cpf/{$userCpf}/email.json";
$emailAccount = fetchFirebase($userEmailUrl);

if (!$emailAccount || !is_string($emailAccount)) {
    echo json_encode(array('error' => 'Email do usu�rio n�o encontrado', 'user_cpf' => $userCpf));
    exit;
}

// 4. Buscar nome do evento
$eventUrl = "{$firebaseBaseUrl}/eventos/{$eventId}.json";
$eventData = fetchFirebase($eventUrl);
$eventName = isset($eventData['name']) ? $eventData['name'] : "Evento #{$eventId}";

// Validar e processar valor total
$total = $valorTotal;

// Garantir que o total seja num�rico e converter para formato adequado
if (!is_numeric($total) || $total <= 0) {
    echo json_encode(array('error' => 'Invalid total value', 'total_received' => $total));
    exit;
}

// Converter valor para centavos
$valorformatado = round(floatval($total) * 100);
$valorOriginal  = $valorformatado / 100;

// Gerar c�digo �nico local
// antes $random_number = rand(30000, 900000);
$random_number = rand(910000, 20000000);

// URL da API do Mercado Pago
$url = getenv('MOCK_URL') . '/v1/payments'; // TESTE: Mercado Pago simulado

// Criar os dados da requisi��o
$requestData = array(
    "transaction_amount" => $valorOriginal,
    "description"         => $eventName . " - Carrinho " . $accountCookie,
    "payment_method_id"   => "pix",
    "payer"               => array("email" => $emailAccount)
);

// Gerar chave de idempot�ncia
$idempotency_key = "unique-key-value-" . $random_number;

// Iniciar cURL
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    "Authorization: Bearer TESTE-token-removido",
    "Content-Type: application/json",
    "X-Idempotency-Key: $idempotency_key"
));

// Executar a requisi��o
$response = curl_exec($ch);

// Preparar resposta
$response_data = [];
if (curl_errno($ch)) {
    $response_data['error'] = curl_error($ch);
} else {
    $response_data = json_decode($response, true);
    $response_data['local_transaction_code'] = $random_number;
    $response_data['email'] = $emailAccount;
    $response_data['event_name'] = $eventName;

    if (isset($response_data['point_of_interaction']['transaction_data']['ticket_url'])) {
        preg_match('/\/payments\/(\d+)\//', $response_data['point_of_interaction']['transaction_data']['ticket_url'], $matches);
        $response_data['ticket_id'] = $matches[1] ?? null;
    }

    if (isset($response_data['point_of_interaction']['transaction_data']['qr_code'])) {
        $response_data['qr_code'] = $response_data['point_of_interaction']['transaction_data']['qr_code'];
    }

    $response_data['valorOriginal'] = $valorOriginal;
}

// Fechar cURL
curl_close($ch);

// ============================
// ATUALIZAR FIREBASE (SEGURAN�A INTEGRADA)
// ============================
$firebaseUpdateSuccess = true;
$firebaseErrors = [];

if (isset($response_data['ticket_id']) && !isset($response_data['error'])) {
    $paymentId = $response_data['ticket_id'];
    
    // Atualizar Cookie
    $cookieUpdateData = [
        'urlmp' => $paymentId,
        'qrcodesucess' => true,
        'methodpaymenturl' => 'PIX'
    ];
    
    $cookieUrl = "{$firebaseBaseUrl}/cookies/{$accountCookie}.json";
    $ch1 = curl_init($cookieUrl);
    curl_setopt($ch1, CURLOPT_CUSTOMREQUEST, "PATCH");
    curl_setopt($ch1, CURLOPT_POSTFIELDS, json_encode($cookieUpdateData));
    curl_setopt($ch1, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch1, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
    curl_setopt($ch1, CURLOPT_TIMEOUT, 10);
    $cookieResult = curl_exec($ch1);
    
    if (curl_errno($ch1)) {
        $firebaseUpdateSuccess = false;
        $firebaseErrors[] = "Erro ao atualizar cookie: " . curl_error($ch1);
    }
    curl_close($ch1);
    
    // Atualizar PontesMP
    $ponteMpUpdateData = [
        'idpagamento' => $paymentId,
        'usercpf' => $userCpf,
        'codcarrinho' => $accountCookie,
        'eventId' => $eventId,
        'paymentStatus' => 'pending'
    ];
    
    $ponteMpUrl = "{$firebaseBaseUrl}/pontesmp/{$paymentId}.json";
    $ch2 = curl_init($ponteMpUrl);
    curl_setopt($ch2, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch2, CURLOPT_POSTFIELDS, json_encode($ponteMpUpdateData));
    curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch2, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);
    curl_setopt($ch2, CURLOPT_TIMEOUT, 10);
    $ponteMpResult = curl_exec($ch2);
    
    if (curl_errno($ch2)) {
        $firebaseUpdateSuccess = false;
        $firebaseErrors[] = "Erro ao atualizar pontesmp: " . curl_error($ch2);
    }
    curl_close($ch2);
    
    // Adicionar status do Firebase na resposta
    $response_data['firebase_updated'] = $firebaseUpdateSuccess;
    if (!$firebaseUpdateSuccess) {
        $response_data['firebase_errors'] = $firebaseErrors;
    }
}

// ============================
// SALVAR LOG (ENTRADA + SA�DA)
// ============================
$logDir = __DIR__ . '/registrologsapi';
if (!file_exists($logDir)) {
    mkdir($logDir, 0777, true);
}

// Criar nome do arquivo baseado em data e transa��o
$logFileName = 'log_' . date('Y-m-d_H-i-s') . '_transacao_' . $random_number . '.json';
$logFilePath = $logDir . '/' . $logFileName;

// Criar estrutura do log para f�cil leitura
$logContent = [
    '&#128338; DataHora'      => date('Y-m-d H:i:s'),
    '&#129534; TransacaoLocal' => $random_number,
    '&#128229; RequisicaoRecebida' => [
        'accountCookie'  => $accountCookie,
        'raw_payload'    => $data
    ],
    '&#128269; DadosBuscadosFirebase' => [
        'eventId'        => $eventId,
        'eventName'      => $eventName,
        'userCpf'        => $userCpf,
        'email'          => $emailAccount,
        'sem_taxa_pix'   => $semTaxaPix ?? false,
        'taxa_personalizada_pix' => $taxaPersonalizadaPix ?? null,
        'compra_segura'  => $compraSegura ?? false,
        'valor_total'    => 'R$ ' . number_format($valorOriginal, 2, ',', '.'),
        'cookie_data'    => $cookieData
    ],
    '&#128228; EnviadoParaMercadoPago' => $requestData,
    '&#128236; RespostaRecebidaDaAPI' => $response_data,
    '&#128293; FirebaseAtualizado' => $firebaseUpdateSuccess,
    '&#9888;&#65039; ErrosFirebase' => $firebaseErrors
];

// Salvar log formatado
file_put_contents($logFilePath, json_encode($logContent, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

// ============================
// Retornar resposta final ao frontend
// ============================
header('Content-Type: application/json');
echo json_encode($response_data);
?>
