// Cenario de abertura de vendas com comportamento proximo do real.
//
// Tres tipos de usuario rodam ao mesmo tempo:
//   1. "navegacao": visitantes que so abrem a pagina do evento e vao embora.
//   2. "jornada":   compradores com a jornada completa: abrem a pagina, pensam,
//                   preparam o checkout, abrem a tela de checkout e pagam: 80% com PIX (gerado,
//                   pago depois de alguns segundos) e 20% com cartao (aprovado na hora). Depois,
//                   70% entram na area do usuario (login + ingressos).
//   3. "abertura":  uma rajada de compradores que entram quase juntos no momento
//                   em que as vendas abrem (fila de pessoas esperando o link).
// Como cada jornada leva de 20 s a 1 min, em qualquer instante ha paginas sendo
// abertas enquanto outros clientes preparam checkout e webhooks estao sendo processados.
import http from 'k6/http';
import { check, sleep } from 'k6';
import { Trend, Counter, Rate } from 'k6/metrics';

const BASE = __ENV.BASE_URL || 'http://nginx';
const FIREBASE = (__ENV.FIREBASE_URL || '').replace(/\/+$/, '');
const EVENTO = __ENV.EVENTO_ID || '1001';
const MULT = Number(__ENV.MULT || 1);

// Calibracao (multiplicador 1): pico real de producao = 26 notificacoes por minuto.
const COMPRAS_MIN = 30 * MULT;              // compradores por minuto no pico
const VISITAS_POR_COMPRA = Number(__ENV.VISITAS_POR_COMPRA || 10);
const SO_OLHAM_MIN = COMPRAS_MIN * (VISITAS_POR_COMPRA - 1); // visitantes que nao compram
const RAJADA = Math.max(1, Math.round(60 * MULT));            // pessoas na abertura (em 20 s)
const BASAL = 0.1;
const N_USUARIOS = Number(__ENV.N_USUARIOS || 2000);
const FRACAO_CARTAO = Number(__ENV.FRACAO_CARTAO || 0.2);  // producao: 17% das notificacoes eram de cartao
const FRACAO_AREA = Number(__ENV.FRACAO_AREA || 0.7);      // compradores que entram na area do usuario depois (suposicao)
const SENHA_TESTE = 'senha123';
// Testes complementares (desligados no teste principal):
//   DUPLICAR=1      -> cada notificacao de aprovacao e enviada duas vezes ao mesmo tempo (o provedor pode repetir).
//   MODO_ESTOQUE=1  -> todos os compradores querem Camarote, que tem estoque limitado; quem ve "ESGOTADO" na
//                      pagina compra Pista. Mede se o sistema vende mais do que o estoque.
const DUPLICAR = __ENV.DUPLICAR === '1';
const MODO_ESTOQUE = __ENV.MODO_ESTOQUE === '1';
const MOCK = __ENV.MOCK_URL || 'http://mocks:4000';                             // senha de todos os usuarios de teste (seed.js)

const fases = (porMin) => {
  const base = Math.max(1, Math.ceil(porMin * BASAL));
  return [
    { target: base, duration: '1m' },                 // antes da abertura
    { target: Math.ceil(porMin), duration: '30s' },   // abertura
    { target: Math.ceil(porMin), duration: '3m' },    // pico
    { target: base, duration: '30s' },                // queda
    { target: base, duration: '30s' },                // recuperacao
  ];
};

export const options = {
  scenarios: {
    navegacao: {
      executor: 'ramping-arrival-rate', exec: 'navegacao', timeUnit: '1m',
      startRate: Math.max(1, Math.ceil(SO_OLHAM_MIN * BASAL)), stages: fases(SO_OLHAM_MIN),
      preAllocatedVUs: 50, maxVUs: 3000,
    },
    jornada: {
      executor: 'ramping-arrival-rate', exec: 'jornada', timeUnit: '1m',
      startRate: Math.max(1, Math.ceil(COMPRAS_MIN * BASAL)), stages: fases(COMPRAS_MIN),
      preAllocatedVUs: 50, maxVUs: 3000, gracefulStop: '3m',
    },
    abertura: {
      executor: 'constant-arrival-rate', exec: 'jornadaApressada', startTime: '1m',
      duration: '20s', rate: RAJADA, timeUnit: '20s',
      preAllocatedVUs: Math.min(RAJADA, 500), maxVUs: 3000, gracefulStop: '3m',
    },
    monitor: {
      executor: 'constant-arrival-rate', exec: 'monitor', rate: 1, timeUnit: '5s',
      duration: '7m', preAllocatedVUs: 2, maxVUs: 5,
    },
  },
  summaryTrendStats: ['min', 'med', 'avg', 'p(95)', 'p(99)', 'max'],
  thresholds: {   // so para aparecerem separados no resumo
    'http_req_duration{rotina:pagina}': ['max>=0'],
    'http_req_duration{rotina:checkout}': ['max>=0'],
    'http_req_duration{rotina:tela_checkout}': ['max>=0'],
    'http_req_duration{rotina:webhook}': ['max>=0'],
    'http_req_duration{rotina:pagamento_cartao}': ['max>=0'],
    'http_req_duration{rotina:area_usuario}': ['max>=0'],
    'http_req_duration{rotina:login}': ['max>=0'],
    'http_req_duration{rotina:login_tela}': ['max>=0'],
    'http_req_duration{rotina:gerar_pix}': ['max>=0'],
    'http_req_failed{rotina:pagina}': ['rate>=0'],
    'http_req_failed{rotina:checkout}': ['rate>=0'],
    'http_req_failed{rotina:tela_checkout}': ['rate>=0'],
    'http_req_failed{rotina:webhook}': ['rate>=0'],
    'http_req_failed{rotina:pagamento_cartao}': ['rate>=0'],
    'http_req_failed{rotina:area_usuario}': ['rate>=0'],
    'http_req_failed{rotina:login}': ['rate>=0'],
    'http_req_failed{rotina:login_tela}': ['rate>=0'],
    'http_req_failed{rotina:gerar_pix}': ['rate>=0'],
  },
};

const fpmAtivos = new Trend('fpm_workers_ativos');
const fpmFila = new Trend('fpm_fila_espera');
const jornadaTempo = new Trend('jornada_tempo_ate_webhook', true);
const comprasOk = new Counter('compras_concluidas');
const comprasFalhas = new Counter('compras_com_falha');
const loginsOk = new Rate('logins_com_sucesso');
const JSONH = { 'Content-Type': 'application/json' };
// Estagios E3/E4: preparacao do checkout e webhooks vao para os servicos Node.js (servidores separados).
// Sem essas variaveis, tudo vai para o PHP (estagios E1 e E2).
const CHECKOUT_URL = __ENV.CHECKOUT_URL || `${BASE}/api/prepararCheckout.php`;
const WEBHOOK_NODE = __ENV.WEBHOOK_NODE || '';

// Ingressos por compra, na proporcao observada em producao (1: 63%, 2: 25%, 3: 7%, 4: 1%, 5: 4%).
function ingressos() {
  const r = Math.random();
  if (r < 0.63) return 1;
  if (r < 0.88) return 2;
  if (r < 0.95) return 3;
  if (r < 0.96) return 4;
  return 5;
}
const entre = (a, b) => a + Math.random() * (b - a);

function abrirPagina() {
  const r = http.get(`${BASE}/comprar/${EVENTO}/`, { tags: { rotina: 'pagina' }, timeout: '60s' });
  return check(r, { 'pagina 200': (x) => x.status === 200 && String(x.body).includes('Evento de Teste') }) ? r : null;
}

export function navegacao() {
  abrirPagina();
}

function comprar(pensaMin, pensaMax) {
  const inicio = Date.now();
  const pagina = abrirPagina();
  if (!pagina) { comprasFalhas.add(1); return; }
  sleep(entre(pensaMin, pensaMax));                       // escolhe o ingresso

  const n = ingressos();
  // comprador entre os usuarios cadastrados nos dados de teste (como um cliente real, que ja tem conta)
  const cpf = String(10000000000 + Math.floor(Math.random() * N_USUARIOS));
  // No modo estoque, o comprador quer Camarote, a menos que a pagina que ele viu o mostre esgotado.
  const camaroteEsgotado = /data-nometipo="Camarote"[^>]*data-esgotado="true"/.test(String(pagina.body));
  const tipo = MODO_ESTOQUE && !camaroteEsgotado ? 'Camarote' : 'Pista';
  const preco = tipo === 'Camarote' ? 110 : 55;
  const corpo = JSON.stringify({ cpf, eventid: EVENTO, total: preco * n, unt: n,
    tipos: { [tipo]: { nometipo: tipo, valorbruto: preco, unt: n } } });
  const ck = http.post(CHECKOUT_URL, corpo,
    { headers: JSONH, tags: { rotina: 'checkout' }, timeout: '60s' });
  let cookie = null;
  try { cookie = ck.json('cookie'); } catch (e) { cookie = null; }
  if (!check(ck, { 'checkout ok': (x) => x.status === 200 && !!cookie })) { comprasFalhas.add(1); return; }

  // o site redireciona para a tela de checkout 1,5 s depois (script.js da pagina do evento)
  sleep(1.5);
  const tela = http.get(`${BASE}/checkout/?event_id=${EVENTO}&event_name=Evento%20de%20Teste&total=${(preco * n).toFixed(2)}&account_cookie=${cookie}`,
    { tags: { rotina: 'tela_checkout' }, timeout: '60s' });
  if (!check(tela, { 'tela checkout 200': (x) => x.status === 200 && String(x.body).includes('Forma de Pagamento') })) {
    comprasFalhas.add(1); return;
  }
  sleep(entre(5, 15));                                   // escolhe a forma de pagamento

  const pago = Math.random() < FRACAO_CARTAO ? pagarCartao(cookie) : pagarPix(cookie);
  if (!pago) { comprasFalhas.add(1); return; }
  comprasOk.add(1);
  jornadaTempo.add(Date.now() - inicio);

  // Depois de comprar, a maioria entra na area do usuario para ver o ingresso.
  if (Math.random() < FRACAO_AREA) {
    sleep(entre(5, 30));
    areaDoUsuario(cpf);
  }
}

// Cartao: a pagina chama pagamentocardmp.php, que cria o pagamento no Mercado Pago (simulado, ja aprovado)
// e grava o registro do pagamento no banco.
function pagarCartao(cookie) {
  sleep(entre(15, 40));                                  // digita os dados do cartao
  const pg = http.post(`${BASE}/api/pagamentocardmp/pagamentocardmp.php`, JSON.stringify({
    external_reference: cookie, token: 'tok_teste', installments: 1, payment_method_id: 'visa', issuer_id: '1',
  }), { headers: JSONH, tags: { rotina: 'pagamento_cartao' }, timeout: '60s' });
  let pid = null;
  try { pid = pg.json('payment_response.id'); } catch (e) { pid = null; }
  if (!check(pg, { 'pagamento cartao ok': (x) => x.status === 200 && !!pid })) return false;
  sleep(entre(1, 3));                                    // o Mercado Pago notifica a criacao, ja aprovada
  const criado = DUPLICAR ? enviarWebhookDuplo('payment.created', pid, 'cartao') : enviarWebhook('payment.created', pid, 'cartao');
  sleep(entre(2, 5));                                    // e em seguida a atualizacao
  enviarWebhook('payment.updated', pid, 'cartao');
  return criado;
}

// PIX: a pagina chama apimercadopago.php, que cria o PIX no Mercado Pago (simulado, pendente) e grava
// o registro do pagamento no banco. O cliente paga no banco dele alguns segundos depois.
function pagarPix(cookie) {
  const g = http.post(`${BASE}/api/apimercadopago.php`, JSON.stringify({ accountCookie: cookie }),
    { headers: JSONH, tags: { rotina: 'gerar_pix' }, timeout: '60s' });
  let pid = null;
  try { pid = g.json('ticket_id'); } catch (e) { pid = null; }
  if (!check(g, { 'pix gerado': (x) => x.status === 200 && !!pid })) return false;
  sleep(entre(1, 3));
  enviarWebhook('payment.created', pid, 'pix');          // notificacao do PIX gerado (status pendente)
  sleep(entre(10, 40));                                  // cliente paga o PIX no app do banco
  http.post(`${MOCK}/__pagar/${pid}`, null, { tags: { rotina: 'preparo_teste' } });
  if (DUPLICAR) return enviarWebhookDuplo('payment.updated', pid, 'pix');
  return enviarWebhook('payment.updated', pid, 'pix');   // notificacao do pagamento aprovado
}

// Area do usuario: abre a tela de login, entra com CPF e senha (a pagina chama validacao.php no proprio
// servidor) e, ja logado, abre a area de novo para ver os ingressos. O k6 guarda o cookie de sessao.
function areaDoUsuario(cpf) {
  const tela = http.get(`${BASE}/login/`, { tags: { rotina: 'login_tela' }, timeout: '60s' });
  check(tela, { 'tela login 200': (x) => x.status === 200 });
  sleep(entre(5, 15));                                   // digita CPF e senha
  const r = http.post(`${BASE}/login/`, { cpf_email: cpf, password: SENHA_TESTE, login: '1' },
    { tags: { rotina: 'login' }, timeout: '60s' });
  const entrou = check(r, { 'login ok': (x) => x.status === 200 && String(x.body).includes('Login bem-sucedido') });
  loginsOk.add(entrou ? 1 : 0);
  if (!entrou) return;
  sleep(entre(10, 40));                                  // olha os ingressos e atualiza a pagina
  const area = http.get(`${BASE}/login/`, { tags: { rotina: 'area_usuario' }, timeout: '60s' });
  check(area, { 'area do usuario 200': (x) => x.status === 200 });
}

// Teste de duplicidade: a mesma notificacao de aprovacao chega duas vezes ao mesmo tempo.
function enviarWebhookDuplo(acao, pid, metodo) {
  const url = WEBHOOK_NODE ? `${WEBHOOK_NODE}/webhook/${metodo}` : `${BASE}/webhook.php`;
  const corpo = JSON.stringify({ action: acao, type: 'payment', api_version: 'v1', data: { id: String(pid) } });
  const p = { headers: JSONH, tags: { rotina: 'webhook' }, timeout: '60s' };
  const rs = http.batch([['POST', url, corpo, p], ['POST', url, corpo, p]]);
  return check(rs[0], { 'webhook 200': (x) => x.status === 200 });
}

function enviarWebhook(acao, pid, metodo) {
  const url = WEBHOOK_NODE ? `${WEBHOOK_NODE}/webhook/${metodo}` : `${BASE}/webhook.php`;
  const r = http.post(url, JSON.stringify({ action: acao, type: 'payment', api_version: 'v1',
    data: { id: String(pid) } }), { headers: JSONH, tags: { rotina: 'webhook' }, timeout: '60s' });
  return check(r, { 'webhook 200': (x) => x.status === 200 });
}

export function jornada() { comprar(5, 20); }
export function jornadaApressada() { comprar(2, 8); }  // quem estava esperando a abertura decide rapido

export function monitor() {
  const r = http.get(`${BASE}/fpm-status?json`, { tags: { rotina: 'monitor' }, timeout: '4s' });
  if (r.status !== 200) return;
  try {
    const s = r.json();
    fpmAtivos.add(s['active processes']);
    fpmFila.add(s['listen queue']);
  } catch (e) { /* sem PHP-FPM */ }
}
