// Carrega dados FICTICIOS no Firebase de teste. Nunca apontar para o banco de producao.
// Uso: node seed.js   (variaveis: FIREBASE_URL, N_USUARIOS, N_VENDAS)
const BASE = (process.env.FIREBASE_URL || '').replace(/\/+$/, '');
const N_USUARIOS = Number(process.env.N_USUARIOS || 2000);
const N_VENDAS = Number(process.env.N_VENDAS || 300);   // registro da empresa com tamanho parecido com o de producao (10 a 73 kB)
const EVENTO = process.env.EVENTO_ID || '1001';
const EMPRESA = process.env.EMPRESA_ID || '9001';
if (!BASE) { console.error('Defina FIREBASE_URL'); process.exit(1); }
if (/piauidbtickets|piauiticketsdb/.test(BASE)) { console.error('Esse e o banco de PRODUCAO. Abortado.'); process.exit(1); }

async function enviar(metodo, caminho, dados) {
  const r = await fetch(`${BASE}/${caminho}.json`, { method: metodo, body: JSON.stringify(dados),
    headers: { 'Content-Type': 'application/json' } });
  if (!r.ok) throw new Error(`${metodo} ${caminho}: HTTP ${r.status} ${await r.text()}`);
}
const letras = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const codigo = (i) => Array.from({ length: 7 }, (_, k) => letras[(i * 7 + k * 11 + (i >> k)) % 26]).join('') + String(i % 1000).padStart(3, '0');
const crypto = require('crypto');
const EVENTOS_ANTIGOS = 5;
const SENHA_TESTE = 'senha123';
const CHAVE_SENHA = process.env.CHAVE_SENHA || 'chave-de-teste-tcc';
// Mesmo formato do site: base64( IV + base64(AES-256-CBC) ), chave completada com zeros como no PHP.
function senhaCriptografada(senha) {
  const chave = Buffer.alloc(32); Buffer.from(CHAVE_SENHA).copy(chave);
  const iv = crypto.randomBytes(16);
  const c = crypto.createCipheriv('aes-256-cbc', chave, iv);
  const interno = Buffer.concat([c.update(senha, 'utf8'), c.final()]).toString('base64');
  return Buffer.concat([iv, Buffer.from(interno)]).toString('base64');
}
const cpf = (i) => String(10000000000 + i);

(async () => {
  console.log(`Banco de teste: ${BASE}`);
  for (const no of ['cookies', 'cookiesfixo', 'pontesmp', 'ingressos', 'users', 'empresas', 'eventos']) await enviar('PUT', no, null);

  await enviar('PUT', `eventos/${EVENTO}`, {
    nomeevento: 'Evento de Teste', datainicio: '2026-12-31', aberturaportas: '22:00', local: 'Local de Teste',
    imageurl: '', nameloteevent: 'Lote 1', empresavinculada: EMPRESA, 'informaçõesadicionais': 'Evento ficticio para teste de carga.',
    tipos: [
      { nometipo: 'Pista', valorbruto: 55, idselection: 1 },
      { nometipo: 'Camarote', valorbruto: 110, idselection: 2 },
    ],
  });

  // Eventos antigos, para que parte dos usuarios ja tenha ingressos de outras compras (a area do usuario
  // le o evento e o ingresso de cada um).
  for (let e = 0; e < EVENTOS_ANTIGOS; e++) {
    await enviar('PUT', `eventos/${900 + e}`, { nomeevento: `Evento Antigo ${e}`, datainicio: '2026-01-01', local: 'Local de Teste',
      empresavinculada: EMPRESA, tipos: [{ nometipo: 'Pista', valorbruto: 40, idselection: 1 }] });
  }
  const senha = senhaCriptografada(SENHA_TESTE);
  const usuarios = {};
  for (let i = 0; i < N_USUARIOS; i++) {
    const c = cpf(i);
    usuarios[c] = { cpf: c, fullname: `Usuario Teste ${i}`, email: `usuario${i}@teste.invalid`, telefone: '00000000000',
      password: senha, ingressoscomprados: {} };
    // ingressos antigos: 50% nenhum, 30% 1-2, 15% 3-6, 5% 7-15 (suposicao; ajuste se tiver o dado real)
    const sorte = (i * 7919) % 100;
    const n = sorte < 50 ? 0 : sorte < 80 ? 1 + (i % 2) : sorte < 95 ? 3 + (i % 4) : 7 + (i % 9);
    for (let k = 0; k < n; k++) {
      const t = `antigo${i}x${k}`;
      usuarios[c].ingressoscomprados[t] = { eventid: String(900 + ((i + k) % EVENTOS_ANTIGOS)), compradorcpf: c, unt: 1,
        valortotal: 40, methodpayment: 'PIX', tipo: 'Pista', token: t };
    }
  }
  const vendas = {};
  for (let i = 0; i < N_VENDAS; i++) {
    const t = codigo(i) + i, c = cpf(i % N_USUARIOS);
    vendas[t] = { compradorcpf: c, datebuy: '2026-11-01', horariocompra: '12:00:00', codcarrinho: `seed${i}`, unt: 1,
      valortotal: 55, methodpayment: 'PIX', tipo: 'Pista' };
    usuarios[c].ingressoscomprados[t] = { eventid: EVENTO, compradorcpf: c, unt: 1, valortotal: 55, methodpayment: 'PIX', tipo: 'Pista', token: t };
  }
  await enviar('PUT', 'users/cpf', usuarios);
  await enviar('PUT', `empresas/${EMPRESA}`, { nome: 'Empresa de Teste', saldo_disponivel: 0,
    vendas: { vendasrealizadas: { [EVENTO]: vendas } } });
  console.log(`OK: evento ${EVENTO}, ${N_USUARIOS} usuarios, ${N_VENDAS} vendas.`);
})().catch((e) => { console.error(e.message); process.exit(1); });
