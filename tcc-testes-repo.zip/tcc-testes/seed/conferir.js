// Conferencia apos cada execucao: pagamentos pagos x ingressos emitidos, e ingressos vendidos x estoque.
// Le o Mercado Pago simulado (quais pagamentos o cliente pagou) e o banco de teste (registros e ingressos).
// Uso: node conferir.js  (variaveis FIREBASE_URL, MOCK_URL, EVENTO, LIMITE_CAMAROTE, SAIDA)
const fs = require('fs');
const BASE = (process.env.FIREBASE_URL || '').replace(/\/$/, '');
const MOCK = (process.env.MOCK_URL || 'http://mocks:4000').replace(/\/$/, '');
const EVENTO = process.env.EVENTO || '1001';
const LIMITE_CAMAROTE = Number(process.env.LIMITE_CAMAROTE || 0);
if (!BASE || /piauidbtickets|piauiticketsdb/.test(BASE)) { console.error('FIREBASE_URL invalida'); process.exit(1); }

const ler = async (url) => { const r = await fetch(url); return (await r.json()) || {}; };

(async () => {
  const pagos = await ler(`${MOCK}/__pagos`);                               // [{id, metodo}]
  const pontes = await ler(`${BASE}/pontesmp.json`);
  const carrinhos = await ler(`${BASE}/cookiesfixo.json`);
  const ingressos = await ler(`${BASE}/ingressos/${EVENTO}/disponiveis.json`);

  const esperado = {};                                 // cpf -> ingressos esperados (soma das compras pagas)
  let semRegistro = 0, ingressosEsperados = 0;
  for (const { id } of pagos) {
    const p = pontes[id];
    if (!p || !p.codcarrinho) { semRegistro++; continue; }
    const c = carrinhos[p.codcarrinho] || {};
    const n = Number(c.unt || c.quantidade || 0);
    const cpf = String(p.usercpf || c.user || '');
    esperado[cpf] = (esperado[cpf] || 0) + n;
    ingressosEsperados += n;
  }
  const emitido = {}; const porTipo = {};
  for (const t of Object.values(ingressos)) {
    if (!t) continue;
    const cpf = String(t.compradorcpf || '');
    emitido[cpf] = (emitido[cpf] || 0) + 1;
    porTipo[t.tipo || '?'] = (porTipo[t.tipo || '?'] || 0) + 1;
  }
  let faltando = 0, excedentes = 0, compradoresSemIngresso = 0, compradoresComFalta = 0, ingressoSemPagamento = 0;
  for (const cpf of new Set([...Object.keys(esperado), ...Object.keys(emitido)])) {
    const e = esperado[cpf] || 0, a = emitido[cpf] || 0;
    if (e > a) { faltando += e - a; compradoresComFalta++; if (a === 0) compradoresSemIngresso++; }
    if (a > e) { excedentes += a - e; if (e === 0) ingressoSemPagamento += a; }
  }
  const resultado = {
    pagamentos_pagos: pagos.length,
    pagos_cartao: pagos.filter((x) => x.metodo === 'cartao').length,
    pagos_pix: pagos.filter((x) => x.metodo === 'pix').length,
    pagos_sem_registro_no_banco: semRegistro,
    registros_marcados_aprovados: Object.values(pontes).filter((p) => p && p.statuspayment === 'aprovada').length,
    ingressos_esperados: ingressosEsperados,
    ingressos_emitidos: Object.values(ingressos).filter(Boolean).length,
    ingressos_faltando: faltando,
    ingressos_a_mais: excedentes,
    ingressos_sem_pagamento: ingressoSemPagamento,
    compradores_com_falta: compradoresComFalta,
    compradores_pagaram_sem_nenhum_ingresso: compradoresSemIngresso,
    ingressos_por_tipo: porTipo,
    limite_camarote: LIMITE_CAMAROTE || null,
    camarote_acima_do_limite: LIMITE_CAMAROTE ? Math.max(0, (porTipo.Camarote || 0) - LIMITE_CAMAROTE) : null,
  };
  console.log('Conferencia:', JSON.stringify(resultado, null, 1));
  if (process.env.SAIDA) fs.writeFileSync(process.env.SAIDA, JSON.stringify(resultado, null, 1));
})().catch((e) => { console.error('Falha na conferencia:', e.message); process.exit(1); });
