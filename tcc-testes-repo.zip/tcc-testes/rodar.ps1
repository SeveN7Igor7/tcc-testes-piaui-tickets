# Executa um teste de carga em um estagio.
# Exemplo:  powershell -ExecutionPolicy Bypass -File rodar.ps1 -Estagio E1 -Mult 1 -Rep 1
param(
  [Parameter(Mandatory = $true)][ValidateSet('E1', 'E1-16', 'E1-32', 'E2-II', 'E2-III', 'E2-Cloud', 'E3', 'E4-fila', 'E4')][string]$Estagio,
  [string]$Mult = '1',   # multiplicador do pico real (use ponto: 0.5, 1, 2, 4)
  [int]$Rep = 1,         # numero da repeticao
  # normal = teste principal; duplicado = cada notificacao de aprovacao chega duas vezes ao mesmo tempo;
  # estoque = todos querem Camarote, com estoque de 100 ingressos controlado pela pagina (servico do organizador)
  [ValidateSet('normal', 'duplicado', 'estoque')][string]$Teste = 'normal'
)
Set-Location $PSScriptRoot

# Limites de cada plano. "filhos" e o numero de processos PHP.
# limite = memoria por processo, como a KingHost divide: memoria do plano / numero de processos.
# servidores = sobe os servicos Node.js (checkout e webhooks) como em producao a partir do E3.
# fila = '1' usa a fila BullMQ/Redis (E4); '0' processa o webhook direto, sem fila (E3).
$cfg = @{
  'E1'       = @{ cpus = '1'; mem = '256m'; filhos = '4';  limite = '64M';  servidores = $false }
  'E1-16'    = @{ cpus = '1'; mem = '256m'; filhos = '16'; limite = '16M';  servidores = $false }
  'E1-32'    = @{ cpus = '1'; mem = '256m'; filhos = '32'; limite = '8M';   servidores = $false }
  'E2-II'    = @{ cpus = '2'; mem = '512m'; filhos = '4';  limite = '128M'; servidores = $false }
  'E2-III'   = @{ cpus = '4'; mem = '1g';   filhos = '4';  limite = '256M'; servidores = $false }
  'E2-Cloud' = @{ cpus = '4'; mem = '4g';   filhos = '32'; limite = '128M'; servidores = $false }
  'E3'       = @{ cpus = '4'; mem = '4g';   filhos = '32'; limite = '128M'; servidores = $true; fila = '0'; cache = $false }
  'E4-fila'  = @{ cpus = '4'; mem = '4g';   filhos = '32'; limite = '128M'; servidores = $true; fila = '1'; cache = $false }
  'E4'       = @{ cpus = '4'; mem = '4g';   filhos = '32'; limite = '128M'; servidores = $true; fila = '1'; cache = $true }
}

if (-not (Test-Path .env)) { Write-Error 'Crie o arquivo .env a partir de .env.exemplo'; exit 1 }
$fb = ((Get-Content .env | Where-Object { $_ -match '^FIREBASE_URL=' }) -replace '^FIREBASE_URL=', '').Trim().TrimEnd('/')
if ($fb -match 'piauidbtickets|piauiticketsdb|SEU-PROJETO') { Write-Error 'FIREBASE_URL precisa ser o banco de TESTE.'; exit 1 }

$c = $cfg[$Estagio]
$env:PHP_CPUS = $c.cpus; $env:PHP_MEM = $c.mem; $env:PM_MAX_CHILDREN = $c.filhos; $env:PHP_MEM_LIMIT = $c.limite
$env:CHAMA_ORGANIZADOR = if ($Teste -eq 'estoque') { '1' } else { '0' }
$env:LIMITE_CAMAROTE = if ($Teste -eq 'estoque') { '100' } else { '' }
$env:USAR_FILA = if ($c.fila) { $c.fila } else { '1' }
$env:CACHE_URL = if ($c.cache) { 'http://cache-node:3020' } else { '' }
$sufixo = @{ normal = ''; duplicado = '-dup'; estoque = '-estoque' }[$Teste]
$nome = "{0}{1}_m{2}_r{3}" -f $Estagio, $sufixo, $Mult, $Rep

# Descricao do computador e das versoes (uma vez so), para a secao de metodo
if (-not (Test-Path resultados/ambiente.txt)) {
  New-Item -ItemType Directory -Force resultados | Out-Null
  $cpuInfo = Get-CimInstance Win32_Processor | Select-Object -First 1
  $amb = @(
    "Processador: $($cpuInfo.Name) ($($cpuInfo.NumberOfCores) nucleos, $($cpuInfo.NumberOfLogicalProcessors) threads)",
    ("Memoria: {0:N1} GB" -f ((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)),
    "Sistema: $((Get-CimInstance Win32_OperatingSystem).Caption) $((Get-CimInstance Win32_OperatingSystem).Version)",
    "Docker: $(docker version --format '{{.Server.Version}}')",
    "Docker (recursos da VM): $(docker info --format '{{.NCPU}} CPUs, {{.MemTotal}} bytes')",
    "k6: $(docker run --rm grafana/k6 version)",
    "PHP: $((docker run --rm php:8.2-fpm-alpine php -v) | Select-Object -First 1)",
    "Nginx: $(docker run --rm nginx:1.27-alpine nginx -v 2>&1)",
    "Node.js (servicos): $(docker run --rm node:18-alpine node -v)",
    "Node.js (simuladores): $(docker run --rm node:20-alpine node -v)",
    "Redis: $(docker run --rm redis:7-alpine redis-server -v)",
    "Observacao: o k6 roda na mesma maquina e no mesmo Docker que os conteineres testados."
  )
  $amb | Set-Content resultados/ambiente.txt
  Write-Host 'Descricao do ambiente salva em resultados\ambiente.txt'
}
New-Item -ItemType Directory -Force resultados, registros-node | Out-Null
$tempos = 'registros-node/tempos_webhook.jsonl'
Remove-Item $tempos -ErrorAction SilentlyContinue

$desc = "$($c.cpus) CPU, $($c.mem), $($c.filhos) processos PHP de $($c.limite)"
if ($c.servidores) { $desc += " + servicos Node (checkout e webhooks)" + $(if ($c.fila -eq '1') { ' com fila Redis' } else { ' sem fila' }) + $(if ($c.cache) { ' + cache Redis da pagina' } else { '' }) }
Write-Host "== $nome : $desc =="
Write-Host '1/3 Recarregando os dados de teste...'
docker run --rm -v "${PWD}/seed:/s" -e FIREBASE_URL=$fb node:20-alpine node /s/seed.js
if ($LASTEXITCODE -ne 0) { Write-Error 'Falha ao carregar os dados.'; exit 1 }

Write-Host '2/3 Subindo os conteineres...'
docker compose --profile servidores down --remove-orphans 2>$null | Out-Null
if ($c.servidores) {
  Write-Host '    (na primeira vez, monta as imagens dos servicos Node: alguns minutos)'
  docker compose --profile servidores up -d --build --force-recreate
} else {
  docker compose up -d --force-recreate
}
Start-Sleep -Seconds 8

$extra = @()
if ($c.servidores) {
  # Confere se os servicos Node subiram antes de gastar 9 minutos de teste
  $ok = $false
  for ($i = 0; $i -lt 30; $i++) {
    docker compose exec -T webhook-node wget -qO- http://localhost:3000/health 2>$null | Out-Null; $a = $LASTEXITCODE
    docker compose exec -T checkout-node wget -qO- http://localhost:3005/ 2>$null | Out-Null; $b = $LASTEXITCODE
    docker compose exec -T cache-node wget -qO- http://localhost:3020/health 2>$null | Out-Null; $d = $LASTEXITCODE
    if ($a -eq 0 -and $b -eq 0 -and $d -eq 0) { $ok = $true; break }
    Start-Sleep -Seconds 3
  }
  if (-not $ok) {
    Write-Host 'ERRO: os servicos Node nao responderam. Ultimas linhas do registro:' -ForegroundColor Red
    docker compose logs --no-color --tail 40 webhook-node checkout-node cache-node
    Write-Host 'Mande essas linhas para analise. Teste cancelado.' -ForegroundColor Red
    exit 1
  }
  Write-Host '    Servicos Node respondendo.'
  $extra = @('-e', 'CHECKOUT_URL=http://checkout-node:3005/prepararcheckout', '-e', 'WEBHOOK_NODE=http://webhook-node:3000')
}

# Amostra de CPU e memoria a cada 10 s, em segundo plano
$amostra = Start-Job { while ($true) {
    docker stats --no-stream --format '{{.Name}},{{.CPUPerc}},{{.MemUsage}}' | ForEach-Object { "$(Get-Date -Format s),$_" }
    Start-Sleep -Seconds 10 } }

Write-Host '3/3 Rodando o k6 (cerca de 9 min)...'
Write-Host '    Acompanhe ao vivo em http://localhost:5665 (abre sozinho em alguns segundos)'
$abrir = Start-Job { Start-Sleep -Seconds 10; Start-Process 'http://localhost:5665' }
# O teste dura no maximo 8min30s. Se o k6 nao sair sozinho (painel ao vivo aberto), encerra aos 9min30s;
# ao ser encerrado, o k6 grava o resumo e o relatorio normalmente.
docker rm -f k6-tcc 2>$null | Out-Null
$vigia = Start-Job { Start-Sleep -Seconds 570; docker stop k6-tcc | Out-Null }
docker run --rm --name k6-tcc --user root --network tcc-testes_default -p 5665:5665 -v "${PWD}/k6:/k6" -v "${PWD}/resultados:/res" `
  -e BASE_URL=http://nginx -e FIREBASE_URL=$fb -e MULT=$Mult -e MOCK_URL=http://mocks:4000 @extra `
  -e DUPLICAR=$(if ($Teste -eq 'duplicado') { '1' } else { '0' }) -e MODO_ESTOQUE=$(if ($Teste -eq 'estoque') { '1' } else { '0' }) `
  -e K6_WEB_DASHBOARD=true -e K6_WEB_DASHBOARD_EXPORT="/res/$nome.html" `
  grafana/k6 run --summary-export "/res/$nome.json" /k6/pico.js | Tee-Object -FilePath "resultados/$nome.txt"
Remove-Job $abrir -Force -ErrorAction SilentlyContinue
Remove-Job $vigia -Force -ErrorAction SilentlyContinue

if ($c.servidores) {
  # Webhooks podem continuar sendo processados depois que o k6 termina. Com fila, espera a fila do Redis
  # zerar (esperando + em processamento + reagendados); sem fila, espera o registro ficar 1 min sem novidade.
  # Limite: 45 minutos.
  Write-Host 'Aguardando o processamento dos webhooks pendentes...'
  $inicioEspera = Get-Date; $anterior = -1; $parado = 0
  while (((Get-Date) - $inicioEspera).TotalMinutes -lt 45) {
    Start-Sleep -Seconds 10
    $feitos = if (Test-Path $tempos) { (Get-Content $tempos | Measure-Object -Line).Lines } else { 0 }
    if ($c.fila -eq '1') {
      $r = 'redis-cli -a redis-teste --no-auth-warning'
      $w = [int](docker compose exec -T redis sh -c "$r LLEN bull:webhook-processing:wait")
      $a = [int](docker compose exec -T redis sh -c "$r LLEN bull:webhook-processing:active")
      $d = [int](docker compose exec -T redis sh -c "$r ZCARD bull:webhook-processing:delayed")
      Write-Host ("    {0:HH:mm:ss}  processados: {1}  na fila: {2}  em processamento: {3}  reagendados: {4}" -f (Get-Date), $feitos, $w, $a, $d)
      if ($w -eq 0 -and $a -eq 0 -and $d -eq 0) { break }
    } else {
      Write-Host ("    {0:HH:mm:ss}  processados: {1}" -f (Get-Date), $feitos)
      if ($feitos -eq $anterior) { $parado++ } else { $parado = 0 }
      $anterior = $feitos
      if ($parado -ge 6) { break }
    }
  }
  Write-Host ("    Espera apos o teste: {0:N1} min" -f ((Get-Date) - $inicioEspera).TotalMinutes)
  Copy-Item $tempos "resultados/${nome}_webhook.log" -ErrorAction SilentlyContinue
  docker compose logs --no-color webhook-node checkout-node cache-node | Set-Content "resultados/${nome}_node.log"
  if ($c.cache) { docker compose exec -T cache-node wget -qO- http://localhost:3020/estatisticas | Set-Content "resultados/${nome}_cache.json" }
}

if (-not $c.servidores) {
  # O webhook em PHP responde antes de terminar (fastcgi_finish_request): espera terminar de emitir os ingressos
  Write-Host 'Aguardando o PHP terminar de processar os webhooks (90 s)...'
  Start-Sleep -Seconds 90
}
Stop-Job $amostra; Receive-Job $amostra | Set-Content "resultados/${nome}_recursos.csv"; Remove-Job $amostra

# Conferencia: pagamentos pagos x ingressos emitidos, e ingressos vendidos x estoque
Write-Host 'Conferindo pagamentos, ingressos e estoque...'
docker run --rm --network tcc-testes_default -v "${PWD}/seed:/s" -v "${PWD}/resultados:/res" `
  -e FIREBASE_URL=$fb -e MOCK_URL=http://mocks:4000 -e LIMITE_CAMAROTE=$env:LIMITE_CAMAROTE -e SAIDA="/res/${nome}_conferencia.json" `
  node:20-alpine node /s/conferir.js
if (-not $c.servidores) { Copy-Item app/webhook_logs.log "resultados/${nome}_webhook.log" -ErrorAction SilentlyContinue }
Remove-Item app/webhook_logs.log -ErrorAction SilentlyContinue
docker compose logs --no-color php | Set-Content "resultados/${nome}_php.log"
Remove-Item app/api/logs, app/api/registrologsapi, app/api/pagamentocardmp/registrologsapi -Recurse -ErrorAction SilentlyContinue
Write-Host "Pronto. Arquivos em resultados\$nome.*  (relatorio visual: resultados\$nome.html)"
