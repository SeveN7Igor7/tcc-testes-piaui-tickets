# Plano pedido na revisao do orientador, tudo em sequencia:
#  1) mais 3 execucoes (3a, 4a e 5a) do controle, do E1 com 32 processos, do E3 e do E4;
#  2) teste de notificacao duplicada no E1 com 32 processos e no E4;
#  3) teste de estoque (todos querem Camarote, estoque de 100) no E1 com 32 processos e no E4.
# Ao fim de cada execucao, a conferencia de pagamentos x ingressos x estoque fica em resultados\*_conferencia.json.
# Duracao estimada: 4 a 5 horas. Deixe o computador sem suspender e sem outros programas abertos.
Set-Location $PSScriptRoot
$inicio = Get-Date
foreach ($r in 3, 4, 5) {
  foreach ($e in 'E2-Cloud', 'E1-32', 'E3', 'E4') {
    powershell -ExecutionPolicy Bypass -File rodar.ps1 -Estagio $e -Rep $r
  }
}
foreach ($t in 'duplicado', 'estoque') {
  foreach ($e in 'E1-32', 'E4') {
    powershell -ExecutionPolicy Bypass -File rodar.ps1 -Estagio $e -Rep 1 -Teste $t
  }
}
$min = [math]::Round(((Get-Date) - $inicio).TotalMinutes)
Write-Host "Tudo terminado em $min minutos. Compacte a pasta resultados e envie."
